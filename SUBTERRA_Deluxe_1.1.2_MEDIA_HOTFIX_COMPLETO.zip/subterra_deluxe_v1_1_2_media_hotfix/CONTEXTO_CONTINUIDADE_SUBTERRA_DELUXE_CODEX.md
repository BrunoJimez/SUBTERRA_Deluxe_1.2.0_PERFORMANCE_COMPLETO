# CONTEXTO DE CONTINUIDADE — SUBTERRA DELUXE / CODEX

**Data:** 05 de agosto de 2026  
**Finalidade:** entregar ao agente Codex um contexto técnico e operacional completo para continuar o projeto diretamente no computador do usuário.  
**Pasta raiz do projeto no Windows:**  
`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix`

---

## 0. PROMPT INICIAL RECOMENDADO PARA O CODEX

Copie e envie ao Codex, após abrir a pasta raiz do projeto:

> Leia integralmente o arquivo `CONTEXTO_CONTINUIDADE_SUBTERRA_DELUXE_CODEX.md` antes de alterar qualquer arquivo. Trabalhe diretamente na pasta `C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix`. Primeiro faça uma auditoria do estado real do código, do ambiente Python, do ComfyUI instalado, dos modelos de vídeo presentes e dos arquivos gerados. Não confie apenas em documentação ou afirmações anteriores: confirme tudo localmente. Faça backup dos arquivos que modificar. O objetivo imediato é concluir uma integração ComfyUI realmente funcional e simples para o usuário, começando por um único plano `shot_0000`, com upload automático do keyframe, parametrização automática do workflow, geração, download e montagem híbrida. Não use API paga, não reduza a qualidade dos motores anteriores, não copie código do Techno Underground e não declare sucesso sem teste real na RTX 4060. Registre comandos, alterações, resultados e limitações em `CONTINUACAO_CODEX.md`.

---

# 1. VISÃO GERAL DO PROJETO

O projeto SUBTERRA transforma música em filme. A música é analisada em profundidade e convertida em uma montagem visual sincronizada com sua estrutura, energia, batidas, timbres, letra e narrativa.

O projeto evoluiu em três linhas:

1. **SUBTERRA clássico**  
   Filmes techno underground abstratos e procedurais, com mídia de base, filtros, glitch, tipografia, cenas e sincronização musical.

2. **SUBTERRA-CYBERPUNK**  
   Filmes narrativos com personagens, rig 2.5D, ações, continuidade entre planos, cenários cyberpunk e dois mundos gráficos.

3. **SUBTERRA Deluxe**  
   Integração dos motores anteriores, renderização acelerada por GPU, estilos/paletas reais, personagens, mídia, áudio, direção multi-shot e ponte para geração de vídeo por IA local.

O sistema deve funcionar localmente, sem APIs pagas, respeitando o hardware do usuário.

---

# 2. OBJETIVO FINAL DO SUBTERRA DELUXE

Criar um “Seedance musical” local e autoral:

- entrada por música;
- entrada opcional por roteiro;
- imagens, vídeos e personagens de referência;
- análise musical e narrativa;
- geração de um roteiro multi-shot;
- filme procedural completo como base;
- geração por IA apenas de planos selecionados;
- montagem híbrida com fallback procedural;
- saída sincronizada com a música;
- alta qualidade visual;
- seed reproduzível;
- exportação MP4, MKV e AVI;
- resoluções horizontais, verticais, cinema e valores digitáveis;
- uso de GPU e encoder NVENC quando possível;
- preservação do áudio quando o modo `preserve` estiver ativo.

A IA deve ser opcional. O programa precisa continuar produzindo filme completo sem ComfyUI.

---

# 3. REQUISITOS NÃO NEGOCIÁVEIS DO USUÁRIO

## 3.1 Liberdade e custo

- Não usar API paga.
- Priorizar modelos, ferramentas e pipelines locais, gratuitos e abertos.
- Não obrigar o usuário a enviar música, imagem ou vídeo para serviços externos.
- Verificar as licenças de modelos e pesos antes de sugerir uso comercial.

## 3.2 Qualidade

- Não acelerar o render reduzindo silenciosamente qualidade, resolução ou complexidade visual.
- Prévia pode usar parâmetros menores de forma explícita.
- Render final deve preservar os recursos das versões anteriores.
- O modo `preserve` não deve aplicar equalização, compressão, limiter ou mudança de loudness.
- O filme final deve ter a mesma duração da música, exceto quando o usuário escolhe uma prévia.

## 3.3 Reprodutibilidade

Cada execução deve registrar:

- seed;
- estilo;
- motor;
- resolução;
- FPS;
- qualidade;
- encoder;
- modo de áudio;
- roteiro;
- manifesto de IA;
- configuração completa;
- relatório de render;
- erros e fallback.

## 3.4 Originalidade

O Deluxe 1.0 foi rejeitado porque reutilizou excessivamente a arquitetura e os shaders do programa Techno Underground fornecido apenas para estudo.

Regra para continuidade:

- não copiar módulos ou shaders do Techno Underground;
- usar apenas princípios gerais de otimização;
- preservar o núcleo reconstruído do Deluxe 1.1;
- qualquer reutilização de código precisa ser identificada, justificada e licenciada;
- realizar auditoria de similaridade ao final.

## 3.5 Comunicação e validação

- Não declarar que algo “funcionou” sem executar teste real.
- Separar claramente: teste em CPU, teste em GPU, teste de encoder e teste de IA.
- Quando a RTX 4060 não puder ser testada, dizer explicitamente.
- Entregar demonstrações, relatórios e logs verificáveis.

---

# 4. HARDWARE E AMBIENTE DO USUÁRIO

Informações observadas nos relatórios e logs:

| Item | Valor |
|---|---|
| Sistema | Windows 10 AMD64 |
| CPU | AMD Ryzen 5 4600G |
| Núcleos/threads | 6 / 12 |
| RAM | aproximadamente 15,9 GB |
| GPU | NVIDIA GeForce RTX 4060 |
| VRAM | aproximadamente 8 GB / 8188 MB |
| Python | linha 3.11 |
| FFmpeg | instalado e funcional |
| OpenGL | NVIDIA, GL 3.3 ou superior |
| NVENC | H.264, HEVC e outros encoders detectados |
| ComfyUI | Desktop, conectado localmente |
| Servidor ComfyUI | `http://127.0.0.1:8188` |
| Versão ComfyUI observada | `0.30.2` |

O usuário informou que já baixou os modelos solicitados no ComfyUI, mas teve dificuldade em configurar o workflow. O nome exato dos modelos instalados ainda precisa ser descoberto localmente pelo Codex.

---

# 5. HISTÓRICO DAS VERSÕES

## 5.1 SUBTERRA v0.1.0

Primeira base funcional:

- entrada de áudio;
- análise musical;
- BPM, tom, energia, brilho e seções;
- sete arquétipos visuais;
- seed;
- mídia de base;
- exportação;
- interface;
- relatório;
- diagnóstico de hardware.

O usuário testou e confirmou funcionamento.

## 5.2 SUBTERRA Fase 0.2

A versão 0.2 foi criada após análise integral do vídeo `Ninajirachi.mp4` e comparação com `teste.mp4`.

Principais evoluções:

- microplanos;
- montagem mais rápida e variada;
- 17 arquétipos;
- 46 filtros;
- resolução digitável;
- estilos e filtros autorais;
- letras SRT/VTT/LRC/TXT;
- envelopes de bandas;
- múltiplos modos de áudio;
- formato vertical e cinema;
- direção baseada em estrutura musical.

O usuário confirmou que funcionou e ficou muito bom.

## 5.3 SUBTERRA-CYBERPUNK v0.1.0

Novo programa independente, derivado do SUBTERRA 0.2:

- personagens importados;
- recorte;
- animação 2.5D;
- cenários cyberpunk;
- `neon_graphic_grit`;
- `future_noir_cel`;
- `hybrid_cyberpunk`;
- `auto_director`;
- personagens procedurais;
- 16 cenários;
- ações sincronizadas ao áudio.

O usuário confirmou funcionamento perfeito.

## 5.4 SUBTERRA-CYBERPUNK v0.2.0

Evoluções:

- continuidade entre planos;
- `story.json` com shots e character arcs;
- rig 2.5D aprimorado;
- ações corporais;
- movimento secundário;
- lip-sync gráfico;
- transições e câmera;
- ponte image-to-video;
- pacote I2V;
- importação de clipes locais;
- fallback procedural.

O usuário confirmou funcionamento e boa qualidade.

## 5.5 SUBTERRA Deluxe 1.0.0 — REJEITADO

Não usar como base.

Problemas:

- arquitetura e shaders excessivamente semelhantes ao Techno Underground;
- estilos eram principalmente mudanças de parâmetros cromáticos;
- cadeia sonora do outro programa foi reutilizada;
- não representou integração legítima dos projetos anteriores.

## 5.6 SUBTERRA Deluxe 1.1.0 — RECONSTRUÍDO

Base válida atual:

- núcleo independente;
- SUBTERRA 0.2 preservado;
- CYBERPUNK 0.2 preservado;
- motor GPU/CPU;
- 15 cenas originais;
- 28 estilos;
- mídia e personagens;
- áudio `preserve`;
- IA multi-shot;
- montagem híbrida;
- auditoria de originalidade;
- testes de estilos.

## 5.7 SUBTERRA Deluxe 1.1.1 — HOTFIX GPU

Pasta atual:

`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix`

Correção principal:

- erro `KeyError('uBright')` no caminho ModernGL/NVIDIA;
- uniforme `uBright` passou a ser usado de fato;
- escrita de uniformes tolerante à otimização do compilador;
- autoteste GPU;
- campos de relatório `gpu_requested`, `gpu_active_at_finish` e `gpu_error`.

---

# 6. PROBLEMA DE DESEMPENHO E ESTADO DA GPU

Teste problemático anterior:

- prévia: 20 segundos;
- 600 frames;
- 30 fps;
- estilo: `nolan_odisseia`;
- seed: `2143028510`;
- GPU solicitada;
- erro: `KeyError('uBright')`;
- fallback: `CPU vectorised fallback`;
- encoder: `h264_nvenc`;
- tempo: `362.669 s`;
- velocidade: `1.65 fps`.

Importante:

- o NVENC acelerou apenas o encode;
- os quadros foram gerados pela CPU;
- portanto aquele resultado não valida a velocidade GPU.

O hotfix 1.1.1 foi criado, mas o ganho real na RTX 4060 ainda precisa ser medido localmente com:

`BENCHMARK_RTX4060.bat`

Critério de sucesso:

- renderer GPU no relatório;
- `gpu_active_at_finish = true`;
- `gpu_error = null`;
- nenhuma mensagem `CPU vectorised fallback`;
- velocidade significativamente superior a 1,65 fps.

O Codex deve executar e registrar esse benchmark, sem misturá-lo com a geração IA do ComfyUI.

---

# 7. ESTADO ATUAL DA INTEGRAÇÃO COM COMFYUI

## 7.1 O que já funciona

A conexão API foi confirmada pelo SUBTERRA:

```text
ComfyUI conectado
Servidor: http://127.0.0.1:8188
Versão observada: 0.30.2
```

O endpoint `/system_stats` respondeu corretamente.

O usuário relata que os modelos de vídeo solicitados já foram baixados no ComfyUI.

## 7.2 Projeto e arquivos atuais

Pasta raiz:

`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix`

Pasta dos planos IA:

`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix\output\ai_shots`

Manifesto:

`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix\output\ai_shots\manifest.json`

Filme-base:

`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix\output\filme_deluxe.mp4`

Filme híbrido desejado:

`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix\output\filme_deluxe_hibrido.mp4`

Roteiro que originou o manifesto:

`C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix\output\_work\Mr. Control_seed849201337\story.json`

Seed desse projeto:

`849201337`

Quantidade informada de planos:

`69`

O manifesto foi criado via linha de comando com resolução inicial 768 × 432, 24 fps e backend lógico `ltx_video_q8`. Esse rótulo do manifesto não prova que LTX esteja instalado; é apenas um campo de configuração e deve ser reconciliado com o modelo realmente presente.

## 7.3 Campo ainda ausente

Na interface, o campo abaixo ainda está vazio:

`Workflow ComfyUI API`

Esse é o bloqueio imediato.

## 7.4 O que o usuário não quer fazer

O usuário não quer editar manualmente dezenas de IDs ou placeholders JSON. O fluxo precisa se tornar simples e guiado, preferencialmente:

1. detectar o ComfyUI;
2. detectar um backend suportado;
3. preparar ou adaptar o workflow;
4. testar um plano;
5. gerar;
6. baixar;
7. montar.

---

# 8. LIMITAÇÕES REAIS DO CÓDIGO ATUAL

Arquivos relevantes:

- `gui.py`
- `deluxe.py`
- `subterra_deluxe/ai/manifest.py`
- `subterra_deluxe/ai/comfyui.py`
- `subterra_deluxe/ai/hybrid.py`
- `subterra_deluxe/ai/backends.py`

## 8.1 Manifesto

`build_multishot_manifest`:

- abre o filme-base com OpenCV;
- extrai um keyframe no início de cada shot;
- cria `shot_XXXX_keyframe.png`;
- cria `shot_XXXX.json`;
- cria `manifest.json`;
- usa caminho absoluto Windows em `input_image`;
- gera prompt genérico;
- calcula frames como duração × FPS.

## 8.2 Workflow atual

`generate_manifest` espera um JSON API contendo placeholders:

```text
{prompt}
{negative_prompt}
{seed}
{width}
{height}
{frames}
{fps}
{duration}
{input_image}
{output_prefix}
{shot}
```

A função substitui strings e envia o workflow por `/prompt`.

## 8.3 Falha provável de imagem de entrada

O código atual não faz upload do keyframe para o armazenamento de entrada do ComfyUI.

Ele injeta o caminho absoluto:

`C:\...\shot_0000_keyframe.png`

Muitos nós nativos `LoadImage` esperam o nome de um arquivo registrado no diretório `input` do ComfyUI, não um caminho arbitrário do Windows.

O Codex deve confirmar isso no workflow/modelo instalado e implementar uma solução robusta:

- preferencialmente upload pela API do ComfyUI;
- alternativamente cópia controlada para a pasta `input`;
- usar o nome/subpasta retornado pelo upload;
- nunca depender de o ComfyUI “adivinhar” caminhos do SUBTERRA.

O endpoint esperado em versões comuns é `/upload/image`, mas deve ser confirmado na instalação local.

## 8.4 Fragilidade dos placeholders

O workflow exportado pelo usuário pode não conter placeholders. Workflows oficiais geralmente contêm valores concretos.

O programa atual não possui um adaptador semântico para descobrir:

- nó de prompt positivo;
- nó de prompt negativo;
- seed;
- largura;
- altura;
- frames;
- FPS;
- imagem inicial;
- prefixo de saída.

Portanto, o Codex deve evitar exigir edição manual do JSON.

## 8.5 Saída de vídeo

O código atual procura recursivamente no histórico por:

- MP4;
- WebM;
- MOV;
- GIF.

Isso é útil, mas precisa ser testado com o nó de saída real do workflow instalado.

## 8.6 Interface

O botão `1 · EXPORTAR MANIFESTO` depende de `last_story` e `last_base` estarem carregados na mesma sessão. Ao reabrir o programa, ele não recupera automaticamente o projeto anterior.

Isso precisa ser corrigido:

- permitir selecionar `story.json`;
- permitir selecionar o filme-base;
- recuperar projeto recente;
- validar existência dos arquivos;
- não obrigar rerender.

---

# 9. MISSÃO IMEDIATA DO CODEX

A tarefa imediata não é gerar todos os 69 planos.

É concluir um teste end-to-end de **um único plano**:

`shot_0000`

O teste deve fazer:

1. ler `manifest.json`;
2. localizar `shot_0000_keyframe.png`;
3. descobrir o modelo/workflow instalado;
4. gerar ou adaptar um workflow API compatível;
5. enviar/uploadar o keyframe;
6. preencher prompt, seed, resolução, frames e FPS;
7. enfileirar no ComfyUI;
8. acompanhar o histórico;
9. detectar o vídeo;
10. baixar como `shot_0000.mp4`;
11. validar duração, resolução e integridade;
12. montar uma prévia híbrida usando o filme-base nos demais planos.

Somente depois do teste de um plano deve ser habilitada a geração em lote.

---

# 10. PLANO DE TRABALHO RECOMENDADO PARA O CODEX

## Fase A — auditoria local

1. Criar backup:
   - `backup_pre_codex_YYYYMMDD_HHMM`.
2. Executar:
   - `git status`, se houver Git;
   - listar arquivos;
   - verificar `.venv`;
   - verificar `requirements.txt`;
   - executar `RODAR_TESTES.bat`;
   - executar testes Python relevantes.
3. Ler:
   - `README.md`;
   - `VALIDATION_REPORT.md`;
   - `CHANGELOG.md`;
   - módulos `subterra_deluxe/ai`.
4. Confirmar:
   - `manifest.json`;
   - keyframes;
   - filme-base;
   - `story.json`;
   - quantidade de shots.
5. Não sobrescrever arquivos originais sem backup.

## Fase B — descoberta do ComfyUI

Descobrir no computador:

- pasta de instalação do ComfyUI Desktop;
- pasta de usuário;
- pasta `input`;
- pasta `output`;
- modelos presentes;
- custom nodes;
- templates/workflows disponíveis;
- backend de vídeo efetivamente instalado;
- classe dos nós do workflow;
- API disponível;
- versão Python/PyTorch/CUDA do ComfyUI;
- VRAM livre durante o teste.

Consultar localmente, conforme disponível:

- `/system_stats`;
- `/object_info`;
- `/queue`;
- `/history`;
- logs do ComfyUI;
- arquivos do workflow/templates.

Não assumir que o backend é LTX ou Wan. Detectar.

## Fase C — escolher backend

Critérios:

- compatível com RTX 4060 8 GB;
- já instalado;
- image-to-video;
- gera arquivo de vídeo detectável;
- suporta resolução de teste entre 640 × 360 e 768 × 432;
- não exige serviço pago.

Para o primeiro teste:

- 24 fps;
- poucos segundos;
- aproximadamente 49 a 81 frames;
- baixa concorrência;
- um único shot.

## Fase D — integração robusta

Implementar:

### 1. Upload do keyframe

Função sugerida:

```python
def upload_input_image(host: str, image_path: Path) -> dict:
    # multipart/form-data
    # retorna name, subfolder e type conforme a API instalada
```

### 2. Adaptador de workflow

Preferência de arquitetura:

- perfis por backend;
- descoberta por `class_type`;
- mapeamento de nós por função;
- validação antes de enviar;
- erro claro se houver ambiguidade;
- salvar workflow adaptado por shot para auditoria.

Evitar depender apenas de placeholders textuais.

### 3. Preset de workflow incluído

Depois de confirmar o modelo instalado, incluir no projeto um workflow API funcional e documentado, sem pesos.

Exemplo de localização:

`workflows/comfyui/<backend>/subterra_i2v_api.json`

### 4. Teste de um plano

Adicionar botão:

`TESTAR SHOT 0000`

O botão deve:

- validar conexão;
- validar workflow;
- validar modelo;
- subir keyframe;
- executar;
- mostrar progresso;
- baixar;
- abrir pasta do clipe;
- mostrar erro detalhado.

### 5. Geração seletiva

Adicionar seleção:

- todos;
- destaques;
- intervalo de shots;
- lista manual;
- ausentes;
- apenas falhos.

Não iniciar 69 planos por padrão.

### 6. Retomada

- se `shot_XXXX.mp4` já existir e estiver válido, pular;
- registrar status por shot;
- permitir cancelar;
- permitir retomar;
- salvar `comfyui_generation_report.json`.

## Fase E — montagem híbrida

Após `shot_0000.mp4`:

- gerar um híbrido curto;
- usar IA no shot 0;
- fallback procedural nos demais;
- preservar áudio;
- validar duração;
- criar relatório.

## Fase F — interface

Melhorias mínimas:

- detectar ComfyUI;
- mostrar versão e GPU;
- mostrar modelo/backend detectado;
- selecionar `story.json`;
- selecionar workflow;
- botão de auto-configuração;
- botão de teste de um shot;
- logs legíveis;
- barra de progresso por shot;
- estimativa apenas depois de medição real;
- tooltip ou ajuda em cada campo.

---

# 11. ACEITE TÉCNICO DA INTEGRAÇÃO IA

A integração só pode ser considerada funcional quando todos os itens abaixo forem comprovados localmente.

## 11.1 Conexão

- `/system_stats` responde;
- versão registrada;
- GPU/VRAM registrada.

## 11.2 Workflow

- API JSON válido;
- todos os nós existem no ComfyUI instalado;
- modelos referenciados existem;
- sem placeholders não resolvidos;
- sem caminhos inválidos.

## 11.3 Entrada

- keyframe enviado ou copiado corretamente;
- nó de imagem abre o arquivo;
- resolução correta;
- seed correta.

## 11.4 Geração

- ComfyUI retorna `prompt_id`;
- execução aparece no histórico;
- nenhum erro de modelo/nó/VRAM;
- arquivo de vídeo é produzido.

## 11.5 Download

- vídeo baixado como `shot_0000.mp4`;
- arquivo não vazio;
- FFprobe lê o arquivo;
- duração aceitável;
- FPS e resolução registrados.

## 11.6 Montagem

- híbrido criado;
- IA usada no shot 0;
- fallback usado nos demais;
- áudio preservado;
- duração do filme preservada;
- relatório informa IA e fallback.

## 11.7 Usabilidade

- usuário não edita JSON manualmente;
- usuário não copia keyframe manualmente para o ComfyUI;
- erro mostra ação corretiva;
- geração pode ser retomada.

---

# 12. ACEITE TÉCNICO DE DESEMPENHO

Separar três métricas:

## 12.1 Análise musical

- tempo de análise;
- cache usado ou não;
- stems/transcrição ativados ou não.

## 12.2 Render procedural

- renderer GPU ou CPU;
- FPS de render;
- tempo do render;
- tempo do encode;
- GPU ativa até o fim.

## 12.3 Geração IA

- modelo;
- resolução;
- frames;
- steps;
- VRAM;
- tempo por shot;
- tempo de download;
- taxa de sucesso.

Não comparar diretamente FPS procedural com geração difusiva por IA.

---

# 13. ESTILOS E PALETAS

O Deluxe reconstruído contém 28 estilos e eles devem continuar distintos. Exemplos importantes:

- `nolan_odisseia`;
- `mitsubishi_evo_1999_camcorder`;
- `trance_classics_late_90s`;
- `unrealistic_hacking`;
- `cold_corporate_glass`;
- `yokohama_9pm`;
- `gen_x_soft_club`;
- `dark_deco`;
- `samurai_graphic_minimal`;
- `legacy_matrix`;
- `frutiger_aero`;
- `scp_zxckfair`;
- mundos cyberpunk.

Cada estilo deve influenciar:

1. transformação de cor;
2. processamento espacial;
3. comportamento temporal;
4. direção gráfica.

Não transformar novamente estilos em simples paletas.

Os testes anteriores informaram:

- 28/28 hashes visuais distintos;
- diferença mínima em relação ao neutro;
- vídeo comparativo e galeria.

O Codex deve preservar e reexecutar esses testes após alterações no renderer.

---

# 14. ÁUDIO

Modos:

- `preserve`;
- `streaming`;
- `cinema`;
- `club`.

Regra principal:

`preserve` não aplica filtros sonoros.

Em MP4, pode recodificar para AAC por compatibilidade. Em MKV, FLAC é preferível quando suportado.

A montagem híbrida deve usar:

- áudio master selecionado, quando fornecido;
- caso contrário, áudio do filme-base;
- nunca o áudio silencioso dos clipes IA.

---

# 15. ARQUIVOS IMPORTANTES NA PASTA RAIZ

Arquivos esperados:

```text
ABRIR_DELUXE.bat
ABRIR_SUBTERRA_CLASSICO.bat
ABRIR_CYBERPUNK.bat
BENCHMARK_RTX4060.bat
DIAGNOSTICO_WINDOWS.bat
INSTALAR_WINDOWS.bat
RODAR_TESTES.bat
README.md
VALIDATION_REPORT.md
CHANGELOG.md
AUDIT_ORIGINALITY.json
deluxe.py
gui.py
requirements.txt
style_specs.json
subterra_deluxe/
engines/
output/
```

Submódulos críticos:

```text
subterra_deluxe/ai/comfyui.py
subterra_deluxe/ai/manifest.py
subterra_deluxe/ai/hybrid.py
subterra_deluxe/ai/backends.py
```

---

# 16. COMANDOS ÚTEIS

Executar a interface:

```bat
cd /d "C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix"
ABRIR_DELUXE.bat
```

Testes:

```bat
RODAR_TESTES.bat
```

Benchmark:

```bat
BENCHMARK_RTX4060.bat
```

Conexão ComfyUI:

```powershell
Invoke-RestMethod http://127.0.0.1:8188/system_stats
```

Verificar manifesto:

```powershell
$manifest = Get-Content ".\output\ai_shots\manifest.json" -Raw | ConvertFrom-Json
$manifest.shots.Count
$manifest.shots[0] | ConvertTo-Json -Depth 10
```

Gerar apenas depois de workflow válido:

```bat
.venv\Scripts\python.exe deluxe.py ai-generate ^
  "output\ai_shots\manifest.json" ^
  "CAMINHO_DO_WORKFLOW_API.json" ^
  --host http://127.0.0.1:8188 ^
  --output-dir "output\ai_shots"
```

Montar:

```bat
.venv\Scripts\python.exe deluxe.py ai-assemble ^
  "output\ai_shots\manifest.json" ^
  "output\filme_deluxe.mp4" ^
  "output\ai_shots" ^
  "output\filme_deluxe_hibrido.mp4"
```

O Codex deve primeiro criar uma forma de gerar somente um shot, para não iniciar os 69 planos.

---

# 17. RISCOS E CUIDADOS

## VRAM

8 GB é o limite principal. Começar pequeno:

- 640 × 360 ou 768 × 432;
- um plano;
- poucos frames;
- batch 1;
- offload quando necessário.

## RAM

A máquina possui aproximadamente 16 GB e havia cerca de 7,5 GB livres na conexão mostrada. Evitar modelos e caches que exijam muita RAM simultaneamente.

## Espaço em disco

Modelos e clipes podem ocupar dezenas de GB. Verificar espaço antes de geração em lote.

## Duração dos shots

O roteiro possui planos longos. Modelos I2V geralmente funcionam melhor com clipes curtos.

O Codex deve considerar:

- dividir shots longos em subshots IA;
- repetir/estender com técnicas controladas;
- usar IA apenas em destaques;
- preservar fallback.

## Identidade

Para personagens:

- keyframes limpos;
- prompts literais;
- planos curtos;
- evitar mudanças extremas de ângulo;
- manter seed;
- usar o rig 2.5D quando a IA não for necessária.

---

# 18. O QUE NÃO FAZER

- Não iniciar geração dos 69 shots sem teste.
- Não exigir edição manual do workflow JSON.
- Não copiar o Techno Underground.
- Não remover os motores Classic e Cyberpunk.
- Não alterar áudio no modo `preserve`.
- Não substituir estilos por simples LUTs.
- Não declarar GPU ativa apenas porque o encoder é NVENC.
- Não confundir render OpenGL com ComfyUI.
- Não baixar modelos sem verificar espaço e licença.
- Não usar serviço pago.
- Não apagar o filme-base ou os projetos `_work`.
- Não sobrescrever arquivos sem backup.
- Não fazer afirmações de qualidade “Nolan” sem qualificar como direção estética, não equivalência de produção.

---

# 19. ENTREGÁVEIS ESPERADOS DO CODEX

## Entrega 1 — diagnóstico

Arquivo:

`CONTINUACAO_CODEX.md`

Com:

- estado real;
- modelo detectado;
- workflow detectado;
- arquivos modificados;
- comandos;
- testes;
- pendências.

## Entrega 2 — integração de um shot

- `shot_0000.mp4`;
- relatório do ComfyUI;
- FFprobe;
- screenshot/log;
- híbrido de teste.

## Entrega 3 — correção do programa

- upload automático do keyframe;
- workflow adaptado;
- UI de teste;
- seleção de shots;
- retomada;
- logs.

## Entrega 4 — validação

- testes anteriores continuam passando;
- benchmark GPU;
- teste IA;
- montagem;
- originalidade;
- ZIP ou commit final.

---

# 20. FORMATO DE TRABALHO COM O USUÁRIO

O usuário prefere:

- português;
- respostas técnicas;
- precisão;
- objetividade;
- instruções executáveis;
- arquivos prontos;
- logs e demonstrações;
- honestidade sobre falhas.

O usuário perdeu confiança após uma versão anterior inadequada. Portanto:

- mostrar evidência;
- explicar causa de erros;
- corrigir no código;
- testar;
- não improvisar uma narrativa de sucesso.

---

# 21. PRIMEIRA AÇÃO RECOMENDADA AO CODEX

Após ler este arquivo, o Codex deve responder ao usuário com um plano curto e iniciar a auditoria local.

Ordem ideal:

1. confirmar a pasta;
2. criar backup;
3. identificar o ComfyUI e os modelos;
4. validar o manifesto;
5. encontrar/importar um workflow I2V instalado;
6. criar integração para um shot;
7. executar o teste;
8. só então alterar a interface para automação completa.

O primeiro marco objetivo é:

> `shot_0000_keyframe.png` entra automaticamente no ComfyUI e resulta em `shot_0000.mp4`, sem edição manual de JSON.

---

# 22. CHECKLIST FINAL PARA O CODEX

- [ ] Li este documento integralmente.
- [ ] Fiz backup.
- [ ] Auditei o código atual.
- [ ] Confirmei ComfyUI 8188.
- [ ] Descobri modelo instalado.
- [ ] Descobri workflow/API.
- [ ] Confirmei keyframe e manifesto.
- [ ] Implementei upload.
- [ ] Adaptei parâmetros.
- [ ] Testei shot 0000.
- [ ] Baixei MP4.
- [ ] Montei híbrido.
- [ ] Preservei áudio.
- [ ] Executei testes anteriores.
- [ ] Executei benchmark GPU.
- [ ] Registrei tudo em `CONTINUACAO_CODEX.md`.
- [ ] Não declarei sucesso sem evidência.

---

**Fim do documento de continuidade.**
