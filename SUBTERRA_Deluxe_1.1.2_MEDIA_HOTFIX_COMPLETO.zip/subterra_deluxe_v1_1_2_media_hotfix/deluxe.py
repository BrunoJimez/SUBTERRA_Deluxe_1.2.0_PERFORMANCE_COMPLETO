from subterra_deluxe.cli import main
if __name__=='__main__':raise SystemExit(main())
