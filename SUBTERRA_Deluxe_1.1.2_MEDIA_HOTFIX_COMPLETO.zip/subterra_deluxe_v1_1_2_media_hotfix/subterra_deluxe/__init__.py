"""SUBTERRA Deluxe rebuilt integration engine."""
__version__ = "1.1.2-media-shape-hotfix"
