#version 330
in vec2 uv;
out vec4 fragColor;
uniform vec2 uRes;
uniform float uTime;
uniform float uEnergy;
uniform float uImpact;
uniform float uBright;
uniform float uSeed;
uniform int uScene;

float hash21(vec2 p){ p=fract(p*vec2(123.34,345.45)); p+=dot(p,p+34.345); return fract(p.x*p.y); }
float line(float d,float w){return smoothstep(w,0.0,abs(d));}
vec3 pal(float x,vec3 a,vec3 b,vec3 c){float m=clamp(x*2.0,0.0,1.0);float h=clamp((x-.5)*2.0,0.0,1.0);return mix(mix(a,b,m),c,h);}

vec3 subterranean(vec2 p){
 float r=length(p);float a=atan(p.y,p.x);float rings=.5+.5*sin(r*92.0-uTime*(4.0+uEnergy*8.0));float ribs=.5+.5*sin(a*10.0+uTime*.5);float floor=exp(-abs(p.y-.19)*24.0)*(.5+.5*sin(p.x*130.0/(p.y+.76)+uTime*6.0));float v=clamp(rings*.38+ribs*.17+floor*.65+uImpact*.18,0.0,1.0);return pal(v,vec3(.012,.008,.025),vec3(.15,.055,.22),vec3(.95,.22,.75));}
vec3 powerlines(vec2 p){
 vec3 sky=mix(vec3(.06,.02,.10),vec3(.38,.08,.38),clamp(1.0-(p.y+.5),0.0,1.0));
 float horizon=smoothstep(-.20,-.18,p.y);sky=mix(sky,vec3(.01),horizon);
 for(int k=0;k<4;k++){float x=-.65+float(k)*.43+.04*sin(uTime*.12+float(k));float mast=line(p.x-x,.006)*(1.0-smoothstep(-.38,.42,p.y));float cross=line(p.y+.12,.005)*line(abs(p.x-x)-.10,.09);sky+=vec3(.78,.78,.86)*(mast+cross);if(k<3){float nx=-.65+float(k+1)*.43+.04*sin(uTime*.12+float(k+1));float u=clamp((p.x-x)/(nx-x),0.0,1.0);float cable=-.12+.08*sin(u*3.14159);sky+=vec3(.75)*line(p.y-cable,.003)*step(x,p.x)*step(p.x,nx);}}
 return sky;
}
vec3 waveformCity(vec2 p){float f=sin(p.x*22.0+uTime*1.5)+sin(p.y*17.0-uTime)+sin((p.x+p.y)*13.0+uTime*.7);float v=.5+f/6.0;vec3 c=pal(v,vec3(.01,.01,.04),vec3(.06,.10,.35),vec3(.85,.20,.95));float cell=floor((p.x+.9)*18.0);float h=.12+.5*hash21(vec2(cell,uSeed));float bx=line(fract((p.x+.9)*18.0)-.5,.42)*step(p.y,-.15+h)*step(-.52,p.y);c=mix(c,vec3(.03,.015,.08),bx);return c;}
vec3 chrome(vec2 p){float f=sin(p.x*10.0+cos(p.y*7.0-uTime)*2.0+uTime)+cos(p.y*12.0+sin(p.x*8.0+uTime)*2.0-uTime*.7);float v=pow(clamp((f+2.0)/4.0,0.0,1.0),.55);return pal(v,vec3(.01,.015,.025),vec3(.36,.42,.46),vec3(.95,.92,.84));}
vec3 city(vec2 p){vec3 c=mix(vec3(.02,.01,.05),vec3(.32,.03,.31),clamp(1.0-(p.y+.5),0.0,1.0));float gx=floor((p.x+.9)*27.0);float h=.10+.55*hash21(vec2(gx,uSeed));float body=line(fract((p.x+.9)*27.0)-.5,.42)*step(p.y,-.5+h);c=mix(c,vec3(.04,.015,.09)+vec3(.18,.02,.28)*hash21(vec2(gx,8.0)),body);float win=line(fract((p.y+.5)*45.0)-.5,.07)*body;c+=vec3(.45,.08,.58)*win;return c;}
vec3 club(vec2 p){vec3 c=vec3(.05,.01,.10);for(int k=0;k<6;k++){vec2 q=p-vec2(-.65+float(k)*.27,.20+.03*sin(uTime+float(k)));float d=length(q);c+=vec3(.18+.04*float(k),.02,.28)*smoothstep(.18,.02,d);}float crowd=step(-.48,p.y)*(.5+.5*sin(p.x*95.0+sin(uTime*2.0)*3.0));c=mix(c,vec3(.005),crowd*.8);return c;}
vec3 monument(vec2 p){vec3 c=mix(vec3(.06,.07,.10),vec3(.44,.50,.58),clamp(1.0-(p.y+.5),0.0,1.0));c=mix(c,vec3(.08,.12,.18),step(-.20,p.y));float tri=step(abs(p.x),(.35-p.y)*.34)*step(-.35,p.y);c=mix(c,vec3(.025,.035,.055),tri);float sun=smoothstep(.09,.07,length(p-vec2(.50,-.20)));c+=vec3(.75,.82,.95)*sun;return c;}
vec3 stage(vec2 p){vec3 c=vec3(.025,.008,.05);for(int k=0;k<8;k++){float x=-.85+float(k)*.24;float ray=line(cross(vec3(p-vec2(x,-.5),0),vec3(.5-x,.8,0)).z,.015);c+=vec3(.12+.04*float(k),.02,.30)*ray;}float rings=.5+.5*sin(length(vec2(p.x,(p.y-.25)*3.0))*55.0);c+=vec3(.6,.04,.65)*rings*exp(-abs(p.y-.25)*7.0);return c;}
vec3 cathedral(vec2 p){float spokes=.5+.5*sin(atan(p.y,p.x)*14.0+uTime*.2);float waves=.5+.5*sin(p.y*35.0-uTime*2.0);float v=spokes*exp(-length(p)*1.8)+waves*.2;return pal(v,vec3(.01,.01,.04),vec3(.10,.05,.28),vec3(.78,.75,.95));}
vec3 corridor(vec2 p){vec3 c=vec3(.05,.01,.055);vec2 vp=vec2(0.0,-.05);for(int k=-5;k<=5;k++){float x=float(k)*.17;float d=abs(cross(vec3(p-vp,0),vec3(x,.55,0)).z);c+=vec3(.25,.04,.22)*line(d,.007);}c+=vec3(.18,.03,.15)*line(fract((p.y+.55)*12.0)-.5,.035);return c;}
vec3 glass(vec2 p){vec3 c=mix(vec3(.15,.22,.25),vec3(.82,.88,.90),clamp(1.0-(p.y+.5),0.0,1.0));for(int k=-4;k<=4;k++){float x=float(k)*.22;float d=abs(cross(vec3(p-vec2(0,.5),0),vec3(x,-1.0,0)).z);c+=vec3(.18,.24,.26)*line(d,.006);}return c;}
vec3 inkroom(vec2 p){vec3 c=vec3(.06,.04,.22);float wall=step(abs(p.x),.78)*step(abs(p.y),.42);c=mix(vec3(.02,.01,.05),c,wall);float window=step(abs(p.x-.32),.27)*step(abs(p.y+.06),.24);c=mix(c,vec3(.006),window);return c;}
vec3 hologram(vec2 p){vec3 c=city(p);vec2 q=(p-vec2(.30,-.05))/vec2(.55,.75);float head=smoothstep(.25,.22,length(q-vec2(0,-.32)));float body=smoothstep(.55,.45,length(q-vec2(0,.18)));float h=max(head,body*.8);c=mix(c,vec3(.85,.18,.92),h*.72);return c;}
vec3 orbit(vec2 p){vec3 c=vec3(0);float n=hash21(floor((p+1.0)*300.0));c+=vec3(.65)*step(.995,n);float planet=smoothstep(.30,.29,length(p-vec2(.45,-.05)));c=mix(c,vec3(.12,.18,.32),planet);float ring=line(length((p-vec2(.45,-.05))*vec2(1.0,4.0))-.42,.008);c+=vec3(.55,.42,.38)*ring;float ruin=step(abs(p.x+.35),.28)*step(abs(p.y-.30),.06);c=mix(c,vec3(.08,.10,.15),ruin);return c;}
void main(){
 vec2 p=(gl_FragCoord.xy-.5*uRes)/max(uRes.x,uRes.y);p.y=-p.y;
 vec3 c;
 if(uScene==0)c=subterranean(p);else if(uScene==1)c=powerlines(p);else if(uScene==2)c=waveformCity(p);else if(uScene==3)c=chrome(p);else if(uScene==4)c=city(p);else if(uScene==5)c=club(p);else if(uScene==6)c=monument(p);else if(uScene==7)c=stage(p);else if(uScene==8)c=cathedral(p);else if(uScene==9)c=corridor(p);else if(uScene==10)c=glass(p);else if(uScene==11)c=city(p)+vec3(.04)*sin((p.x+p.y+uTime)*80.0);else if(uScene==12)c=inkroom(p);else if(uScene==13)c=hologram(p);else c=orbit(p);
 // Brilho espectral do áudio: exposição sutil e limitada. Além de tornar o
 // parâmetro musical efetivo, impede que drivers NVIDIA removam uBright.
 float spectralExposure=mix(.84,1.16,clamp(uBright,0.0,1.0));
 c*=spectralExposure;
 c+=vec3(.018,.012,.024)*(clamp(uBright,0.0,1.0)-.5);
 fragColor=vec4(pow(max(c,vec3(0)),vec3(.92)),1.0);
}
