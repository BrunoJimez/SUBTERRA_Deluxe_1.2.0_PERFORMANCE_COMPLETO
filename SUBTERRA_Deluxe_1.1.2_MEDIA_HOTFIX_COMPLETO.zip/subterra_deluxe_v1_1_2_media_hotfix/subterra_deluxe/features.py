from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np


def _normalise(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    if x.size == 0:
        return x
    lo, hi = np.nanpercentile(x, [2, 98])
    if hi <= lo + 1e-8:
        return np.zeros_like(x)
    return np.clip((x - lo) / (hi - lo), 0, 1)


def audio_cache_key(path: str | Path) -> str:
    p = Path(path)
    h = hashlib.sha256()
    h.update(str(p.resolve()).encode())
    st = p.stat()
    h.update(f"{st.st_size}:{st.st_mtime_ns}".encode())
    return h.hexdigest()[:20]


def analyse_audio(audio_path: str | Path, work_dir: str | Path, use_cache: bool = True) -> tuple[Path, Path]:
    """Analyse audio using the proven SUBTERRA 0.2 feature vocabulary.

    This is a clean integration implementation: it caches by file signature and
    never applies audio processing during analysis.
    """
    import librosa
    from scipy.signal import find_peaks

    source = Path(audio_path)
    out = Path(work_dir)
    out.mkdir(parents=True, exist_ok=True)
    key = audio_cache_key(source)
    json_path = out / f"analysis_{key}.json"
    npz_path = out / f"features_{key}.npz"
    if use_cache and json_path.exists() and npz_path.exists():
        return json_path, npz_path

    y, sr = librosa.load(str(source), sr=22050, mono=True)
    if y.size == 0:
        raise ValueError("Áudio vazio ou ilegível.")
    hop = 512
    duration = float(librosa.get_duration(y=y, sr=sr))
    harmonic, percussive = librosa.effects.hpss(y)
    rms = librosa.feature.rms(y=y, hop_length=hop)[0]
    onset = librosa.onset.onset_strength(y=percussive, sr=sr, hop_length=hop)
    centroid = librosa.feature.spectral_centroid(y=y, sr=sr, hop_length=hop)[0]
    flatness = librosa.feature.spectral_flatness(y=y, hop_length=hop)[0]
    chroma = librosa.feature.chroma_cens(y=harmonic, sr=sr, hop_length=hop)
    spec = np.abs(librosa.stft(y, n_fft=2048, hop_length=hop))
    freqs = librosa.fft_frequencies(sr=sr, n_fft=2048)
    times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=hop)
    tempo, beat_frames = librosa.beat.beat_track(onset_envelope=onset, sr=sr, hop_length=hop)
    bpm = float(np.asarray(tempo).reshape(-1)[0]) if np.asarray(tempo).size else 120.0
    beat_times = librosa.frames_to_time(beat_frames, sr=sr, hop_length=hop)

    n = min(len(times), len(rms), len(onset), len(centroid), len(flatness), chroma.shape[1], spec.shape[1])
    times = times[:n]
    spec = spec[:, :n]
    energy = _normalise(rms[:n])
    impact = _normalise(onset[:n])
    brightness = _normalise(centroid[:n])
    texture = _normalise(flatness[:n])
    flux = _normalise(np.sqrt(np.sum(np.maximum(0, np.diff(spec, axis=1, prepend=spec[:, :1])) ** 2, axis=0)))

    def band(lo: float, hi: float) -> np.ndarray:
        mask = (freqs >= lo) & (freqs < hi)
        return _normalise(np.mean(spec[mask], axis=0)) if np.any(mask) else np.zeros(n, np.float32)

    sub = band(20, 80)
    bass = band(80, 250)
    mid = band(250, 2500)
    presence = band(2500, 6000)
    air = band(6000, sr / 2 + 1)

    feature_stack = np.vstack([chroma[:, :n], energy, impact, brightness, bass, flux])
    smooth = np.vstack([np.convolve(r, np.ones(17) / 17, mode="same") for r in feature_stack])
    novelty = _normalise(np.linalg.norm(np.diff(smooth, axis=1, prepend=smooth[:, :1]), axis=0))
    dt = max(0.001, float(times[1] - times[0])) if len(times) > 1 else 1.0
    peaks, props = find_peaks(novelty, distance=max(1, int(5.0 / dt)), prominence=0.13)
    order = peaks[np.argsort(props.get("prominences", np.ones(len(peaks))))[::-1]] if len(peaks) else peaks
    max_cuts = max(3, min(20, int(duration / 12) + 3))
    chosen = sorted(order[: max_cuts - 1].tolist())
    bounds = [0.0]
    for i in chosen:
        b = float(times[min(i, len(times) - 1)])
        if b - bounds[-1] >= 3.0:
            bounds.append(b)
    bounds.append(duration)
    bounds = np.asarray(bounds, np.float32)

    sections: list[dict[str, Any]] = []
    for idx in range(len(bounds) - 1):
        a, b = float(bounds[idx]), float(bounds[idx + 1])
        mask = (times >= a) & (times < b)
        if not np.any(mask):
            mask = np.ones(n, bool)
        sections.append({
            "index": idx, "start": round(a, 3), "end": round(b, 3),
            "duration": round(b - a, 3),
            "energy": round(float(energy[mask].mean()), 4),
            "impact": round(float(impact[mask].mean()), 4),
            "brightness": round(float(brightness[mask].mean()), 4),
            "bass": round(float(bass[mask].mean()), 4),
            "flux": round(float(flux[mask].mean()), 4),
        })
    energies = np.array([s["energy"] for s in sections], np.float32)
    q25, q55, q80 = np.quantile(energies, [0.25, 0.55, 0.80]) if len(energies) else (0.2, 0.5, 0.8)
    for i, s in enumerate(sections):
        e = s["energy"]
        before = sections[i - 1]["energy"] if i else e
        after = sections[i + 1]["energy"] if i + 1 < len(sections) else e
        if i == 0:
            role = "intro"
        elif i == len(sections) - 1:
            role = "outro"
        elif e <= q25:
            role = "breakdown"
        elif e >= q80:
            role = "climax"
        elif e - before > 0.16:
            role = "drop"
        elif after - e > 0.12:
            role = "buildup"
        else:
            role = "development"
        s["role"] = role

    summary = {
        "source": str(source.resolve()), "duration_seconds": round(duration, 4),
        "sample_rate": sr, "estimated_bpm": round(bpm, 3),
        "beats": int(len(beat_times)), "sections": sections,
        "energy_mean": round(float(energy.mean()), 4),
        "brightness_mean": round(float(brightness.mean()), 4),
        "mood_tags": [
            "driving" if bpm >= 125 else "measured",
            "dark" if brightness.mean() < 0.50 else "bright",
            "aggressive" if impact.mean() > 0.38 else "hypnotic",
            "bass-heavy" if bass.mean() > presence.mean() else "aerial",
        ],
    }
    json_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    np.savez_compressed(npz_path, times=times.astype(np.float32), energy=energy.astype(np.float32),
                        impact=impact.astype(np.float32), brightness=brightness.astype(np.float32),
                        texture=texture.astype(np.float32), flux=flux.astype(np.float32),
                        sub=sub.astype(np.float32), bass=bass.astype(np.float32), mid=mid.astype(np.float32),
                        presence=presence.astype(np.float32), air=air.astype(np.float32),
                        beat_times=np.asarray(beat_times, np.float32), section_bounds=bounds)
    return json_path, npz_path


class FeatureStream:
    def __init__(self, path: str | Path):
        z = np.load(path)
        self.times = z["times"]
        self.channels = {k: z[k] for k in z.files if k not in {"times", "beat_times", "section_bounds"}}
        self.beat_times = z["beat_times"]

    def value(self, name: str, t: float) -> float:
        arr = self.channels.get(name)
        return float(np.interp(t, self.times, arr)) if arr is not None and len(arr) else 0.0

    def pulse(self, t: float, decay: float = 10.0) -> float:
        if not len(self.beat_times):
            return 0.0
        i = int(np.searchsorted(self.beat_times, t, side="right") - 1)
        return math.exp(-max(0.0, t - float(self.beat_times[i])) * decay) if i >= 0 else 0.0
