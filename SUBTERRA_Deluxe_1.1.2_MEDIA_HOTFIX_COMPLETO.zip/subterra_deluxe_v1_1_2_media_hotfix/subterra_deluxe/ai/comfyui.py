from __future__ import annotations

import json
import mimetypes
import re
import shutil
import subprocess
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from collections.abc import Iterable
from pathlib import Path, PurePosixPath
from typing import Callable


VIDEO_SUFFIXES = {".mp4", ".webm", ".mov", ".gif"}


def _http_error(exc: urllib.error.HTTPError) -> RuntimeError:
    try:
        body = exc.read().decode("utf-8", errors="replace")
    except Exception:
        body = ""
    detail = f": {body}" if body else ""
    return RuntimeError(f"ComfyUI respondeu HTTP {exc.code} em {exc.url}{detail}")


def _read_json(url: str, timeout: float = 20) -> dict:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise _http_error(exc) from exc


def _post_json(url: str, payload: dict, timeout: float = 30) -> dict:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise _http_error(exc) from exc


def test_connection(host: str = "http://127.0.0.1:8188") -> dict:
    return _read_json(host.rstrip("/") + "/system_stats", 10)


def parse_shot_selector(value: str | None) -> list[int] | None:
    """Parse ``0,2-4``; return ``None`` only for an explicit ``all``."""
    raw = (value or "0").strip().lower()
    if raw == "all":
        return None
    selected: set[int] = set()
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            first, last = part.split("-", 1)
            start, end = int(first), int(last)
            if start < 0 or end < start:
                raise ValueError(f"Intervalo de shots inválido: {part}")
            selected.update(range(start, end + 1))
        else:
            shot = int(part)
            if shot < 0:
                raise ValueError(f"Shot inválido: {part}")
            selected.add(shot)
    if not selected:
        raise ValueError("Selecione ao menos um shot ou use 'all'.")
    return sorted(selected)


def _input_options(object_info: dict, node: str, input_name: str) -> list[str]:
    definition = object_info.get(node, {})
    fields = definition.get("input", {}).get("required", {})
    spec = fields.get(input_name)
    if not isinstance(spec, list) or not spec:
        return []
    if isinstance(spec[0], list):
        return [str(value) for value in spec[0]]
    if len(spec) > 1 and isinstance(spec[1], dict):
        options = spec[1].get("options", [])
        values: list[str] = []
        for option in options:
            if isinstance(option, dict) and "key" in option:
                values.append(str(option["key"]))
            elif isinstance(option, str):
                values.append(option)
        return values
    return []


def _first_matching(values: Iterable[str], *needles: str) -> str | None:
    for value in values:
        lower = value.lower()
        if all(needle.lower() in lower for needle in needles):
            return value
    return None


def discover_comfyui(host: str = "http://127.0.0.1:8188") -> dict:
    """Discover actual loader choices and local video capabilities via the API."""
    host = host.rstrip("/")
    stats = _read_json(host + "/system_stats", 15)
    object_info = _read_json(host + "/object_info", 90)
    unets = _input_options(object_info, "UNETLoader", "unet_name")
    clips = _input_options(object_info, "CLIPLoader", "clip_name")
    vaes = _input_options(object_info, "VAELoader", "vae_name")
    clip_vision = _input_options(object_info, "CLIPVisionLoader", "clip_name")

    wan_i2v = next(
        (name for name in unets if "wan2.1" in name.lower() and "i2v" in name.lower()), None
    )
    wan_fun_camera = next(
        (
            name
            for name in unets
            if "wan2.1" in name.lower()
            and ("fun_camera" in name.lower() or "fun-camera" in name.lower())
        ),
        None,
    )
    wan_t2v = next(
        (name for name in unets if "wan2.1" in name.lower() and "t2v" in name.lower()), None
    )
    text_encoder = _first_matching(clips, "umt5") or _first_matching(clips, "wan")
    vae = _first_matching(vaes, "wan")
    vision = _first_matching(clip_vision, "clip_vision") or (
        clip_vision[0] if clip_vision else None
    )
    required_common = {
        "UNETLoader",
        "CLIPLoader",
        "VAELoader",
        "CLIPTextEncode",
        "ModelSamplingSD3",
        "KSampler",
        "VAEDecode",
        "CreateVideo",
        "SaveVideo",
    }
    common_nodes_ready = required_common.issubset(object_info)
    i2v_nodes_ready = {"LoadImage", "CLIPVisionLoader", "CLIPVisionEncode", "WanImageToVideo"}.issubset(
        object_info
    )
    fun_camera_nodes_ready = {
        "LoadImage",
        "CLIPVisionLoader",
        "CLIPVisionEncode",
        "WanCameraEmbedding",
        "WanCameraImageToVideo",
    }.issubset(object_info)
    i2v_ready = bool(
        common_nodes_ready and i2v_nodes_ready and wan_i2v and text_encoder and vae and vision
    )
    fun_camera_ready = bool(
        common_nodes_ready
        and fun_camera_nodes_ready
        and wan_fun_camera
        and text_encoder
        and vae
        and vision
    )
    t2v_ready = bool(
        common_nodes_ready
        and "EmptyHunyuanLatentVideo" in object_info
        and wan_t2v
        and text_encoder
        and vae
    )

    backends: list[dict] = []
    if wan_fun_camera:
        backends.append(
            {
                "id": "wan_fun_camera_i2v",
                "mode": "image-to-video",
                "model": wan_fun_camera,
                "ready": fun_camera_ready,
            }
        )
    if wan_i2v:
        backends.append(
            {
                "id": "wan_native_i2v",
                "mode": "image-to-video",
                "model": wan_i2v,
                "ready": i2v_ready,
            }
        )
    if wan_t2v:
        backends.append(
            {
                "id": "wan_native_t2v",
                "mode": "text-to-video",
                "model": wan_t2v,
                "ready": t2v_ready,
            }
        )

    issues: list[str] = []
    if not (wan_i2v or wan_fun_camera):
        issues.append("Nenhum peso Wan image-to-video aparece no UNETLoader.")
    if not vision:
        issues.append("Nenhum modelo CLIP Vision aparece no CLIPVisionLoader.")
    if wan_t2v and not (wan_i2v or wan_fun_camera):
        issues.append(
            "O peso Wan T2V instalado não condiciona o vídeo pelo keyframe; "
            "ele só pode ser usado em diagnóstico explícito de texto-para-vídeo."
        )

    system = stats.get("system", {})
    devices = stats.get("devices", [])
    return {
        "host": host,
        "comfyui_version": system.get("comfyui_version"),
        "python_version": system.get("python_version"),
        "pytorch_version": system.get("pytorch_version"),
        "devices": devices,
        "node_count": len(object_info),
        "models": {
            "unet": unets,
            "clip": clips,
            "vae": vaes,
            "clip_vision": clip_vision,
        },
        "resolved": {
            "wan_i2v": wan_i2v,
            "wan_fun_camera": wan_fun_camera,
            "wan_t2v": wan_t2v,
            "text_encoder": text_encoder,
            "vae": vae,
            "clip_vision": vision,
        },
        "backends": backends,
        "image_to_video_ready": i2v_ready or fun_camera_ready,
        "fun_camera_ready": fun_camera_ready,
        "text_to_video_ready": t2v_ready,
        "issues": issues,
        "_object_info": object_info,
    }


def _multipart_field(name: str, value: str, boundary: str) -> bytes:
    return (
        f"--{boundary}\r\n"
        f'Content-Disposition: form-data; name="{name}"\r\n\r\n'
        f"{value}\r\n"
    ).encode("utf-8")


def upload_input_image(
    host: str,
    image_path: str | Path,
    subfolder: str = "subterra_deluxe",
    overwrite: bool = True,
) -> dict:
    """Upload a keyframe through ComfyUI's native multipart endpoint."""
    image_path = Path(image_path)
    if not image_path.is_file():
        raise FileNotFoundError(image_path)
    boundary = "----SubterraDeluxe" + uuid.uuid4().hex
    mime = mimetypes.guess_type(image_path.name)[0] or "application/octet-stream"
    body = bytearray()
    body.extend(_multipart_field("type", "input", boundary))
    body.extend(_multipart_field("subfolder", subfolder, boundary))
    body.extend(_multipart_field("overwrite", "true" if overwrite else "false", boundary))
    body.extend(
        (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="image"; filename="{image_path.name}"\r\n'
            f"Content-Type: {mime}\r\n\r\n"
        ).encode("utf-8")
    )
    body.extend(image_path.read_bytes())
    body.extend(f"\r\n--{boundary}--\r\n".encode("utf-8"))
    request = urllib.request.Request(
        host.rstrip("/") + "/upload/image",
        data=bytes(body),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            result = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise _http_error(exc) from exc
    if not result.get("name"):
        raise RuntimeError(f"Upload do keyframe não retornou nome de arquivo: {result}")
    return result


def _uploaded_name(record: dict) -> str:
    subfolder = str(record.get("subfolder", "")).replace("\\", "/").strip("/")
    name = str(record["name"]).replace("\\", "/").lstrip("/")
    return str(PurePosixPath(subfolder) / name) if subfolder else name


def _wan_length(frames: int) -> int:
    # Native Wan latent lengths follow 4*n+1.
    return max(9, int(round((max(1, int(frames)) - 1) / 4.0)) * 4 + 1)


def _multiple_of_16(value: int) -> int:
    return max(16, int(round(int(value) / 16.0)) * 16)


def _fun_camera_pose(item: dict) -> tuple[str, float]:
    """Translate common director terms to the native Fun Camera trajectories."""
    description = f"{item.get('camera', '')} {item.get('prompt', '')}".lower()
    mappings = (
        (("pan up", "tilt up"), "Pan Up"),
        (("pan down", "tilt down"), "Pan Down"),
        (("pan left", "truck left"), "Pan Left"),
        (("pan right", "truck right"), "Pan Right"),
        (("zoom out", "dolly out", "pull back"), "Zoom Out"),
        (("zoom in", "dolly in", "push in"), "Zoom In"),
        (("anti clockwise", "counterclockwise"), "Anti Clockwise (ACW)"),
        (("clockwise", "orbit"), "ClockWise (CW)"),
    )
    for terms, pose in mappings:
        if any(term in description for term in terms):
            return pose, 0.65
    return "Static", 1.0


def _common_wan_workflow(item: dict, resolved: dict) -> dict:
    return {
        "37": {
            "class_type": "UNETLoader",
            "inputs": {"unet_name": "", "weight_dtype": "default"},
        },
        "38": {
            "class_type": "CLIPLoader",
            "inputs": {
                "clip_name": resolved["text_encoder"],
                "type": "wan",
                "device": "default",
            },
        },
        "39": {
            "class_type": "VAELoader",
            "inputs": {"vae_name": resolved["vae"]},
        },
        "6": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": item["prompt"], "clip": ["38", 0]},
        },
        "7": {
            "class_type": "CLIPTextEncode",
            "inputs": {"text": item.get("negative_prompt", ""), "clip": ["38", 0]},
        },
        "48": {
            "class_type": "ModelSamplingSD3",
            "inputs": {"model": ["37", 0], "shift": 8.0},
        },
        "3": {
            "class_type": "KSampler",
            "inputs": {
                "model": ["48", 0],
                "seed": int(item["seed"]),
                "steps": 20,
                "cfg": 6.0,
                "sampler_name": "uni_pc",
                "scheduler": "simple",
                "positive": [],
                "negative": [],
                "latent_image": [],
                "denoise": 1.0,
            },
        },
        "8": {
            "class_type": "VAEDecode",
            "inputs": {"samples": ["3", 0], "vae": ["39", 0]},
        },
        "49": {
            "class_type": "CreateVideo",
            "inputs": {"images": ["8", 0], "fps": float(item["fps"])},
        },
        "50": {
            "class_type": "SaveVideo",
            "inputs": {
                "video": ["49", 0],
                "filename_prefix": f"subterra_deluxe/shot_{int(item['shot']):04d}",
                "format": "mp4",
                "codec": "auto",
            },
        },
    }


def build_auto_workflow(
    item: dict,
    discovery: dict,
    uploaded_image: dict | None = None,
    allow_text_to_video: bool = False,
) -> tuple[dict, dict]:
    """Build a concrete API workflow from detected native ComfyUI nodes."""
    resolved = discovery["resolved"]
    workflow = _common_wan_workflow(item, resolved)
    width = _multiple_of_16(int(item["width"]))
    height = _multiple_of_16(int(item["height"]))
    length = _wan_length(int(item["frames"]))

    if discovery.get("fun_camera_ready"):
        if uploaded_image is None:
            raise ValueError("O backend Fun Camera I2V exige upload do keyframe.")
        camera_pose, camera_speed = _fun_camera_pose(item)
        workflow["37"]["inputs"]["unet_name"] = resolved["wan_fun_camera"]
        workflow.update(
            {
                "52": {
                    "class_type": "LoadImage",
                    "inputs": {"image": _uploaded_name(uploaded_image)},
                },
                "53": {
                    "class_type": "CLIPVisionLoader",
                    "inputs": {"clip_name": resolved["clip_vision"]},
                },
                "54": {
                    "class_type": "CLIPVisionEncode",
                    "inputs": {
                        "clip_vision": ["53", 0],
                        "image": ["52", 0],
                        "crop": "none",
                    },
                },
                "55": {
                    "class_type": "WanCameraEmbedding",
                    "inputs": {
                        "camera_pose": camera_pose,
                        "width": width,
                        "height": height,
                        "length": length,
                        "speed": camera_speed,
                        "fx": 0.5,
                        "fy": 0.5,
                        "cx": 0.5,
                        "cy": 0.5,
                    },
                },
                "56": {
                    "class_type": "WanCameraImageToVideo",
                    "inputs": {
                        "positive": ["6", 0],
                        "negative": ["7", 0],
                        "vae": ["39", 0],
                        "width": ["55", 1],
                        "height": ["55", 2],
                        "length": ["55", 3],
                        "batch_size": 1,
                        "clip_vision_output": ["54", 0],
                        "start_image": ["52", 0],
                        "camera_conditions": ["55", 0],
                    },
                },
            }
        )
        workflow["3"]["inputs"].update(
            {"positive": ["56", 0], "negative": ["56", 1], "latent_image": ["56", 2]}
        )
        profile = {
            "id": "wan_fun_camera_i2v",
            "mode": "image-to-video",
            "model": resolved["wan_fun_camera"],
            "width": width,
            "height": height,
            "frames": length,
            "camera_pose": camera_pose,
            "camera_speed": camera_speed,
        }
        return workflow, profile

    if discovery.get("image_to_video_ready"):
        if uploaded_image is None:
            raise ValueError("O backend I2V exige upload do keyframe antes de montar o workflow.")
        workflow["37"]["inputs"]["unet_name"] = resolved["wan_i2v"]
        workflow.update(
            {
                "52": {
                    "class_type": "LoadImage",
                    "inputs": {"image": _uploaded_name(uploaded_image)},
                },
                "53": {
                    "class_type": "CLIPVisionLoader",
                    "inputs": {"clip_name": resolved["clip_vision"]},
                },
                "54": {
                    "class_type": "CLIPVisionEncode",
                    "inputs": {
                        "clip_vision": ["53", 0],
                        "image": ["52", 0],
                        "crop": "center",
                    },
                },
                "55": {
                    "class_type": "WanImageToVideo",
                    "inputs": {
                        "positive": ["6", 0],
                        "negative": ["7", 0],
                        "vae": ["39", 0],
                        "width": width,
                        "height": height,
                        "length": length,
                        "batch_size": 1,
                        "clip_vision_output": ["54", 0],
                        "start_image": ["52", 0],
                    },
                },
            }
        )
        workflow["3"]["inputs"].update(
            {"positive": ["55", 0], "negative": ["55", 1], "latent_image": ["55", 2]}
        )
        profile = {
            "id": "wan_native_i2v",
            "mode": "image-to-video",
            "model": resolved["wan_i2v"],
            "width": width,
            "height": height,
            "frames": length,
        }
        return workflow, profile

    if not (allow_text_to_video and discovery.get("text_to_video_ready")):
        issues = " ".join(discovery.get("issues", []))
        raise RuntimeError(
            "Nenhum backend image-to-video local está pronto. "
            f"{issues} Use --allow-text-to-video somente para um diagnóstico T2V explícito."
        )

    workflow["37"]["inputs"]["unet_name"] = resolved["wan_t2v"]
    workflow["40"] = {
        "class_type": "EmptyHunyuanLatentVideo",
        "inputs": {"width": width, "height": height, "length": length, "batch_size": 1},
    }
    workflow["3"]["inputs"].update(
        {"positive": ["6", 0], "negative": ["7", 0], "latent_image": ["40", 0]}
    )
    profile = {
        "id": "wan_native_t2v",
        "mode": "text-to-video-diagnostic",
        "model": resolved["wan_t2v"],
        "width": width,
        "height": height,
        "frames": length,
        "warning": "O keyframe não condiciona este peso T2V.",
    }
    return workflow, profile


def validate_workflow(
    workflow: dict,
    object_info: dict | None = None,
    allow_placeholders: bool = False,
) -> dict:
    if not isinstance(workflow, dict) or not workflow:
        raise ValueError("Workflow API vazio ou inválido.")
    if "nodes" in workflow and isinstance(workflow.get("nodes"), list):
        raise ValueError(
            "O arquivo selecionado é um workflow de interface, não o formato API. "
            "Use a autoconfiguração do SUBTERRA ou exporte no formato API."
        )
    unresolved: list[str] = []
    missing_nodes: list[str] = []
    for node_id, node in workflow.items():
        if not isinstance(node, dict) or not isinstance(node.get("inputs"), dict):
            raise ValueError(f"Nó {node_id} não possui inputs no formato API.")
        class_type = node.get("class_type")
        if not isinstance(class_type, str):
            raise ValueError(f"Nó {node_id} não possui class_type.")
        if object_info is not None and class_type not in object_info:
            missing_nodes.append(class_type)
        serialized = json.dumps(node, ensure_ascii=False)
        if re.search(r"\{\{[^{}]+\}\}", serialized):
            unresolved.append(str(node_id))
    if unresolved and not allow_placeholders:
        raise ValueError(f"Placeholders não resolvidos nos nós: {', '.join(unresolved)}")
    if missing_nodes:
        raise ValueError(
            "Nós ausentes no ComfyUI instalado: " + ", ".join(sorted(set(missing_nodes)))
        )
    return {"nodes": len(workflow), "class_types": sorted({node["class_type"] for node in workflow.values()})}


def _replace(obj, replacements: dict[str, object]):
    if isinstance(obj, dict):
        return {key: _replace(value, replacements) for key, value in obj.items()}
    if isinstance(obj, list):
        return [_replace(value, replacements) for value in obj]
    if isinstance(obj, str):
        if obj in replacements:
            return replacements[obj]
        for key, value in replacements.items():
            obj = obj.replace(key, str(value))
    return obj


def _replacements(item: dict, input_image: str) -> dict[str, object]:
    return {
        "{{prompt}}": item["prompt"],
        "{{negative_prompt}}": item.get("negative_prompt", ""),
        "{{seed}}": int(item["seed"]),
        "{{width}}": int(item["width"]),
        "{{height}}": int(item["height"]),
        "{{frames}}": int(item["frames"]),
        "{{fps}}": float(item["fps"]),
        "{{duration}}": float(item["duration"]),
        "{{input_image}}": input_image,
        "{{output_prefix}}": Path(item["output_name"]).stem,
        "{{shot}}": int(item["shot"]),
    }


def _queue(prompt: dict, host: str) -> str:
    response = _post_json(host.rstrip("/") + "/prompt", {"prompt": prompt}, 60)
    prompt_id = response.get("prompt_id", "")
    if not prompt_id:
        raise RuntimeError(f"O ComfyUI não retornou prompt_id: {response}")
    return prompt_id


def _file_records(obj) -> list[dict]:
    found: list[dict] = []
    if isinstance(obj, dict):
        if isinstance(obj.get("filename"), str):
            found.append(obj)
        for value in obj.values():
            found.extend(_file_records(value))
    elif isinstance(obj, list):
        for value in obj:
            found.extend(_file_records(value))
    return found


def _download_record(record: dict, host: str, destination: Path) -> Path:
    query = urllib.parse.urlencode(
        {
            "filename": record["filename"],
            "subfolder": record.get("subfolder", ""),
            "type": record.get("type", "output"),
        }
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(host.rstrip("/") + "/view?" + query, timeout=300) as response:
        with destination.open("wb") as output:
            shutil.copyfileobj(response, output)
    return destination


def _normalise_video(source: Path, destination: Path) -> Path:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.suffix.lower() == ".mp4":
        if source.resolve() != destination.resolve():
            shutil.copyfile(source, destination)
        return destination
    subprocess.run(
        [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(source),
            "-c:v",
            "libx264",
            "-crf",
            "18",
            "-preset",
            "medium",
            "-pix_fmt",
            "yuv420p",
            "-an",
            "-movflags",
            "+faststart",
            str(destination),
        ],
        check=True,
    )
    return destination


def probe_video(path: str | Path) -> dict:
    path = Path(path)
    if not path.is_file() or path.stat().st_size <= 0:
        raise RuntimeError(f"Vídeo ausente ou vazio: {path}")
    raw = subprocess.check_output(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=codec_name,width,height,r_frame_rate,avg_frame_rate,nb_frames:format=duration,size",
            "-of",
            "json",
            str(path),
        ],
        text=True,
        encoding="utf-8",
        timeout=60,
    )
    data = json.loads(raw)
    streams = data.get("streams", [])
    if not streams:
        raise RuntimeError(f"FFprobe não encontrou stream de vídeo: {path}")
    return {"path": str(path.resolve()), "stream": streams[0], "format": data.get("format", {})}


def _history_error(history: dict) -> str | None:
    status = history.get("status", {})
    if status.get("status_str") == "error":
        messages = status.get("messages", [])
        return json.dumps(messages[-3:], ensure_ascii=False) if messages else "erro sem detalhes"
    return None


def _wait_for_history(host: str, prompt_id: str, timeout: float) -> dict:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        payload = _read_json(host.rstrip("/") + "/history/" + prompt_id, 30)
        if prompt_id in payload:
            history = payload[prompt_id]
            error = _history_error(history)
            if error:
                raise RuntimeError(f"ComfyUI falhou no prompt {prompt_id}: {error}")
            status = history.get("status", {})
            if status.get("completed") or history.get("outputs"):
                return history
        time.sleep(2)
    raise TimeoutError(f"Tempo esgotado aguardando o prompt {prompt_id}.")


def _select_manifest_items(manifest: dict, shot_ids: Iterable[int] | None) -> list[dict]:
    items = list(manifest.get("shots", []))
    if shot_ids is None:
        return items
    selected = {int(value) for value in shot_ids}
    result = [item for item in items if int(item["shot"]) in selected]
    found = {int(item["shot"]) for item in result}
    missing = selected - found
    if missing:
        formatted = ", ".join(f"{shot:04d}" for shot in sorted(missing))
        raise ValueError(f"Shots não encontrados no manifesto: {formatted}")
    return result


def _public_discovery(discovery: dict | None) -> dict | None:
    if discovery is None:
        return None
    return {key: value for key, value in discovery.items() if key != "_object_info"}


def queue_manifest(
    manifest_path: str | Path,
    workflow_api_path: str | Path,
    host: str = "http://127.0.0.1:8188",
) -> list[str]:
    """Advanced helper: upload inputs and queue all shots without waiting."""
    manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
    workflow = json.loads(Path(workflow_api_path).read_text(encoding="utf-8"))
    validate_workflow(workflow)
    queued: list[str] = []
    for item in manifest["shots"]:
        input_name = ""
        if item.get("input_image"):
            input_name = _uploaded_name(upload_input_image(host, item["input_image"]))
        prompt = _replace(workflow, _replacements(item, input_name))
        validate_workflow(prompt)
        queued.append(_queue(prompt, host))
    return queued


def generate_manifest(
    manifest_path: str | Path,
    workflow_api_path: str | Path | None = None,
    output_dir: str | Path | None = None,
    host: str = "http://127.0.0.1:8188",
    timeout_per_shot: float = 3600,
    progress: Callable[[int, int, str], None] | None = None,
    shot_ids: Iterable[int] | None = None,
    skip_existing: bool = True,
    allow_text_to_video: bool = False,
) -> dict:
    """Generate selected shots, download them, validate them and persist a report.

    With no external workflow, a concrete native workflow is built from
    ``/object_info``.  The default rejects text-only backends so a T2V result is
    never presented as successful keyframe conditioning.
    """
    manifest_path = Path(manifest_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    items = _select_manifest_items(manifest, shot_ids)
    out = Path(output_dir) if output_dir else manifest_path.parent
    out.mkdir(parents=True, exist_ok=True)
    host = host.rstrip("/")

    external_workflow: dict | None = None
    discovery: dict | None = None
    if workflow_api_path:
        external_workflow = json.loads(Path(workflow_api_path).read_text(encoding="utf-8"))
        object_info = _read_json(host + "/object_info", 90)
        validate_workflow(external_workflow, object_info, allow_placeholders=True)
    else:
        discovery = discover_comfyui(host)

    report = {
        "manifest": str(manifest_path.resolve()),
        "host": host,
        "output_dir": str(out.resolve()),
        "workflow_source": str(Path(workflow_api_path).resolve()) if workflow_api_path else "auto",
        "discovery": _public_discovery(discovery),
        "requested_shots": [int(item["shot"]) for item in items],
        "allow_text_to_video": bool(allow_text_to_video),
        "shots": [],
        "downloaded": 0,
        "skipped": 0,
        "failed": 0,
        "total": len(items),
    }
    report_path = out / "comfyui_generation_report.json"
    previous_report: dict = {}
    if report_path.exists():
        try:
            previous_report = json.loads(report_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            previous_report = {}

    def existing_mode(shot: int) -> str | None:
        for previous in previous_report.get("shots", []):
            if int(previous.get("shot", -1)) == shot:
                return previous.get("profile", {}).get("mode")
        return None

    def save_report() -> None:
        report["downloaded"] = sum(bool(row.get("downloaded")) for row in report["shots"])
        report["skipped"] = sum(bool(row.get("skipped")) for row in report["shots"])
        report["failed"] = sum(bool(row.get("error")) for row in report["shots"])
        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")

    total = len(items)
    for index, item in enumerate(items, 1):
        sid = int(item["shot"])
        target = out / item["output_name"]
        row: dict = {"shot": sid, "target": str(target.resolve())}
        shot_started = time.perf_counter()
        try:
            if external_workflow is not None:
                expected_mode = "external-workflow"
            elif discovery.get("image_to_video_ready"):
                expected_mode = "image-to-video"
            elif allow_text_to_video and discovery.get("text_to_video_ready"):
                expected_mode = "text-to-video-diagnostic"
            else:
                # Raise the same detailed capability error used by workflow construction.
                build_auto_workflow(item, discovery, allow_text_to_video=allow_text_to_video)
                raise AssertionError("Autoconfiguração terminou sem selecionar um backend.")

            if skip_existing and target.exists() and existing_mode(sid) == expected_mode:
                row.update({"skipped": True, "downloaded": False, "probe": probe_video(target)})
                row["elapsed_seconds"] = round(time.perf_counter() - shot_started, 3)
                report["shots"].append(row)
                save_report()
                if progress:
                    progress(index, total, f"Shot {sid:04d}: arquivo válido já existente")
                continue

            if progress:
                progress(index - 1, total, f"Preparando shot {sid:04d}")

            uploaded: dict | None = None
            input_path = Path(item["input_image"]) if item.get("input_image") else None
            if external_workflow is not None or discovery.get("image_to_video_ready"):
                if input_path is None or not input_path.is_file():
                    raise RuntimeError(
                        f"Keyframe ausente para o shot {sid:04d}. "
                        "Reextraia o manifesto a partir do filme-base."
                    )
                uploaded = upload_input_image(host, input_path)

            if external_workflow is not None:
                input_name = _uploaded_name(uploaded) if uploaded else ""
                workflow = _replace(external_workflow, _replacements(item, input_name))
                profile = {"id": "external", "mode": "external-workflow"}
            else:
                workflow, profile = build_auto_workflow(
                    item, discovery, uploaded, allow_text_to_video=allow_text_to_video
                )
            validation = validate_workflow(
                workflow, discovery.get("_object_info") if discovery is not None else None
            )
            workflow_path = out / f"shot_{sid:04d}_comfyui_api.json"
            workflow_path.write_text(json.dumps(workflow, indent=2, ensure_ascii=False), encoding="utf-8")
            row.update(
                {
                    "profile": profile,
                    "workflow": str(workflow_path.resolve()),
                    "workflow_validation": validation,
                    "uploaded_input": uploaded,
                }
            )
            if progress:
                progress(index - 1, total, f"Enviando shot {sid:04d}")
            prompt_id = _queue(workflow, host)
            row["prompt_id"] = prompt_id
            history = _wait_for_history(host, prompt_id, timeout_per_shot)
            files = [
                record
                for record in _file_records(history.get("outputs", {}))
                if Path(record.get("filename", "")).suffix.lower() in VIDEO_SUFFIXES
            ]
            if not files:
                raise RuntimeError("O workflow terminou sem arquivo de vídeo detectável.")
            selected = files[-1]
            raw = out / ("_comfy_" + Path(selected["filename"]).name)
            _download_record(selected, host, raw)
            _normalise_video(raw, target)
            if raw.resolve() != target.resolve():
                raw.unlink(missing_ok=True)
            row.update(
                {
                    "downloaded": True,
                    "skipped": False,
                    "comfy_record": selected,
                    "probe": probe_video(target),
                }
            )
            row["elapsed_seconds"] = round(time.perf_counter() - shot_started, 3)
            report["shots"].append(row)
            save_report()
            if progress:
                progress(index, total, f"Shot {sid:04d}: {target.name}")
        except Exception as exc:
            row["error"] = repr(exc)
            row["elapsed_seconds"] = round(time.perf_counter() - shot_started, 3)
            row.setdefault("downloaded", False)
            report["shots"].append(row)
            save_report()
            raise

    save_report()
    return report
