from __future__ import annotations

import json
from collections.abc import Iterable
from pathlib import Path

import cv2
import numpy as np


def _selected_shots(shot_ids: Iterable[int] | None) -> set[int] | None:
    if shot_ids is None:
        return None
    return {int(value) for value in shot_ids}


def _frame_quality(frame: np.ndarray) -> tuple[float, float]:
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    mean_luma = float(gray.mean())
    contrast = float(gray.std())
    bright_detail = float(np.percentile(gray, 90))
    return mean_luma * 0.55 + contrast * 0.30 + bright_detail * 0.15, mean_luma


def _extract_representative_keyframe(
    cap: cv2.VideoCapture,
    start: float,
    end: float,
    destination: Path,
    samples: int = 11,
) -> dict | None:
    """Select a useful in-shot frame instead of blindly taking a fade boundary."""
    start = max(0.0, float(start))
    end = max(start, float(end))
    duration = end - start
    if duration <= 0.05:
        timestamps = [start]
    else:
        # Stay clear of both edit boundaries while sampling enough of the shot
        # to avoid black fades, flashes and transition frames.
        timestamps = np.linspace(
            start + duration * 0.12,
            start + duration * 0.82,
            max(3, int(samples)),
        )
    best: tuple[float, float, float, np.ndarray] | None = None
    for timestamp in timestamps:
        cap.set(cv2.CAP_PROP_POS_MSEC, float(timestamp) * 1000.0)
        ok, frame = cap.read()
        if not ok or frame is None:
            continue
        score, mean_luma = _frame_quality(frame)
        if best is None or score > best[0]:
            best = (score, mean_luma, float(timestamp), frame.copy())
    if best is None:
        return None
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not cv2.imwrite(str(destination), best[3]):
        return None
    return {
        "timestamp": round(best[2], 4),
        "quality_score": round(best[0], 3),
        "mean_luma": round(best[1], 3),
    }


def build_multishot_manifest(
    story_path: str | Path,
    output_dir: str | Path,
    keyframe_video: str | Path | None,
    width: int,
    height: int,
    fps: float,
    backend: str = "auto",
    shot_ids: Iterable[int] | None = None,
    strict_keyframes: bool = False,
) -> Path:
    """Build a reproducible shot manifest and extract available keyframes.

    ``shot_ids`` is primarily useful for a cheap one-shot diagnostic.  The
    default keeps the historical behaviour and exports the complete story.
    When ``strict_keyframes`` is enabled, a missing frame is reported instead
    of leaving a misleading empty ``input_image`` field.
    """
    story_path = Path(story_path)
    if not story_path.exists():
        raise FileNotFoundError(story_path)
    story = json.loads(story_path.read_text(encoding="utf-8"))
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    selected = _selected_shots(shot_ids)

    cap: cv2.VideoCapture | None = None
    video_path: Path | None = None
    if keyframe_video:
        video_path = Path(keyframe_video)
        if not video_path.exists():
            raise FileNotFoundError(video_path)
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            cap.release()
            raise RuntimeError(f"Não foi possível abrir o filme-base: {video_path}")

    manifest = {
        "version": "1.1.3-codex",
        "project_seed": story["seed"],
        "audio": story.get("audio", ""),
        "backend": backend,
        "story": str(story_path.resolve()),
        "keyframe_video": str(video_path.resolve()) if video_path else "",
        "shots": [],
    }
    try:
        for shot in story["shots"]:
            sid = int(shot["shot"])
            if selected is not None and sid not in selected:
                continue
            duration = float(shot["end"]) - float(shot["start"])
            frames = max(9, int(round(duration * fps)))
            keyframe = out / f"shot_{sid:04d}_keyframe.png"
            extracted = keyframe.exists()
            keyframe_meta: dict | None = None
            if cap is not None:
                keyframe_meta = _extract_representative_keyframe(
                    cap, float(shot["start"]), float(shot["end"]), keyframe
                )
                extracted = keyframe_meta is not None
            if strict_keyframes and not extracted:
                raise RuntimeError(
                    f"Não foi possível extrair o keyframe do shot {sid:04d} "
                    f"em {float(shot['start']):.3f}s."
                )

            prompt = str(
                shot.get("ai_prompt")
                or (
                    f"Original cinematic music-film shot. Scene: {shot['scene']}. "
                    f"Role: {shot['role']}. Camera: {shot['camera']}. "
                    f"Visual preset: {shot['style']}. Maintain character identity, "
                    "coherent physical motion, cinematic lighting, no logos, no text artifacts."
                )
            )
            negative_prompt = str(
                shot.get("ai_negative_prompt")
                or (
                    "warped anatomy, duplicate limbs, flicker, unstable face, "
                    "text, watermark, logo"
                )
            )
            item = {
                "shot": sid,
                "start": shot["start"],
                "end": shot["end"],
                "duration": round(duration, 4),
                "width": int(width),
                "height": int(height),
                "fps": float(fps),
                "frames": frames,
                "seed": int(shot["seed"]),
                "prompt": prompt,
                "negative_prompt": negative_prompt,
                "input_image": str(keyframe.resolve()) if extracted else "",
                "output_name": f"shot_{sid:04d}.mp4",
            }
            if keyframe_meta is not None:
                item["keyframe_timestamp"] = keyframe_meta["timestamp"]
                item["keyframe_quality"] = keyframe_meta
            (out / f"shot_{sid:04d}.json").write_text(
                json.dumps(item, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            manifest["shots"].append(item)
    finally:
        if cap is not None:
            cap.release()

    if selected is not None:
        missing = selected - {int(item["shot"]) for item in manifest["shots"]}
        if missing:
            formatted = ", ".join(f"{shot:04d}" for shot in sorted(missing))
            raise ValueError(f"Shots não encontrados no roteiro: {formatted}")

    path = out / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def ensure_manifest_keyframes(
    manifest_path: str | Path,
    keyframe_video: str | Path,
    shot_ids: Iterable[int],
) -> dict:
    """Repair selected keyframes in an existing manifest in-place.

    This preserves a full multi-shot manifest while allowing the safe first
    milestone to operate only on ``shot_0000``.
    """
    manifest_path = Path(manifest_path)
    video_path = Path(keyframe_video)
    if not manifest_path.exists():
        raise FileNotFoundError(manifest_path)
    if not video_path.exists():
        raise FileNotFoundError(video_path)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    selected = _selected_shots(shot_ids) or set()
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        cap.release()
        raise RuntimeError(f"Não foi possível abrir o filme-base: {video_path}")

    repaired: list[dict] = []
    found: set[int] = set()
    try:
        for item in manifest.get("shots", []):
            sid = int(item["shot"])
            if sid not in selected:
                continue
            found.add(sid)
            keyframe = manifest_path.parent / f"shot_{sid:04d}_keyframe.png"
            keyframe_meta = _extract_representative_keyframe(
                cap, float(item["start"]), float(item["end"]), keyframe
            )
            if keyframe_meta is None:
                raise RuntimeError(
                    f"Não foi possível extrair o keyframe do shot {sid:04d} "
                    f"em {float(item['start']):.3f}s."
                )
            item["input_image"] = str(keyframe.resolve())
            item["keyframe_timestamp"] = keyframe_meta["timestamp"]
            item["keyframe_quality"] = keyframe_meta
            shot_json = manifest_path.parent / f"shot_{sid:04d}.json"
            shot_json.write_text(json.dumps(item, indent=2, ensure_ascii=False), encoding="utf-8")
            repaired.append(
                {
                    "shot": sid,
                    "input_image": item["input_image"],
                    "keyframe_timestamp": keyframe_meta["timestamp"],
                    "keyframe_quality": keyframe_meta,
                }
            )
    finally:
        cap.release()

    missing = selected - found
    if missing:
        formatted = ", ".join(f"{shot:04d}" for shot in sorted(missing))
        raise ValueError(f"Shots não encontrados no manifesto: {formatted}")
    manifest["keyframe_video"] = str(video_path.resolve())
    manifest["version"] = "1.1.3-codex"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"manifest": str(manifest_path.resolve()), "keyframe_video": str(video_path.resolve()), "repaired": repaired}
