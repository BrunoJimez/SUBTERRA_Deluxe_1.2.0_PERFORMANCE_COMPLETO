"""Local video model compatibility registry.

Models are not bundled because their weights are very large and have their own
licences. The program generates interoperable manifests and can call ComfyUI.
"""
BACKENDS={
 'ltx_video_q8':{'label':'LTX-Video Q8','vram_gb':8,'status':'recommended','modes':['text-to-video','image-to-video']},
 'framepack':{'label':'FramePack','vram_gb':6,'status':'supported-slow','modes':['image-to-video','long clips']},
 'animatediff':{'label':'AnimateDiff','vram_gb':8,'status':'supported-stylised','modes':['image-to-video','loops']},
 'wan_2_1_1_3b':{'label':'Wan 2.1 1.3B','vram_gb':8.2,'status':'experimental-offload','modes':['text-to-video','image-to-video']},
}
