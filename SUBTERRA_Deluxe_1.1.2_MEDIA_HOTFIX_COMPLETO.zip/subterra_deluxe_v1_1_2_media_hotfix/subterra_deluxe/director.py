from __future__ import annotations

import json
from pathlib import Path
import numpy as np

SCENES = [
    "subterranean_architecture", "powerline_memory", "waveform_city",
    "liquid_chrome", "neon_megacity", "silhouette_club", "monumental_desert",
    "cyber_stage", "signal_cathedral", "character_corridor", "glass_atrium",
    "rain_transit", "ink_apartment", "hologram_plaza", "orbital_ruins",
]

ROLE_SCENES = {
    "intro": ["monumental_desert", "glass_atrium", "powerline_memory", "orbital_ruins"],
    "breakdown": ["ink_apartment", "character_corridor", "glass_atrium", "liquid_chrome"],
    "buildup": ["waveform_city", "signal_cathedral", "rain_transit", "powerline_memory"],
    "drop": ["neon_megacity", "silhouette_club", "cyber_stage", "subterranean_architecture"],
    "climax": ["hologram_plaza", "cyber_stage", "neon_megacity", "signal_cathedral"],
    "outro": ["orbital_ruins", "monumental_desert", "powerline_memory"],
    "development": SCENES,
}

CAMERAS = ["locked", "push", "drift", "orbit", "handheld", "low_angle", "over_shoulder", "crash_zoom"]
TRANSITIONS = ["cut", "dissolve", "blackout", "shape_wipe", "chromatic_whip", "film_burn"]
ACTIONS = ["idle", "walk", "stare", "sing", "dance", "dramatic_turn", "reach", "run", "levitate"]


def make_story(analysis_path: str | Path, output: str | Path, seed: int, edit_density: float,
               style: str, character_count: int = 0) -> dict:
    data = json.loads(Path(analysis_path).read_text(encoding="utf-8"))
    rng = np.random.default_rng(seed)
    bpm = max(60.0, float(data.get("estimated_bpm", 120)))
    beat = 60.0 / bpm
    shots = []
    sid = 0
    last_scene = ""
    for section in data["sections"]:
        a, b = float(section["start"]), float(section["end"])
        role = section.get("role", "development")
        if role in {"drop", "climax"}:
            target = beat * (2.0 + 4.0 * (1 - edit_density))
        elif role == "breakdown":
            target = beat * (8.0 + 8.0 * (1 - edit_density))
        else:
            target = beat * (4.0 + 8.0 * (1 - edit_density))
        count = max(1, int(np.ceil((b - a) / max(0.6, target))))
        cuts = np.linspace(a, b, count + 1)
        for j in range(count):
            pool = ROLE_SCENES.get(role, SCENES)
            scene = str(rng.choice(pool))
            for _ in range(5):
                if scene != last_scene:
                    break
                scene = str(rng.choice(pool))
            last_scene = scene
            visible = []
            if character_count:
                nchar = 2 if role in {"drop", "climax"} and character_count > 1 else 1
                visible = rng.choice(character_count, size=nchar, replace=False).astype(int).tolist()
            blocking = {}
            for k, char_id in enumerate(visible):
                left = 0.32 if k == 0 else 0.68
                travel = float(rng.uniform(-0.10, 0.10))
                blocking[str(char_id)] = {
                    "x_start": round(left, 3), "x_end": round(left + travel, 3),
                    "scale": round(float(rng.uniform(0.78, 1.08)), 3),
                    "depth": round(float(rng.uniform(0.25, 0.75)), 3),
                    "action": str(rng.choice(ACTIONS)),
                    "facing": int(rng.choice([-1, 1])),
                }
            shots.append({
                "shot": sid, "start": round(float(cuts[j]), 4), "end": round(float(cuts[j + 1]), 4),
                "role": role, "scene": scene, "camera": str(rng.choice(CAMERAS)),
                "transition": str(rng.choice(TRANSITIONS)),
                "style": style, "media_mix": round(float(rng.uniform(0.15, 0.85)), 3),
                "character_intensity": round(float(rng.uniform(0.55, 1.0)), 3),
                "visible_characters": visible, "blocking": blocking,
                "seed": int(rng.integers(1, 2**31 - 1)),
            })
            sid += 1
    story = {
        "version": "1.1.0-rebuilt", "seed": int(seed), "audio": data["source"],
        "duration_seconds": data["duration_seconds"], "bpm": data["estimated_bpm"],
        "style": style, "shots": shots,
        "principles": ["SUBTERRA 0.2 audiovisual analysis", "SUBTERRA-CYBERPUNK 0.2 character continuity",
                       "new GPU-first Deluxe renderer", "audio unchanged unless explicitly requested"],
    }
    Path(output).write_text(json.dumps(story, ensure_ascii=False, indent=2), encoding="utf-8")
    return story
