from __future__ import annotations

import math
import cv2
import numpy as np

from .media import cover


class CPUSceneRenderer:
    """Vectorised fallback renderer. No code is sourced from Techno Underground."""
    def __init__(self,width:int,height:int,seed:int):
        self.w=width;self.h=height;self.seed=seed
        yy,xx=np.mgrid[0:height,0:width].astype(np.float32)
        self.x=(xx-width/2)/max(width,height);self.y=(yy-height/2)/max(width,height)
        self.r=np.sqrt(self.x*self.x+self.y*self.y);self.a=np.arctan2(self.y,self.x)

    def render(self,scene:str,t:float,energy:float,impact:float,brightness:float,shot_seed:int,media:np.ndarray|None=None)->np.ndarray:
        fn=getattr(self,'_'+scene,self._subterranean_architecture)
        frame=fn(t,energy,impact,brightness,shot_seed)
        if media is not None:
            mix=.12+.40*energy
            media=cover(media,self.w,self.h)
            frame=cv2.addWeighted(frame,1-mix,media,mix,0)
        return frame

    def _colorize(self,v:np.ndarray,c0:tuple,c1:tuple,c2:tuple)->np.ndarray:
        v=np.clip(v,0,1)[...,None]
        mid=np.clip(v*2,0,1);hi=np.clip((v-.5)*2,0,1)
        a=np.array(c0,np.float32);b=np.array(c1,np.float32);c=np.array(c2,np.float32)
        out=a*(1-mid)+b*mid*(1-hi)+c*hi
        return np.clip(out,0,255).astype(np.uint8)

    def _subterranean_architecture(self,t,e,i,b,s):
        corridor=np.abs(np.sin((self.a+t*.12)*6))+np.abs(np.sin((self.r*18-t*(.6+e*1.8))))
        floor=np.exp(-np.abs(self.y-.18)*18)*(np.sin(self.x*55/(self.y+.75)+t*4)*.5+.5)
        v=np.clip((2.2-corridor)*.35+floor*.55+i*.25,0,1)
        return self._colorize(v,(4,3,8),(35,18,55),(210,70,190))

    def _powerline_memory(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8)
        grad=np.linspace(0,1,self.h)[:,None,None]
        top=np.array((85,25,105));bottom=np.array((5,6,14));frame[:]=np.clip(top*(1-grad)+bottom*grad,0,255)
        horizon=int(self.h*.68);cv2.rectangle(frame,(0,horizon),(self.w,self.h),(5,5,8),-1)
        for k in range(4):
            x=int(self.w*(.16+.24*k+.03*math.sin(t*.13+k)));hh=int(self.h*(.32+.07*(k%2)));y=horizon
            col=(210,210,225);cv2.line(frame,(x-int(hh*.12),y),(x,y-hh),col,2);cv2.line(frame,(x+int(hh*.12),y),(x,y-hh),col,2)
            cv2.line(frame,(x-int(hh*.20),y-int(hh*.58)),(x+int(hh*.20),y-int(hh*.58)),col,2)
            if k<3:
                nx=int(self.w*(.16+.24*(k+1)+.03*math.sin(t*.13+k+1)))
                pts=[]
                for u in np.linspace(0,1,40):
                    px=int(x+(nx-x)*u);py=int(y-hh*.58+math.sin(u*math.pi)*self.h*.05)
                    pts.append((px,py))
                cv2.polylines(frame,[np.array(pts,np.int32)],False,col,1,cv2.LINE_AA)
        return frame

    def _waveform_city(self,t,e,i,b,s):
        v=(np.sin(self.x*38+t*2)+np.sin(self.y*26-t*1.3)+np.sin((self.x+self.y)*18+t*.7))/6+.5
        frame=self._colorize(v,(5,4,14),(25,35,95),(210,80,230))
        skyline=np.zeros_like(frame)
        rng=np.random.default_rng(s)
        for k in range(28):
            x=int(k*self.w/28);bw=max(3,self.w//34);bh=int(self.h*(.08+.35*rng.random())*(.5+.5*e));cv2.rectangle(skyline,(x,self.h-bh),(x+bw,self.h),(20,10,35),-1)
            if k%3==0:cv2.line(skyline,(x+bw//2,self.h-bh),(x+bw//2,self.h-bh-int(self.h*.06)),(220,120,245),1)
        return cv2.addWeighted(frame,.70,skyline,.85,0)

    def _liquid_chrome(self,t,e,i,b,s):
        f=np.sin(self.x*12+np.cos(self.y*9-t)*2+t)+np.cos(self.y*14+np.sin(self.x*8+t)*2-t*.7)
        v=np.clip((f+2)/4,0,1);v=np.power(v,.55)
        frame=self._colorize(v,(4,5,8),(90,105,115),(245,235,225))
        edges=cv2.Canny(cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY),70,150);frame[edges>0]=(210,210,230)
        return frame

    def _neon_megacity(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8);grad=np.linspace(0,1,self.h)[:,None,None]
        frame[:]=np.clip(np.array((110,15,100))*(1-grad)+np.array((5,4,12))*grad,0,255)
        rng=np.random.default_rng(s)
        for k in range(38):
            x=int(k*self.w/38);bw=max(3,int(self.w/42));bh=int(self.h*(.12+.55*rng.random()));col=(int(20+80*rng.random()),int(10+35*rng.random()),int(35+130*rng.random()))
            cv2.rectangle(frame,(x,self.h-bh),(x+bw,self.h),col,-1)
            for y in range(self.h-bh+6,self.h-4,max(7,self.h//40)):cv2.line(frame,(x+2,y),(x+bw-2,y),(180,80,220),1)
        road=np.array([[int(self.w*.42),self.h],[int(self.w*.58),self.h],[int(self.w*.52),int(self.h*.55)],[int(self.w*.48),int(self.h*.55)]],np.int32);cv2.fillConvexPoly(frame,road,(12,8,24))
        return frame

    def _silhouette_club(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8);frame[:]=(28,6,45)
        for k in range(6):
            cx=int(self.w*(.12+.16*k));cy=int(self.h*(.28+.04*math.sin(t*1.3+k)));r=int(self.h*(.12+.03*i));cv2.circle(frame,(cx,cy),r,(100+20*k,20,120+15*k),-1)
        rng=np.random.default_rng(s)
        for k in range(30):
            x=int((k+.5)*self.w/30);base=self.h;hh=int(self.h*(.18+.18*rng.random()+.08*e));cv2.circle(frame,(x,base-hh),max(3,self.w//120),(5,5,10),-1);cv2.line(frame,(x,base-hh+5),(x,base-int(hh*.35)),(5,5,10),max(2,self.w//150));cv2.line(frame,(x,base-int(hh*.7)),(x+int(math.sin(t*2+k)*self.w*.02),base-int(hh*.95)),(5,5,10),max(2,self.w//180))
        return frame

    def _monumental_desert(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8);grad=np.linspace(0,1,self.h)[:,None,None];frame[:]=np.clip(np.array((130,145,165))*(1-grad)+np.array((16,18,25))*grad,0,255)
        horizon=int(self.h*.66);cv2.rectangle(frame,(0,horizon),(self.w,self.h),(25,38,62),-1)
        cx=self.w//2;top=int(self.h*.17);base=horizon;half=int(self.w*.12);poly=np.array([[cx,top],[cx-half,base],[cx+half,base]],np.int32);cv2.fillConvexPoly(frame,poly,(18,24,35));cv2.line(frame,(cx,top),(cx,base),(115,125,135),2)
        sun=(int(self.w*.76),int(self.h*.25));cv2.circle(frame,sun,int(self.h*.055),(180,205,235),-1)
        return frame

    def _cyber_stage(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8);frame[:]=(12,4,20)
        for k in range(7):
            x=int(self.w*(.08+.14*k));cv2.line(frame,(x,0),(self.w//2,self.h),(30+20*k,20,90+18*k),max(1,self.w//250))
        for r in range(1,7):cv2.ellipse(frame,(self.w//2,int(self.h*.65)),(int(self.w*.08*r),int(self.h*.025*r)),0,180,360,(190,35,210),2)
        return frame

    def _signal_cathedral(self,t,e,i,b,s):
        v=np.abs(np.sin(self.a*10+t*.2))*np.exp(-self.r*1.3)+np.abs(np.sin(self.y*22-t*1.5))*.25
        frame=self._colorize(np.clip(v,0,1),(3,4,12),(35,20,80),(190,190,245))
        for k in range(5):
            x=int(self.w*(.18+.16*k));cv2.line(frame,(x,self.h),(self.w//2,int(self.h*.12)),(215,215,235),1)
        return frame

    def _character_corridor(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8);frame[:]=(16,5,16)
        vp=(self.w//2,int(self.h*.43))
        for x in [0,int(self.w*.15),int(self.w*.30),int(self.w*.70),int(self.w*.85),self.w-1]:cv2.line(frame,(x,self.h),vp,(115,30,95),2)
        for y in np.linspace(vp[1],self.h,10):
            span=int((y-vp[1])/(self.h-vp[1])*self.w*.5);cv2.line(frame,(vp[0]-span,int(y)),(vp[0]+span,int(y)),(75,20,65),1)
        return frame

    def _glass_atrium(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8);grad=np.linspace(0,1,self.h)[:,None,None];frame[:]=np.clip(np.array((210,225,232))*(1-grad)+np.array((45,65,75))*grad,0,255)
        for k in range(9):
            x=int(k*self.w/8);cv2.line(frame,(x,0),(int(self.w*.5+(x-self.w*.5)*.28),self.h),(160,185,195),2)
        cv2.rectangle(frame,(int(self.w*.18),int(self.h*.18)),(int(self.w*.82),int(self.h*.78)),(220,230,235),2)
        return frame

    def _rain_transit(self,t,e,i,b,s):
        frame=self._neon_megacity(t,e,i,b,s);rng=np.random.default_rng(s+int(t*24))
        for _ in range(max(80,self.w//8)):
            x=int(rng.integers(0,self.w));y=int(rng.integers(0,self.h));cv2.line(frame,(x,y),(x-4,y+int(self.h*.035)),(170,135,190),1)
        return frame

    def _ink_apartment(self,t,e,i,b,s):
        frame=np.zeros((self.h,self.w,3),np.uint8);frame[:]=(18,14,65);cv2.rectangle(frame,(int(self.w*.08),int(self.h*.08)),(int(self.w*.92),int(self.h*.92)),(30,25,95),-1)
        cv2.rectangle(frame,(int(self.w*.53),int(self.h*.14)),(int(self.w*.86),int(self.h*.70)),(5,5,12),-1)
        for k in range(10):cv2.line(frame,(0,int(k*self.h/10)),(self.w,int((k+.25)*self.h/10)),(35,25,105),1)
        return frame

    def _hologram_plaza(self,t,e,i,b,s):
        frame=self._neon_megacity(t,e,i,b,s);cx,cy=int(self.w*.65),int(self.h*.42);r=int(self.h*.24);overlay=np.zeros_like(frame);cv2.ellipse(overlay,(cx,cy),(int(r*.7),r),0,0,360,(220,75,235),-1);cv2.circle(overlay,(cx,cy-r//3),int(r*.22),(255,145,245),-1);frame=cv2.addWeighted(frame,.78,cv2.GaussianBlur(overlay,(0,0),5),.55,0)
        return frame

    def _orbital_ruins(self,t,e,i,b,s):
        stars=np.zeros((self.h,self.w,3),np.uint8);rng=np.random.default_rng(s)
        pts=rng.integers([0,0],[self.w,self.h],size=(max(80,self.w//4),2));stars[pts[:,1],pts[:,0]]=(190,195,220)
        planet=np.zeros_like(stars);cv2.circle(planet,(int(self.w*.72),int(self.h*.42)),int(self.h*.24),(40,55,90),-1);cv2.ellipse(planet,(int(self.w*.72),int(self.h*.42)),(int(self.h*.42),int(self.h*.07)),-12,0,360,(150,120,115),3)
        cv2.rectangle(planet,(int(self.w*.12),int(self.h*.62)),(int(self.w*.42),int(self.h*.69)),(25,30,45),-1)
        return cv2.add(stars,planet)
