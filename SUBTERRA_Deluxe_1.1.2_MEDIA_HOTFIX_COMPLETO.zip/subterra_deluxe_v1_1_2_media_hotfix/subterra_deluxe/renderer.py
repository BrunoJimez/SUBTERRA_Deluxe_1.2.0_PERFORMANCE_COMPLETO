from __future__ import annotations

import json
import math
import os
import subprocess
import time
from pathlib import Path
from typing import Callable

import cv2
import numpy as np

from .audio_mux import resolve_encoder, video_writer_cmd, mux_audio
from .config import DeluxeConfig, QUALITY_PRESETS
from .features import FeatureStream
from .media import MediaPool, CharacterSpec, CharacterSprite, alpha_composite
from .scene_cpu import CPUSceneRenderer
from .styles import StyleState, apply_style, STYLE_SPECS


class DeluxeRenderer:
    def __init__(self,cfg:DeluxeConfig,features_path:str|Path,story_path:str|Path,
                 media_paths:list[str]|None=None,characters:list[CharacterSpec]|None=None):
        self.cfg=cfg;cfg.validate();self.features=FeatureStream(features_path)
        self.story=json.loads(Path(story_path).read_text(encoding='utf-8'))
        self.shots=self.story['shots'];self.duration=float(self.story['duration_seconds'])
        q=QUALITY_PRESETS.get(cfg.quality,QUALITY_PRESETS['deluxe'])
        scale=cfg.internal_scale*q['scale'];self.iw=max(64,int(round(cfg.width*scale/2)*2));self.ih=max(64,int(round(cfg.height*scale/2)*2))
        self.media=MediaPool(media_paths or [],self.iw,self.ih)
        self.characters=[CharacterSprite(c) for c in (characters or [])]
        self.style_state=StyleState();self.active_style=cfg.style;self.rng=np.random.default_rng(cfg.seed)
        self.renderer_name='CPU vectorised fallback';self.base=None
        self.gpu_requested=bool(cfg.use_gpu);self.gpu_active=False;self.gpu_error=None
        if cfg.use_gpu:
            try:
                from .gpu_engine import GPUSceneRenderer
                candidate=GPUSceneRenderer(self.iw,self.ih,cfg.seed)
                candidate.self_test()
                self.base=candidate;self.gpu_active=True
                self.renderer_name='GPU '+candidate.renderer_name
            except Exception as exc:
                self.gpu_error=repr(exc)
                try:candidate.close()
                except Exception:pass
        if self.base is None:self.base=CPUSceneRenderer(self.iw,self.ih,cfg.seed)
        self.last=np.zeros((self.ih,self.iw,3),np.uint8)

    def shot_at(self,t:float)->dict:
        lo,hi=0,len(self.shots)-1
        while lo<=hi:
            mid=(lo+hi)//2;s=self.shots[mid]
            if t<float(s['start']):hi=mid-1
            elif t>=float(s['end']):lo=mid+1
            else:return s
        return self.shots[min(max(lo,0),len(self.shots)-1)]

    def _camera(self,frame:np.ndarray,mode:str,t:float,local:float,impact:float,seed:int)->np.ndarray:
        h,w=frame.shape[:2];cx,cy=w/2,h/2
        if mode=='locked':return frame
        zoom=1.0;angle=0;dx=dy=0
        if mode=='push':zoom=1.0+.035*local
        elif mode=='drift':dx=math.sin(t*.25+seed)*w*.025;dy=math.cos(t*.19+seed)*h*.018
        elif mode=='orbit':angle=math.sin(t*.22+seed)*2.2;zoom=1.025
        elif mode=='handheld':dx=math.sin(t*7.3+seed)*w*.006*(.3+impact);dy=math.cos(t*9.1+seed)*h*.005*(.3+impact);angle=math.sin(t*6.1)*.6
        elif mode=='low_angle':dy=h*.04;zoom=1.06
        elif mode=='over_shoulder':dx=w*.04;zoom=1.10
        elif mode=='crash_zoom':zoom=1.0+.18*impact
        m=cv2.getRotationMatrix2D((cx,cy),angle,zoom);m[:,2]+=np.array([dx,dy])
        return cv2.warpAffine(frame,m,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT)

    def _characters(self,frame:np.ndarray,shot:dict,t:float,impact:float)->np.ndarray:
        if not self.characters:return frame
        local=t-float(shot['start']);dur=max(.001,float(shot['end'])-float(shot['start']));p=np.clip(local/dur,0,1)
        blocking=shot.get('blocking',{})
        # An explicitly empty list is meaningful for narrative shots where the
        # supplied references should affect the environment but no character
        # sprite should be composited. Older stories without the field retain
        # the original automatic-character behaviour.
        if 'visible_characters' in shot:
            visible=shot.get('visible_characters') or []
        else:
            visible=[int(shot['shot'])%len(self.characters)]
        for idx in sorted(visible,key=lambda x:blocking.get(str(x),{}).get('depth',.5),reverse=True):
            if idx>=len(self.characters):continue
            b=blocking.get(str(idx),{});x0=float(b.get('x_start',.5));x1=float(b.get('x_end',x0));x=int((x0+(x1-x0)*p)*self.iw)
            depth=float(b.get('depth',.5));scale=float(b.get('scale',1));height=int(self.ih*(.50+.24*(1-depth))*scale*self.cfg.character_strength)
            src,alpha=self.characters[idx].render(height,t,impact,str(b.get('action','idle')),int(b.get('facing',1)))
            y=int(self.ih*.90)-src.shape[0];px=x-src.shape[1]//2
            shadow=cv2.GaussianBlur(alpha,(0,0),max(2,self.ih*.008));alpha_composite(frame,np.zeros_like(src),(shadow*.30).astype(np.uint8),px+int(self.iw*.01),y+int(self.ih*.01))
            alpha_composite(frame,src,alpha,px,y)
        return frame

    def _transition(self,frame:np.ndarray,shot:dict,local:float)->np.ndarray:
        dur=min(.5,max(.12,(float(shot['end'])-float(shot['start']))*.2));p=float(np.clip(local/dur,0,1));kind=shot.get('transition','cut')
        if p>=1 or kind=='cut':return frame
        if kind=='dissolve':return cv2.addWeighted(frame,p,self.last,1-p,0)
        if kind=='blackout':return (frame.astype(np.float32)*p).astype(np.uint8)
        if kind=='shape_wipe':
            yy,xx=np.ogrid[:self.ih,:self.iw];r=np.sqrt((xx-self.iw/2)**2+(yy-self.ih/2)**2);mask=(r<math.hypot(self.iw,self.ih)*p)[...,None];return np.where(mask,frame,self.last).astype(np.uint8)
        if kind=='chromatic_whip':
            shift=int((1-p)*self.iw*.55);a=np.roll(frame,shift,1);b=np.roll(self.last,shift-self.iw,1);out=cv2.addWeighted(a,p,b,1-p,0);bb,gg,rr=cv2.split(out);return cv2.merge([np.roll(bb,3,1),gg,np.roll(rr,-3,1)])
        if kind=='film_burn':
            burn=np.full_like(frame,(35,95,235));return cv2.addWeighted(frame,p,burn,(1-p)*.65,0)
        return frame

    def frame(self,t:float,frame_no:int)->np.ndarray:
        shot=self.shot_at(t);energy=self.features.value('energy',t);impact=max(self.features.value('impact',t),self.features.pulse(t));bright=self.features.value('brightness',t)
        media=self.media.get(int(shot['shot']),t)
        try:
            frame=self.base.render(shot['scene'],t,energy,impact,bright,int(shot['seed']),media if self.cfg.media_strength>0 else None)
        except Exception as exc:
            if not self.gpu_active:raise
            # Uma falha específica do driver não destrói o trabalho. O relatório
            # registra o motivo e o filme continua no fallback CPU.
            self.gpu_error=repr(exc)
            try:self.base.close()
            except Exception:pass
            self.base=CPUSceneRenderer(self.iw,self.ih,self.cfg.seed)
            self.gpu_active=False
            self.renderer_name='CPU vectorised fallback após falha GPU'
            frame=self.base.render(shot['scene'],t,energy,impact,bright,int(shot['seed']),media if self.cfg.media_strength>0 else None)
        frame=self._characters(frame,shot,t,impact)
        local=t-float(shot['start']);frame=self._camera(frame,shot.get('camera','locked'),t,local,impact,int(shot['seed']))
        style_name=str(shot.get('style') or self.cfg.style)
        if style_name not in STYLE_SPECS:style_name=self.cfg.style
        if style_name!=self.active_style:
            self.style_state=StyleState();self.active_style=style_name
        frame=apply_style(frame,style_name,self.cfg.style_strength,self.style_state,t,frame_no,impact,self.cfg.seed)
        frame=self._transition(frame,shot,local)
        self.last=frame.copy()
        if (self.iw,self.ih)!=(self.cfg.width,self.cfg.height):frame=cv2.resize(frame,(self.cfg.width,self.cfg.height),interpolation=cv2.INTER_LANCZOS4)
        return frame

    def render(self,output:str|Path,audio:str|Path|None=None,progress:Callable[[int,int],None]|None=None)->dict:
        out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
        silent=out.with_name(out.stem+'__silent'+out.suffix)
        encoder=resolve_encoder(self.cfg.encoder,silent)
        cmd=video_writer_cmd(silent,self.cfg.width,self.cfg.height,self.cfg.fps,encoder,self.cfg.crf,self.cfg.ffmpeg_preset)
        proc=subprocess.Popen(cmd,stdin=subprocess.PIPE)
        seconds=self.cfg.preview_seconds if self.cfg.preview_seconds>0 else self.duration
        total=max(1,int(round(seconds*self.cfg.fps)))
        start=time.perf_counter()
        try:
            assert proc.stdin is not None
            for i in range(total):
                t=i/self.cfg.fps;fr=self.frame(t,i);proc.stdin.write(np.ascontiguousarray(fr).tobytes())
                if progress and (i%max(1,total//100)==0 or i==total-1):progress(i+1,total)
        finally:
            if proc.stdin:proc.stdin.close()
            code=proc.wait()
            self.close()
        if code!=0:raise RuntimeError(f'FFmpeg terminou com código {code}')
        if audio:mux_audio(silent,audio,out,self.cfg.audio_mode);silent.unlink(missing_ok=True)
        else:silent.replace(out)
        elapsed=time.perf_counter()-start
        report={'output':str(out.resolve()),'frames':total,'seconds':seconds,'elapsed_seconds':round(elapsed,3),'fps_render':round(total/max(elapsed,.001),2),'renderer':self.renderer_name,'gpu_requested':self.gpu_requested,'gpu_active_at_finish':self.gpu_active,'gpu_error':self.gpu_error,'encoder':encoder,'style':self.cfg.style,'styles_used':sorted({str(shot.get('style') or self.cfg.style) for shot in self.shots}),'seed':self.cfg.seed,'audio_mode':self.cfg.audio_mode,'audio_filters_applied':self.cfg.audio_mode!='preserve'}
        out.with_suffix('.render_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
        return report

    def close(self):
        self.media.close()
        try:self.base.close()
        except Exception:pass
