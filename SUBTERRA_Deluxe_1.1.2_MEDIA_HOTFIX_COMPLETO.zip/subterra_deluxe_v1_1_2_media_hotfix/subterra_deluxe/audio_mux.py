from __future__ import annotations

import platform
import shutil
import subprocess
from pathlib import Path


def ffmpeg_encoders() -> str:
    if not shutil.which('ffmpeg'):
        return ''
    try:
        return subprocess.check_output(['ffmpeg','-hide_banner','-encoders'],stderr=subprocess.STDOUT,text=True,timeout=15)
    except Exception:
        return ''


def resolve_encoder(requested: str, output: Path) -> str:
    if output.suffix.lower()=='.avi': return 'mpeg4'
    if requested!='auto': return requested
    enc=ffmpeg_encoders()
    # NVIDIA is preferred only when actually available.
    if shutil.which('nvidia-smi') and 'h264_nvenc' in enc: return 'h264_nvenc'
    if platform.system()=='Windows' and 'h264_qsv' in enc: return 'h264_qsv'
    return 'libx264'


def video_writer_cmd(output: Path, width:int, height:int, fps:float, encoder:str, crf:int, preset:str)->list[str]:
    cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','bgr24','-s',f'{width}x{height}','-r',str(fps),'-i','-','-an']
    if encoder=='h264_nvenc': cmd += ['-c:v','h264_nvenc','-preset',preset if preset.startswith('p') else 'p5','-cq',str(crf),'-pix_fmt','yuv420p']
    elif encoder=='hevc_nvenc': cmd += ['-c:v','hevc_nvenc','-preset',preset if preset.startswith('p') else 'p5','-cq',str(crf),'-pix_fmt','yuv420p']
    elif encoder=='av1_nvenc': cmd += ['-c:v','av1_nvenc','-preset',preset if preset.startswith('p') else 'p5','-cq',str(crf),'-pix_fmt','yuv420p']
    elif encoder=='mpeg4': cmd += ['-c:v','mpeg4','-q:v','3']
    else: cmd += ['-c:v','libx264','-preset',preset if not preset.startswith('p') else 'medium','-crf',str(crf),'-pix_fmt','yuv420p']
    cmd += [str(output)]
    return cmd


def mux_audio(video_silent: str|Path, audio: str|Path, output: str|Path, mode: str='preserve') -> Path:
    """Mux audio. `preserve` means no EQ/compression/loudness filters.

    MP4 requires a compatible codec, so source audio is transparently encoded to
    high-bitrate AAC but its samples are not equalised, compressed or limited.
    """
    v=Path(video_silent);a=Path(audio);out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
    cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(v),'-i',str(a),'-map','0:v:0','-map','1:a:0','-c:v','copy']
    suffix=out.suffix.lower()
    if mode=='preserve':
        if suffix=='.mkv': cmd += ['-c:a','flac']
        else: cmd += ['-c:a','aac','-b:a','320k']
    elif mode=='streaming': cmd += ['-af','loudnorm=I=-14:TP=-1.0:LRA=11','-c:a','aac','-b:a','320k']
    elif mode=='cinema': cmd += ['-af','highpass=f=25,lowpass=f=19000,loudnorm=I=-18:TP=-1.0:LRA=14','-c:a','aac','-b:a','320k']
    elif mode=='club': cmd += ['-af','highpass=f=25,loudnorm=I=-9:TP=-0.8:LRA=7','-c:a','aac','-b:a','320k']
    else: raise ValueError(f'Modo de áudio desconhecido: {mode}')
    cmd += ['-shortest','-movflags','+faststart',str(out)]
    subprocess.run(cmd,check=True)
    return out
