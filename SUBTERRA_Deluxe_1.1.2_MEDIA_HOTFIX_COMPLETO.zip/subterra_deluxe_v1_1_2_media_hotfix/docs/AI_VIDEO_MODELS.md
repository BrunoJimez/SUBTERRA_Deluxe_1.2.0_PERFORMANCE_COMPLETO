# Modelos locais de vídeo e compatibilidade

O SUBTERRA Deluxe não inclui pesos de modelos. Ele cria um roteiro musical multi-shot, keyframes, prompts, seeds e duração; o ComfyUI ou outro backend gera apenas os planos selecionados.

## Registro interno

| Backend | Situação na RTX 4060 8 GB | Uso |
|---|---|---|
| `ltx_video_q8` | recomendado | texto/imagem para vídeo curto |
| `framepack` | suportado, lento | imagem para vídeo e planos longos |
| `animatediff` | suportado, estilizado | loops, animação gráfica e personagens |
| `wan_2_1_1_3b` | experimental com offload | texto/imagem para vídeo em resolução moderada |

## Estratégia

- gerar clipes em 640 × 360, 768 × 432 ou 854 × 480;
- usar 24 fps e poucos segundos por plano;
- preservar seed e keyframe;
- gerar apenas planos de destaque;
- manter o filme procedural como fallback;
- montar e ampliar no SUBTERRA.

## Seedance musical

O objetivo não é copiar um modelo proprietário. O Deluxe implementa uma lógica semelhante de produção musical multimodal:

1. música, roteiro, imagens, vídeos e personagens entram no projeto;
2. análise musical cria estrutura e arco;
3. direção cria planos independentes;
4. cada plano recebe prompt, seed, duração e keyframe;
5. um modelo local gera os clipes;
6. o montador recompõe o filme completo com o áudio original.

## Observação de licenças

Antes de uso comercial, verifique a licença do código, dos pesos e de quaisquer LoRAs ou custom nodes. O SUBTERRA não altera nem amplia os direitos concedidos por cada modelo.
