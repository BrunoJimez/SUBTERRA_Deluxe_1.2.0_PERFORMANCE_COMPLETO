# Arquitetura de velocidade

## Gargalo das versões anteriores

O custo elevado vinha principalmente de operações por quadro em CPU: filtros bilaterais, Canny, posterização, deformações, recortes, composição e abertura repetida de arquivos. Em vídeos longos, qualquer operação de dezenas de milissegundos é multiplicada por milhares de quadros.

## Novo caminho rápido

1. A música é analisada uma vez e o resultado é salvo em `analysis.json` e `features.npz`.
2. O roteiro é criado antes do render.
3. Somente o catálogo de cenas necessário é usado.
4. O contexto OpenGL permanece ativo durante todo o filme.
5. Os shaders recebem tempo, energia, impacto, brilho, seed e mídia como uniforms/texturas.
6. Imagens são pré-redimensionadas; vídeos mantêm decodificador persistente.
7. O quadro final é enviado diretamente ao stdin do FFmpeg.
8. O FFmpeg codifica com NVENC quando disponível.
9. O áudio é incorporado uma única vez no fim.

## Perfis

| Perfil | Escala interna | Finalidade |
|---|---:|---|
| `preview` | 0,50 | testes rápidos |
| `fast` | 0,75 | produção rápida |
| `deluxe` | 1,00 | render recomendado |
| `master` | 1,15 | supersampling moderado |

## Fallback CPU

Se o ModernGL não criar contexto, o programa utiliza um renderer NumPy/OpenCV vetorizado. Ele mantém funcionalidade, mas não representa o desempenho esperado da RTX 4060.

## Medição no ambiente de validação

O teste de seis segundos em 640 × 360 e 24 fps, usando fallback CPU, produziu 144 quadros a aproximadamente 65,86 quadros de render por segundo na última execução. Esse valor não deve ser extrapolado diretamente para 1080p ou para a RTX 4060.

## Benchmark correto no computador do usuário

Execute `BENCHMARK_RTX4060.bat`. O teste:

- gera áudio sintético reprodutível;
- usa seed `1223951587`;
- renderiza 20 segundos;
- usa 1920 × 1080, 30 fps e qualidade `deluxe`;
- registra o renderer usado, encoder, tempo e FPS em `benchmark_output/benchmark_report.json`.

Para comparar:

```powershell
python tests\benchmark_rtx4060.py --quality fast
python tests\benchmark_rtx4060.py --quality deluxe
python tests\benchmark_rtx4060.py --quality master
python tests\benchmark_rtx4060.py --cpu
```
