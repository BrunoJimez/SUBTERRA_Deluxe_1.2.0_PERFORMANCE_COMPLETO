# Estilos e paletas

Os materiais do arquivo de referências foram extraídos, amostrados e medidos. A análise incluiu brilho, contraste, saturação, densidade de bordas e cores médias. Esses números foram usados como referência, mas cada preset é autoral e não reutiliza LUT proprietária.

## Estrutura obrigatória de um preset

Todo estilo possui:

1. **Cor:** matriz 3×3, lift, gamma, gain, contraste e saturação.
2. **Imagem:** bloom, grão, vinheta, posterização, aberração e/ou tratamento específico.
3. **Tempo:** hold, ghosting, smear, interlace, stutter ou cadence.
4. **Direção:** overlay, tipografia, arquitetura, chuva, linhas, código, letterbox ou outro operador composicional.

## Presets

| Preset | Identidade principal |
|---|---|
| `clean_deluxe` | acabamento neutro e leve |
| `nolan_odisseia` | monumental, baixo croma, halation, letterbox e espaço negativo |
| `mitsubishi_evo_1999_camcorder` | campos entrelaçados, bleed cromático, REC e tracking |
| `trance_classics_late_90s` | bloom, starburst, ghosting e magenta/ciano |
| `unrealistic_hacking` | grid, código, stutter e verde de terminal |
| `cold_corporate_glass` | vidro, diagonais arquitetônicas e ciano frio |
| `yokohama_9pm` | chuva, reflexos, neon e trilhas temporais |
| `gen_x_soft_club` | difusão suave, hold e tons pastel noturnos |
| `go_death` | contraste extremo e linguagem gráfica agressiva |
| `aesthetic_archive` | arquivo, poeira, cor envelhecida e hold |
| `junkieconcept` | xerox, preto e branco, ruído e ruptura |
| `dark_deco` | geometria art déco escura e linhas douradas |
| `samurai_graphic_minimal` | silhuetas, poucos níveis tonais e animação limitada a 12 fps |
| `sunburst` | raios gráficos, cor quente e pulso radial |
| `allure_of_night` | noite verde-violeta e persistência lenta |
| `graphicdesign` | grid, cartaz, alto contraste e tipografia de movimento |
| `legacy_matrix` | código verde e eco digital |
| `night_vibe` | azul profundo, grão e ghosting |
| `life_good` | arquivo cotidiano, date stamp e contraste de compacta |
| `vibes_2006` | câmera digital, contador, stutter e saturação do período |
| `urban_ink_band` | contorno de tinta, silhueta e vermelho/preto |
| `poster_marketing_90s_00s` | blocos gráficos, texto e posterização |
| `frutiger_aero` | ciano/verde, brilho limpo e bolhas |
| `desire_machine` | mecânico, cinza industrial e pulso temporal |
| `staglieno_cemetery` | pedra, veios, verde musgo e atmosfera funerária |
| `scp_zxckfair` | feed anômalo, scanline, moldura e dropouts |
| `neon_graphic_grit` | vermelho-magenta, tinta, halftone e ação cyberpunk |
| `future_noir_cel` | cel shading, bordas limpas, violeta e laranja |

## Prova de distinção

O teste processa o mesmo quadro por todos os 28 presets:

- 28 hashes diferentes;
- diferença média mínima de 10,57 níveis RGB em relação ao `clean_deluxe`;
- métricas cromáticas e de borda registradas em `tests/_validation/style_metrics.json`;
- vídeo comparativo `subterra_deluxe_style_comparison.mp4`.

A distinção visual não é garantida apenas pelo nome do menu; ela é verificada automaticamente.
