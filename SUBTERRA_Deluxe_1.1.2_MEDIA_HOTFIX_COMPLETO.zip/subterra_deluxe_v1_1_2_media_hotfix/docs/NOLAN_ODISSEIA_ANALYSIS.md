# Análise do material `A_Odisseia`

## Dados técnicos

- resolução: 1920 × 1080;
- cadência: 24 fps;
- codec de vídeo: H.264;
- áudio: AAC;
- duração: aproximadamente 108,53 segundos.

## Amostragem visual

Foram amostrados 28 quadros em intervalos de quatro segundos. Médias aproximadas:

- brilho normalizado: 0,118;
- contraste normalizado: 0,117;
- saturação normalizada: 0,215;
- fração de pixels abaixo de 40/255: 76,5%;
- densidade de bordas: 0,008.

Os números indicam imagem majoritariamente escura, baixa saturação, superfícies amplas e pouca fragmentação gráfica.

## Princípios observados

- escala monumental;
- figuras pequenas diante do ambiente;
- espaço negativo;
- luz direcional e localizada;
- preto, carvão, areia, pedra e bronze;
- fogo e azul frio como acentos, não como preenchimento constante;
- câmera mais ponderada;
- transições menos frequentes;
- halation e flare horizontal controlados;
- letterbox cinematográfico.

## Implementação autoral

O preset `nolan_odisseia` aplica:

- matriz cromática própria;
- saturação 0,70;
- contraste 1,25;
- lift negativo;
- gamma 0,94;
- vinheta 0,28;
- grão 0,15;
- bloom/halation controlados;
- letterbox de 10,5% da altura;
- baixa aberração cromática;
- direção monumental no seletor de cenas.

Ele não reutiliza quadros, LUTs ou ativos do trailer. O nome identifica um preset de estudo inspirado em princípios cinematográficos do material fornecido.
