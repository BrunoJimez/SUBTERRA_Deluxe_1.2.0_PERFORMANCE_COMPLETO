# Instalação e uso da IA local

## 1. ComfyUI

Instale o ComfyUI Desktop ou Portable para Windows/NVIDIA. Confirme no navegador que o endereço abaixo responde:

```text
http://127.0.0.1:8188
```

## 2. Modelo e workflow

Instale um modelo de vídeo compatível e valide seu workflow dentro do próprio ComfyUI. Exporte o workflow em **formato API**, não apenas o JSON visual do canvas.

O workflow deve conter placeholders como valores completos ou trechos de texto:

```text
{{prompt}}
{{negative_prompt}}
{{seed}}
{{width}}
{{height}}
{{frames}}
{{fps}}
{{duration}}
{{input_image}}
{{output_prefix}}
{{shot}}
```

O nó de saída precisa salvar um arquivo de vídeo detectável pelo histórico do ComfyUI: MP4, WebM, MOV ou GIF.

## 3. Painel Deluxe

Após renderizar um filme-base:

1. abra a aba **IA local**;
2. escolha a pasta dos planos;
3. clique em **1 · Exportar manifesto**;
4. selecione o workflow API;
5. teste a conexão;
6. clique em **2 · Gerar e baixar clipes IA**;
7. clique em **3 · Montar filme híbrido**.

## Campos

- **Pasta dos planos IA:** keyframes, JSONs e clipes baixados.
- **Manifesto IA:** `manifest.json` do projeto.
- **Workflow ComfyUI API:** JSON exportado pela opção API.
- **Filme-base:** render procedural do mesmo projeto.
- **Áudio master:** opcional; se vazio, usa o áudio do filme-base.
- **Filme híbrido final:** arquivo final.
- **Servidor:** normalmente `http://127.0.0.1:8188`.

## Fallback

A montagem nunca exige que todos os planos estejam prontos. Para cada clipe ausente, o programa recorta a mesma faixa temporal do filme-base. O relatório final informa quantos planos vieram da IA e quantos usaram fallback.

## Diagnóstico

- conexão recusada: ComfyUI fechado ou porta diferente;
- workflow termina sem vídeo: nó de saída não expõe arquivo pelo histórico;
- falta de VRAM: reduza resolução, frames e duração;
- rosto instável: use keyframe mais limpo, prompt literal e plano mais curto;
- clipe não encontrado: confirme prefixo `shot_XXXX` ou use o download automático do painel.
