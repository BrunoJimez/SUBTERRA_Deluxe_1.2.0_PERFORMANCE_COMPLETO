# Auditoria da reconstrução

## Motivo

O Deluxe 1.0 foi rejeitado porque reutilizava de forma excessiva a estrutura do programa Techno Underground analisado e porque os presets visuais se limitavam, em grande parte, a variações superficiais sobre as mesmas cenas. Esta reconstrução corrige os dois problemas na origem.

## Base legítima

A distribuição usa como patrimônio técnico do projeto:

- SUBTERRA 0.2: análise audiovisual, filme abstrato, mídia, filtros e exportação;
- SUBTERRA-CYBERPUNK 0.2: personagens, rig 2.5D, continuidade, câmera e ponte I2V.

Os dois programas permanecem disponíveis em `engines/` e podem ser executados separadamente.

## Uso do programa analisado

O código do Techno Underground foi estudado apenas para reconhecer princípios gerais e públicos de engenharia:

- contexto OpenGL persistente;
- shaders compilados antes do loop;
- decodificadores de mídia mantidos abertos;
- ausência de PNG intermediário por quadro;
- pipe de bytes para FFmpeg;
- encode por hardware;
- cache de análises.

Esses princípios foram reimplementados no contexto do SUBTERRA. O novo motor não importa módulos, cenas ou shaders do programa de referência.

## Auditoria automática

O teste percorreu os arquivos Python do novo núcleo e os comparou com os arquivos Python extraídos do programa analisado.

Resultado:

- arquivos novos analisados: 17;
- arquivos de referência analisados: 33;
- hashes completos idênticos: 0;
- pares com similaridade textual superior a 0,70: 0.

O resultado detalhado está em `AUDIT_ORIGINALITY.json` e `tests/_validation/originality_audit.json`.

## Diferença arquitetural

O novo sistema não reproduz as oito cenas do programa analisado. Possui um catálogo próprio de 15 cenas, um diretor próprio, um pipeline de estilo temporal e espacial, integração de personagens, preservação dos motores anteriores e montagem multi-shot com IA.
