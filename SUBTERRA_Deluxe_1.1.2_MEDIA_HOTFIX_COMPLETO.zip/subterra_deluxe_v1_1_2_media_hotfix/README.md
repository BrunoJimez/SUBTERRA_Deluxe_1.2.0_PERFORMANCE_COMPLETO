# SUBTERRA Deluxe 1.1.2 — reconstruído · hotfix de composição de mídia

Motor musical para criação de filmes techno/cyberpunk, construído sobre as bases funcionais do **SUBTERRA 0.2** e do **SUBTERRA-CYBERPUNK 0.2**.

Esta distribuição substitui integralmente o Deluxe 1.0 rejeitado. O código do novo núcleo foi escrito de forma independente. O projeto Techno Underground fornecido para estudo foi usado apenas para identificar princípios gerais de desempenho; seus módulos e shaders não foram incorporados.


## Hotfix de mídia 1.1.2

Esta revisão corrige o erro OpenCV `(-209:Sizes of input arguments do not match)` observado ao iniciar o render com determinadas imagens/vídeos de base. A causa era um arredondamento por truncamento na rotina `cover()`: algumas proporções podiam produzir um quadro com **1 pixel a menos** em uma dimensão (por exemplo, 832×1216 → 959×540 quando o alvo era 960×540). Como `cv2.addWeighted` exige arrays do mesmo tamanho, a composição falhava tanto no caminho GPU quanto no fallback CPU.

A rotina agora garante `altura × largura × 3` exatos em BGR `uint8`, usa arredondamento seguro e repete a normalização antes da mistura nos compositores GPU/CPU. O hotfix anterior de `uBright` foi preservado.

## Hotfix GPU 1.1.1

Esta revisão corrige a falha `KeyError('uBright')` observada em drivers NVIDIA durante o primeiro quadro. O parâmetro de brilho espectral agora é usado pelo shader, a interface de uniformes é tolerante a otimizações do compilador GLSL e o motor executa um autoteste antes de iniciar o filme.

## Conteúdo da distribuição

- **SUBTERRA Deluxe 1.1:** novo motor híbrido GPU/CPU, estilos reais, mídia, personagens rápidos 2.5D e ponte de IA multi-shot.
- **SUBTERRA clássico 0.2:** preservado em `engines/subterra_classic_v0_2`.
- **SUBTERRA-CYBERPUNK 0.2:** preservado em `engines/subterra_cyberpunk_v0_2`.
- **30 presets visuais:** cada um possui transformação de cor, processamento espacial, comportamento temporal e direção/overlay próprios.
- **15 cenas Deluxe originais:** subterrâneo, linhas elétricas, cidade sonora, megacidade, clube em silhueta, deserto monumental, palco cyberpunk, catedral de sinais, corredor de personagens, átrio de vidro, trânsito chuvoso, apartamento de tinta, praça holográfica, ruínas orbitais e outras.
- **IA local multi-shot:** manifesto, envio ao ComfyUI, espera, download e montagem híbrida com fallback procedural.

## Instalação no Windows

Requisitos:

- Windows 10 ou 11;
- Python 3.11 ou 3.12;
- FFmpeg no `PATH`;
- GPU OpenGL 3.3 ou superior para o caminho acelerado;
- RTX 4060 recomendada, mas não obrigatória.

Execute:

```text
INSTALAR_WINDOWS.bat
DIAGNOSTICO_WINDOWS.bat
ABRIR_DELUXE.bat
```

O diagnóstico cria `hardware_report_deluxe.json`.

## Primeiro teste recomendado

1. Abra `ABRIR_DELUXE.bat`.
2. Selecione a música e o caminho do filme final.
3. Use 1280 × 720, 30 fps, qualidade `fast` e estilo `nolan_odisseia`.
4. Mantenha **Áudio = preserve**.
5. Gere uma prévia de 20 segundos.
6. Em seguida, teste 1920 × 1080 com qualidade `deluxe`.

## Interface

### Projeto

- música;
- saída MP4/MKV/AVI;
- resolução digitável;
- FPS;
- qualidade interna;
- encoder automático, NVENC ou CPU;
- modo de áudio;
- prévia;
- acesso direto aos dois programas anteriores.

### Mídia e personagens

- imagens e vídeos de base com decodificação persistente;
- múltiplos personagens PNG/JPG;
- deslocamento, profundidade, escala, ação e reação ao áudio;
- para rig e atuação completos, abra o motor Cyberpunk 0.2 integrado.

### Direção e estilo

- 30 estilos distintos;
- descrição do tratamento cromático, temporal e gráfico;
- seed manual ou aleatória;
- seed gravada nos arquivos de projeto e relatórios.

### IA local

O fluxo possui autoconfiguração segura e geração seletiva:

1. **Auto-detectar:** consulta `/system_stats` e `/object_info`, identifica nós, GPU e modelos realmente expostos pelo ComfyUI.
2. **Exportar manifesto:** cria `manifest.json`, keyframes e JSONs de cada plano; os keyframes são selecionados no interior do shot para evitar fades pretos. Também permite recuperar `story.json` e filme-base de uma sessão anterior.
3. **Testar shot 0000:** faz upload do keyframe, monta um workflow API concreto, gera somente o primeiro plano, baixa e valida o vídeo.
4. **Gerar selecionados:** aceita `0`, `2-4`, listas ou `all`; o padrão seguro é somente `0`, com retomada de arquivos válidos.
5. **Montar filme híbrido:** substitui os planos encontrados e usa o filme-base nos planos ausentes.

O campo de workflow é opcional. Quando vazio, o programa usa perfis nativos montados a partir da instalação detectada, incluindo Wan I2V e Wan2.1 Fun Camera. Um peso text-to-video não é aceito como image-to-video: T2V só pode ser habilitado explicitamente para diagnóstico e o relatório registra que o keyframe não condicionou o resultado.

A IA é opcional. O filme procedural completo funciona sem ComfyUI.

## Áudio

O modo padrão é `preserve`:

- não aplica equalização;
- não aplica compressor;
- não aplica limiter;
- não altera loudness.

Em MP4, o áudio é codificado em AAC 320 kbit/s por compatibilidade do contêiner. Em MKV, o modo `preserve` usa FLAC. Os modos `streaming`, `cinema` e `club` são alterações explícitas escolhidas pelo usuário.

## Linha de comando

Render:

```powershell
python deluxe.py render "musica.wav" "saida.mp4" `
  --style nolan_odisseia `
  --seed 1223951587 `
  --width 1920 --height 1080 --fps 30 `
  --quality deluxe --encoder auto --audio-mode preserve
```

Com mídia e personagens:

```powershell
python deluxe.py render "musica.wav" "saida.mp4" `
  --media "imagem_base.jpg" `
  --character "personagem.png::protagonist::Operative" `
  --style neon_graphic_grit
```

Manifesto de IA:

```powershell
python deluxe.py ai-manifest "output\_work\projeto\story.json" "output\ai_shots" `
  --base-video "output\filme_base.mp4" --width 768 --height 432 --fps 24
```

Geração no ComfyUI:

```powershell
python deluxe.py ai-detect --host http://127.0.0.1:8188

python deluxe.py ai-generate "output\ai_shots\manifest.json" `
  --host http://127.0.0.1:8188 --output-dir "output\ai_shots" --shots 0
```

Um workflow API externo continua aceito como segundo argumento opcional. Para um diagnóstico deliberado com um backend somente T2V, use `--allow-text-to-video`; essa opção não valida condicionamento por keyframe.

Montagem híbrida:

```powershell
python deluxe.py ai-assemble "output\ai_shots\manifest.json" "filme_base.mp4" `
  "output\ai_shots" "filme_hibrido.mp4" --audio-master "audio_master.wav" --shots 0-4
```

## Testes e benchmark

```text
RODAR_TESTES.bat
BENCHMARK_RTX4060.bat
```

`RODAR_TESTES.bat` valida compilação, originalidade, estilos, render, personagens e montagem híbrida. `BENCHMARK_RTX4060.bat` mede 20 segundos em 1920 × 1080 no computador do usuário e registra o renderizador realmente utilizado.

## Limites honestos

- Nenhum programa local garante automaticamente o padrão integral de uma superprodução cinematográfica. O preset `nolan_odisseia` traduz princípios de contraste, escala, espaço negativo, lente, ritmo, halation e letterbox; a qualidade final depende de direção, mídia e planos gerados.
- Modelos de vídeo não são incluídos no ZIP por tamanho e licenças. O programa fornece a orquestração musical multi-shot e a integração local.
- A geração por IA em 8 GB deve começar em 640 × 360, 768 × 432 ou 854 × 480 e ser ampliada na composição final.
- A execução GPU não pôde ser medida no ambiente de construção. O relatório incluído mede o fallback CPU em 640 × 360; use o benchmark local para números da RTX 4060.

## Documentação

- `VALIDATION_REPORT.md`
- `docs/REBUILD_AUDIT.md`
- `docs/SPEED_ARCHITECTURE.md`
- `docs/STYLES_AND_PALETTES.md`
- `docs/NOLAN_ODISSEIA_ANALYSIS.md`
- `docs/AI_VIDEO_MODELS.md`
- `docs/INSTALL_IA_LOCAL.md`
