# Continuação Codex — SUBTERRA Deluxe

**Data:** 05 de agosto de 2026  
**Workspace:** `C:\Projeto_GPT\sub_terra\subterra_deluxe_v1_1_1_gpu_hotfix`

## 1. Pacote de continuidade e backup

- ZIP validado contra `PACOTE_CONTEXTO_SUBTERRA_DELUXE_CODEX.sha256`.
- SHA-256 calculado e esperado: `DACF9565BFC77ED6B4CEA500B69B398EF1C8C6B124818330E5717F3FE1A56860`.
- Os quatro documentos foram extraídos na raiz do projeto.
- Backup pré-alteração: `backup_pre_codex_20260805_172918`.
- O backup contém 161 arquivos de código/configuração e uma cópia adicional do manifesto original em `output_ai_shots_original`.

## 2. Estado real auditado

### Projeto

- Não existe repositório Git nesta pasta.
- Python do projeto: 3.11.9.
- `pip check`: nenhuma dependência quebrada.
- FFmpeg funcional, com NVENC.
- Filme-base presente: `output/filme_deluxe.mp4`.
- Filme-base validado: HEVC, 1920 × 1080, 30 fps, AAC, 20,000 s.
- Roteiro: `output/_work/Mr. Control_seed849201337/story.json`.
- Manifesto: 69 shots.
- Problema encontrado no manifesto original: os keyframes não existiam e `input_image` estava vazio.

### Hardware

- GPU: NVIDIA GeForce RTX 4060.
- VRAM: 8188 MiB.
- Driver observado: 610.88.
- Espaço livre em `C:` durante a auditoria: 40,07 GiB.

### ComfyUI

- Instalação Desktop: `C:\Users\Hugo\AppData\Local\Comfy-Desktop\ComfyUI-Installs\Jimezz`.
- ComfyUI: 0.30.2.
- Python: 3.13.12.
- PyTorch: 2.12.1+cu130.
- API local: `http://127.0.0.1:8188`.
- Nós expostos em `/object_info`: 825.
- CUDA e RTX 4060 confirmadas por `/system_stats`.
- Diretório compartilhado de entrada: `C:\Users\Hugo\AppData\Local\Comfy-Desktop\ComfyUI-Shared\input`.
- Diretório compartilhado de saída: `C:\Users\Hugo\AppData\Local\Comfy-Desktop\ComfyUI-Shared\output`.

Modelos instalados ao final da continuação:

- `diffusion_models/wan2.1_fun_camera_v1.1_1.3B_bf16.safetensors` — 3.232.727.784 bytes;
- `text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors` — 6.735.906.897 bytes;
- `vae/wan_2.1_vae.safetensors` — 253.815.318 bytes;
- `clip_vision/clip_vision_h.safetensors` — 1.264.219.396 bytes.

O peso que veio com a instalação e não seria mais usado foi removido após o
teste I2V aprovado:

- `diffusion_models/wan2.1_t2v_1.3B_fp16.safetensors` — 2.838.303.560 bytes.

Conclusão final: o backend local atual é **Wan2.1 Fun Camera 1.3B I2V**.
O rótulo anterior `backend=ltx_video_q8` não correspondia aos modelos locais.

## 3. Alterações implementadas

### Manifesto e keyframes

- Extração de keyframes agora valida filme-base e falhas de leitura.
- Adicionada exportação seletiva por shot.
- Adicionada reparação de keyframes em manifesto existente, sem reconstruir o projeto.
- A extração agora amostra o interior de cada shot e escolhe o quadro com melhor
  luminância/contraste, evitando fades pretos nas fronteiras.
- `shot_0000_keyframe.png` foi extraído do filme-base.

### Integração ComfyUI

- Descoberta automática por `/system_stats` e `/object_info`.
- Detecção dos modelos disponíveis diretamente nas opções dos loaders.
- Upload multipart real por `/upload/image`.
- Uso do nome/subpasta retornado pelo ComfyUI no `LoadImage`.
- Workflows API Wan nativos construídos com valores concretos, sem placeholders manuais.
- Adicionado adaptador nativo Wan2.1 Fun Camera: detecção do peso, upload do keyframe,
  CLIP Vision, `WanCameraEmbedding` e `WanCameraImageToVideo`.
- Validação de nós, formato API e placeholders antes do envio.
- Seleção segura de shots (`0`, `0,2-4` ou `all`).
- Padrão de geração alterado para somente shot 0.
- Retomada condicionada ao tipo de backend registrado; um clipe T2V anterior não é reutilizado como I2V.
- Workflow adaptado salvo por shot.
- Prompt ID, upload, backend, saída e FFprobe registrados.
- Erros são persistidos em `comfyui_generation_report.json` antes de retornar ao usuário.

### Interface

- `story.json` e filme-base podem ser selecionados após reabrir o programa.
- O roteiro mais recente é recuperado automaticamente.
- Adicionados `AUTO-DETECTAR`, `TESTAR SHOT 0000` e seletor de shots.
- Workflow externo passou a ser opcional.
- T2V sem keyframe exige opção explícita de diagnóstico.

### Montagem

- A montagem híbrida aceita subconjunto de shots para prévias curtas.
- O relatório informa todos os shots do manifesto e os shots selecionados.

## 4. Testes reais executados

### Upload do keyframe

Resultado aprovado:

- origem: `output/ai_shots/shot_0000_keyframe.png`;
- tamanho: 7.923 bytes;
- resposta da API: `name=shot_0000_keyframe.png`, `subfolder=subterra_deluxe`, `type=input`;
- cópia confirmada em `ComfyUI-Shared/input/subterra_deluxe/shot_0000_keyframe.png`;
- tamanho remoto: 7.923 bytes.

Este teste valida upload e resolução de caminho. Ele não valida I2V porque o peso I2V está ausente.

### Diagnóstico T2V do shot 0

Foi usado `--allow-text-to-video` deliberadamente para validar a infraestrutura instalada sem apresentar o resultado como I2V.

- Modelo: `wan2.1_t2v_1.3B_fp16.safetensors`.
- Prompt ID: `e4d79630-b50d-4887-af4e-0d478d42add9`.
- Resolução: 768 × 432.
- FPS: 24.
- Frames: 89.
- Steps: 20.
- Seed: 291597938.
- Tempo total observado: 376,7 s.
- GPU durante sampler: 100%, aproximadamente 5,1–5,9 GiB de VRAM.
- Saída: `output/ai_shots/shot_0000.mp4`.
- Codec: H.264.
- Duração FFprobe: 3,708333 s.
- Tamanho: 318.389 bytes.
- Resultado visual decodificável; frame de inspeção em `shot_0000_preview.png`.

Limitação obrigatória: `uploaded_input` está nulo no relatório T2V e o perfil contém `warning: O keyframe não condiciona este peso T2V.`

### Preflight I2V

Resultado aprovado como bloqueio preventivo:

- sem `--allow-text-to-video`, a geração recusou o backend atual;
- nenhum prompt foi enfileirado;
- fila final: 0 em execução, 0 pendentes;
- erro corretivo gravado em `output/ai_shots/comfyui_i2v_readiness_report.json`.

### I2V real do shot 0

Os pesos oficiais foram baixados e verificados:

- Fun Camera SHA-256: `1a648f6fbb543dd6ac9f2f9af1ca4bc1bbe460482ee4d7984d50565699e97398`;
- CLIP Vision SHA-256: `64a7ef761bfccbadbaa3da77366aac4185a6c58fa5de5f589b42a65bcc21f161`.

A primeira execução I2V foi estruturalmente válida, mas rejeitada visualmente
porque o keyframe em `t=0` era preto. O artefato foi preservado como
`shot_0000_i2v_black_keyframe_rejected.mp4`.

Após corrigir a seleção de keyframe:

- timestamp escolhido: 2,5204 s;
- backend: `wan_fun_camera_i2v`;
- keyframe enviado por `/upload/image`;
- perfil: `image-to-video`;
- movimento: `ClockWise (CW)`, velocidade 0,65;
- prompt ID: `5b20458b-c940-48cd-a3b8-500d570dfa30`;
- 768 × 432, 24 fps, 89 frames;
- duração: 3,708333 s;
- tamanho: 102.691 bytes;
- tempo total: 385,769 s;
- inspeção visual: estrutura vermelha do keyframe preservada e movimento contínuo.

Relatório congelado: `comfyui_generation_report_i2v_accepted.json`.

### Montagem híbrida curta

- Saída: `output/filme_deluxe_hibrido_preview.mp4`.
- Shots: 0–4.
- Shot gerado: 1.
- Fallback procedural: 4.
- Resolução: 1920 × 1080.
- FPS: 24.
- Vídeo: H.264/NVENC.
- Áudio: AAC presente.
- Duração: 18,499023 s.
- Tamanho: 24.623.472 bytes.

Esta prévia usa o `shot_0000` I2V aprovado e quatro fallbacks procedurais.

### Regressão

Comando:

```powershell
.venv\Scripts\python.exe tests\run_validation.py
.venv\Scripts\python.exe -m unittest tests.test_comfyui_auto -v
```

Resultados:

- validação do projeto: 9/9 PASS;
- contratos unitários de ComfyUI/keyframe: 7/7 PASS;
- originalidade: 0 arquivos idênticos e 0 pares acima de 0,70;
- estilos: 28/28 hashes únicos;
- montagem híbrida sintética: PASS.

### Benchmark RTX 4060

Comando equivalente a `BENCHMARK_RTX4060.bat`, executado sem o `pause` final:

```powershell
.venv\Scripts\python.exe tests\benchmark_rtx4060.py --width 1920 --height 1080 --fps 30 --seconds 20 --quality deluxe --encoder auto
```

Resultado:

- renderer: `GPU NVIDIA GeForce RTX 4060/PCIe/SSE2`;
- `gpu_requested=true`;
- `gpu_active_at_finish=true`;
- `gpu_error=null`;
- encoder: `h264_nvenc`;
- 600 frames;
- duração: 20,000 s;
- tempo: 356,423 s;
- velocidade: 1,68 fps.

Conclusão honesta: a GPU está realmente ativa e o erro `uBright` foi corrigido, mas o ganho sobre o fallback anterior de 1,65 fps é irrelevante. O critério de desempenho não foi atingido. A causa provável é a leitura síncrona completa do framebuffer GPU para RAM em cada quadro (`fbo.read`), seguida por câmera, estilo, transições e cópias OpenCV/NumPy em CPU a 1920 × 1080.

## 5. Arquivos de código modificados

- `gui.py`
- `subterra_deluxe/ai/__init__.py`
- `subterra_deluxe/ai/comfyui.py`
- `subterra_deluxe/ai/manifest.py`
- `subterra_deluxe/ai/hybrid.py`
- `subterra_deluxe/cli.py`
- `tests/run_validation.py`
- `tests/test_comfyui_auto.py`
- `README.md`
- `CHANGELOG.md`
- `VALIDATION_REPORT.md`
- `VALIDATION_REPORT.json`

## 6. Artefatos principais

- `output/ai_shots/shot_0000_keyframe.png`
- `output/ai_shots/shot_0000.mp4`
- `output/ai_shots/shot_0000_preview.png`
- `output/ai_shots/shot_0000_comfyui_api.json`
- `output/ai_shots/comfyui_generation_report.json`
- `output/ai_shots/comfyui_generation_report_t2v_diagnostic.json`
- `output/ai_shots/comfyui_i2v_readiness_report.json`
- `output/filme_deluxe_hibrido_preview.mp4`
- `output/filme_deluxe_hibrido_preview.hybrid_report.json`
- `benchmark_output/benchmark_1920x1080_30fps_deluxe.mp4`
- `benchmark_output/benchmark_report.json`

## 7. Marco I2V concluído

O primeiro marco objetivo foi atingido: o keyframe foi selecionado, enviado e
usado por um backend I2V real; o vídeo foi baixado, validado por FFprobe e
aprovado visualmente. O ComfyUI temporário foi encerrado, a fila terminou em
0/0 e a porta 8188 ficou livre.

## 8. Próximo passo recomendado

Gerar um lote pequeno, por exemplo shots 1–4, inspecionar continuidade e custo
por shot, e somente depois autorizar um lote maior. O padrão seguro permanece
`--shots 0`; nenhum lote completo é disparado implicitamente.
