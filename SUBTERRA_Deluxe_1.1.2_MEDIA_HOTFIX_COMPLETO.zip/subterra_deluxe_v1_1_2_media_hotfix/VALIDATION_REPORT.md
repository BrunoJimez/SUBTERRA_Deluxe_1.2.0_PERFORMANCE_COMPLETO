# Relatório de validação — SUBTERRA Deluxe 1.1.2 · hotfix de mídia

**Resultado:** 10/10 testes aprovados.

- PASS — **compilacao**: módulos Deluxe compilados
- PASS — **contrato_midia_dimensoes**: 832x1216->960x540; 103x100->1920x1080; 154x100->640x360; CPU normalizou BGRA 319x181
- PASS — **contrato_gpu_uniformes**: uBright ativo no shader; uniformes otimizados tratados sem KeyError
- PASS — **comfyui_autoconfiguracao_segura**: T2V não se passa por I2V; Fun Camera conecta keyframe, CLIP Vision e câmera
- PASS — **estilos_distintos**: 30/30 hashes únicos; diferença mínima 10.58
- PASS — **originalidade_codigo**: exatos=0, similaridade>0.70=0
- PASS — **render_demo**: 144 quadros, 24.00 fps, 36.56 fps de render
- PASS — **render_personagens**: 2 personagens; 144 quadros
- PASS — **video_comparacao_estilos**: 30 presets no mesmo material
- PASS — **montagem_hibrida_ia**: IA=1, fallback=3, duração=5.88s