@echo off
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (.venv\Scripts\python.exe tests\hardware_diagnostic.py) else (py -3.11 tests\hardware_diagnostic.py)
pause
