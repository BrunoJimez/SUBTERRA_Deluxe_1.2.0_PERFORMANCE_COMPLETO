from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from subterra_deluxe.config import DeluxeConfig
from subterra_deluxe.director import make_story
from subterra_deluxe.features import analyse_audio
from subterra_deluxe.media import CharacterSpec
from subterra_deluxe.renderer import DeluxeRenderer


PROJECT = ROOT / "output" / "producoes" / "the_thief_of_red_roses"
AUDIO = Path(
    r"C:\Users\Hugo\Documents\musicas IA\Jimezz\hyde\Masterizado\slowed\The Thief of Red Roses.wav"
)
REFERENCES = [
    Path(
        r"C:\Users\Hugo\Documents\musicas IA\Jimezz\Capas\ChatGPT Image 8 de mai. de 2026, 21_49_42 (1).png"
    ),
    Path(
        r"C:\Users\Hugo\Documents\musicas IA\Jimezz\Capas\ChatGPT Image 8 de mai. de 2026, 21_49_42 (2).png"
    ),
]
SEED = 8_052_026


PHASES = (
    (0.0, 10.101, "cold_prologue", "O vidro frio ainda não sabe que perdeu o vermelho."),
    (10.101, 27.957, "first_signal", "Uma presença aparece como falha, não como corpo."),
    (27.957, 65.109, "first_theft", "O ladrão encontra o primeiro vestígio da rosa."),
    (65.109, 106.765, "burial", "A memória roubada atravessa corredores de vidro e pedra."),
    (106.765, 153.670, "return", "O refrão traz a presença de volta, agora consciente do roubo."),
    (153.670, 171.247, "red_possession", "O vermelho toma a imagem em impulsos violentos."),
    (171.247, 183.438, "ritual", "A repetição de red transforma o roubo em ritual."),
    (183.438, 250.015, "drained_world", "A cor some; resta o eco do sinal e uma ausência."),
)


AI_NEGATIVE = (
    "warm cheerful daylight, comedy, generic cyberpunk city, busy background, floral wallpaper, "
    "literal bouquet, distorted anatomy, duplicate face, extra eyes, unstable identity, face morphing, "
    "fast random motion, camera shake, flicker, low detail, compression artifacts, subtitles, text, "
    "letters, watermark, signature, logo"
)


def _phase_at(timestamp: float) -> tuple[str, str]:
    for start, end, name, thesis in PHASES:
        if start <= timestamp < end:
            return name, thesis
    return PHASES[-1][2], PHASES[-1][3]


def _shot_direction(phase: str, sid: int) -> dict:
    choices = {
        "cold_prologue": {
            "scenes": ("glass_atrium", "liquid_chrome", "powerline_memory"),
            "styles": ("red_rose_glass",),
            "cameras": ("locked", "drift", "push"),
            "transitions": ("blackout", "dissolve", "cut"),
            "visible": (),
            "motif": "cold glass / missing colour",
        },
        "first_signal": {
            "scenes": ("liquid_chrome", "signal_cathedral", "glass_atrium"),
            "styles": ("red_rose_glass",),
            "cameras": ("push", "drift", "locked"),
            "transitions": ("chromatic_whip", "dissolve", "cut"),
            "visible": (0,),
            "motif": "He is the thief / first apparition",
        },
        "first_theft": {
            "scenes": ("rain_transit", "character_corridor", "subterranean_architecture"),
            "styles": ("red_rose_glass", "red_rose_signal", "desire_machine"),
            "cameras": ("over_shoulder", "handheld", "push"),
            "transitions": ("chromatic_whip", "cut", "blackout"),
            "visible": (0,),
            "motif": "Stealing the red / rose as memory",
        },
        "burial": {
            "scenes": ("character_corridor", "glass_atrium", "orbital_ruins", "liquid_chrome"),
            "styles": ("staglieno_cemetery", "red_rose_glass", "desire_machine"),
            "cameras": ("locked", "drift", "low_angle"),
            "transitions": ("dissolve", "blackout", "cut"),
            "visible": (),
            "motif": "heavy glass / buried signal",
        },
        "return": {
            "scenes": ("signal_cathedral", "rain_transit", "waveform_city", "character_corridor"),
            "styles": ("red_rose_glass", "red_rose_signal", "future_noir_cel"),
            "cameras": ("push", "orbit", "over_shoulder"),
            "transitions": ("shape_wipe", "chromatic_whip", "cut"),
            "visible": (1,),
            "motif": "Thief of the red / mirrored return",
        },
        "red_possession": {
            "scenes": ("cyber_stage", "signal_cathedral", "silhouette_club"),
            "styles": ("go_death", "red_rose_signal"),
            "cameras": ("crash_zoom", "handheld", "orbit"),
            "transitions": ("film_burn", "chromatic_whip", "cut"),
            "visible": (0, 1),
            "motif": "Stolen the red / colour possession",
        },
        "ritual": {
            "scenes": ("signal_cathedral", "cyber_stage", "subterranean_architecture"),
            "styles": ("go_death", "red_rose_signal"),
            "cameras": ("crash_zoom", "locked", "handheld"),
            "transitions": ("blackout", "film_burn", "cut"),
            "visible": (0, 1),
            "motif": "Red, red, red / theft becomes ritual",
        },
        "drained_world": {
            "scenes": ("orbital_ruins", "powerline_memory", "glass_atrium", "monumental_desert"),
            "styles": ("staglieno_cemetery", "red_rose_glass", "night_vibe"),
            "cameras": ("drift", "locked", "push"),
            "transitions": ("dissolve", "blackout", "cut"),
            "visible": (),
            "motif": "red drained / residual ghost",
        },
    }
    spec = choices[phase]
    visible = list(spec["visible"])
    return {
        "scene": spec["scenes"][sid % len(spec["scenes"])],
        "style": spec["styles"][sid % len(spec["styles"])],
        "camera": spec["cameras"][sid % len(spec["cameras"])],
        "transition": spec["transitions"][sid % len(spec["transitions"])],
        "visible": visible,
        "motif": spec["motif"],
    }


def _blocking(visible: list[int], phase: str, sid: int) -> dict:
    blocks = {}
    for position, character_id in enumerate(visible):
        if len(visible) == 1:
            center = 0.59 if (sid % 2) else 0.41
        else:
            center = 0.35 if position == 0 else 0.65
        travel = 0.035 if phase in {"red_possession", "ritual"} else 0.015
        blocks[str(character_id)] = {
            "x_start": round(center - travel, 3),
            "x_end": round(center + travel, 3),
            "scale": 1.08 if phase in {"red_possession", "ritual"} else 0.96,
            "depth": 0.34 + position * 0.12,
            "action": "dramatic_turn" if phase in {"red_possession", "ritual"} else "stare",
            "facing": 1 if position == 0 else -1,
        }
    return blocks


def _ai_prompt(phase: str, motif: str, camera: str) -> str:
    motion = {
        "cold_prologue": "almost motionless, condensation crawls slowly across glass",
        "first_signal": "the eye wakes gradually while horizontal signal scars drift",
        "first_theft": "a black gloved silhouette removes one small red rose from behind wet glass",
        "burial": "slow suspended dust and rain, the face recedes into marble darkness",
        "return": "the fragmented face reforms from scanlines and turns toward camera",
        "red_possession": "a single red pulse blooms through the eye and fractures the frozen surface",
        "ritual": "controlled rhythmic red pulses repeat through the glass without changing identity",
        "drained_world": "the last red reflection dies and the face dissolves into black ice",
    }[phase]
    return (
        "Original experimental industrial music-film, 16:9 composition. Preserve the exact facial identity, "
        "wet-glass texture and black negative space of the input reference. Icy cyan, white and deep black "
        "palette with only one restrained blood-red accent. A faceless thief is implied as absence and signal "
        f"corruption, never shown literally. Narrative motif: {motif}. Motion: {motion}. "
        f"Camera language: {camera}, slow controlled cinematic movement. High-contrast analogue video damage, "
        "horizontal glitches integrated into the image, coherent geometry, elegant horror, no dialogue text."
    )


def prepare() -> tuple[Path, Path, Path]:
    missing = [path for path in [AUDIO, *REFERENCES] if not path.exists()]
    if missing:
        raise FileNotFoundError("Arquivos ausentes: " + ", ".join(map(str, missing)))

    analysis_dir = PROJECT / "analysis" / "music"
    work_dir = PROJECT / "work"
    work_dir.mkdir(parents=True, exist_ok=True)
    analysis_path, features_path = analyse_audio(AUDIO, analysis_dir, use_cache=True)
    story_path = work_dir / "story.json"
    story = make_story(
        analysis_path,
        story_path,
        seed=SEED,
        edit_density=0.42,
        style="future_noir_cel",
        character_count=2,
    )

    for shot in story["shots"]:
        midpoint = (float(shot["start"]) + float(shot["end"])) / 2.0
        phase, thesis = _phase_at(midpoint)
        direction = _shot_direction(phase, int(shot["shot"]))
        shot.update(
            {
                "narrative_phase": phase,
                "narrative_thesis": thesis,
                "lyric_motif": direction["motif"],
                "scene": direction["scene"],
                "style": direction["style"],
                "camera": direction["camera"],
                "transition": direction["transition"],
                "visible_characters": direction["visible"],
                "blocking": _blocking(direction["visible"], phase, int(shot["shot"])),
                "media_mix": 0.58 if direction["visible"] else 0.40,
                "ai_prompt": _ai_prompt(phase, direction["motif"], direction["camera"]),
                "ai_negative_prompt": AI_NEGATIVE,
                "ai_candidate": phase
                in {"first_theft", "return", "red_possession", "ritual", "drained_world"},
            }
        )

    story["version"] = "1.1.3-the-thief-of-red-roses"
    story["title"] = "The Thief of Red Roses"
    story["artist"] = "Jimezz"
    story["logline"] = (
        "Uma presença rouba o vermelho de um mundo glacial; a cor vira memória, culpa e sinal vital."
    )
    story["reference_images"] = [str(path.resolve()) for path in REFERENCES]
    story["production"] = {
        "final_format": "1920x1080, 16:9, 24 fps",
        "base_render": "960x540 procedural synthesis upscaled frame-by-frame to 1920x1080",
        "ai_render": "selected 768x432 I2V hero shots, normalized into the 1080p master",
        "audio": "original 48 kHz stereo WAV preserved without mastering changes",
        "colour_arc": "icy cyan/black -> stolen red -> violent red ritual -> drained cyan/black",
    }
    story_path.write_text(json.dumps(story, ensure_ascii=False, indent=2), encoding="utf-8")

    treatment = PROJECT / "creative_treatment.md"
    treatment.write_text(
        "# The Thief of Red Roses — tratamento audiovisual\n\n"
        "**Formato:** 1920×1080, 16:9, 24 fps.  **Duração:** 4:10.  **Áudio:** preservado.\n\n"
        "## Conceito\n\n"
        "A rosa nunca aparece como decoração. O vermelho é memória, culpa e sinal vital. Uma presença "
        "fragmentada o rouba de um mundo de vidro molhado, ruído horizontal e gelo negro. As capas "
        "funcionam como identidade recorrente e matéria visual, não como uma imagem estática esticada.\n\n"
        "## Arco\n\n"
        "1. **Prólogo frio (0:00–0:10):** vidro sem vermelho, ausência e respiração visual lenta.\n"
        "2. **Primeiro sinal (0:10–0:28):** o rosto surge como falha de transmissão.\n"
        "3. **Primeiro roubo (0:28–1:05):** o refrão revela a perda do vermelho.\n"
        "4. **Enterro (1:05–1:47):** corredores de vidro e pedra guardam a memória roubada.\n"
        "5. **Retorno (1:47–2:34):** o rosto se recompõe, agora espelhado.\n"
        "6. **Posse vermelha (2:34–2:51):** o vermelho invade olho, vidro e sinal.\n"
        "7. **Ritual (2:51–3:03):** a repetição de “red” vira pulso visual.\n"
        "8. **Mundo drenado (3:03–4:10):** a cor morre lentamente; sobra o eco.\n\n"
        "## Letra e interpretação\n\n"
        "A transcrição automática sustenta com confiança os motivos “he is the thief”, “stealing the red”, "
        "“thief of the red”, “stolen the red”, “heavy glass” e a repetição final de “red”. Trechos menos "
        "nítidos não são usados como texto literal; informam apenas a atmosfera.\n",
        encoding="utf-8",
    )
    return analysis_path, features_path, story_path


def render(preview_seconds: float, output: Path) -> dict:
    _, features_path, story_path = prepare()
    config = DeluxeConfig(
        width=1920,
        height=1080,
        fps=24.0,
        seed=SEED,
        style="future_noir_cel",
        style_strength=0.94,
        quality="preview",
        internal_scale=1.0,
        encoder="h264_nvenc",
        crf=18,
        ffmpeg_preset="p5",
        audio_mode="preserve",
        edit_density=0.42,
        character_strength=0.92,
        media_strength=0.62,
        safe_flashes=True,
        preview_seconds=preview_seconds,
        use_gpu=True,
    )
    label = "preview" if preview_seconds > 0 else "full"
    config.save(PROJECT / "work" / f"render_config_{label}.json")
    characters = [
        CharacterSpec(str(REFERENCES[0]), role="apparition", name="The Signal"),
        CharacterSpec(str(REFERENCES[1]), role="mirror", name="The Echo"),
    ]
    renderer = DeluxeRenderer(
        config,
        features_path,
        story_path,
        media_paths=[str(path) for path in REFERENCES],
        characters=characters,
    )
    last_percent = -1

    def progress(done: int, total: int) -> None:
        nonlocal last_percent
        percent = int(done * 100 / max(1, total))
        if percent != last_percent:
            print(f"PROGRESS {percent:03d}% ({done}/{total})", flush=True)
            last_percent = percent

    return renderer.render(output, AUDIO, progress=progress)


def main() -> int:
    parser = argparse.ArgumentParser(description="Cria e renderiza The Thief of Red Roses.")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--preview-seconds", type=float, default=30.0)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.prepare_only:
        analysis, features, story = prepare()
        print(json.dumps({"analysis": str(analysis), "features": str(features), "story": str(story)}, indent=2))
        return 0
    output = args.output or PROJECT / (
        "the_thief_of_red_roses_preview_1080p.mp4"
        if args.preview_seconds > 0
        else "the_thief_of_red_roses_base_1080p.mp4"
    )
    report = render(args.preview_seconds, output)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
