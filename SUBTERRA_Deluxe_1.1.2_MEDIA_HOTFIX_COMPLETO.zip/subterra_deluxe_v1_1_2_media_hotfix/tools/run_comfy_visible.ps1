$ErrorActionPreference = "Stop"
$ComfyRoot = "C:\Users\Hugo\AppData\Local\Comfy-Desktop\ComfyUI-Installs\Jimezz\ComfyUI"
$ComfyPython = Join-Path $ComfyRoot ".venv\Scripts\python.exe"
$SharedRoot = "C:\Users\Hugo\AppData\Local\Comfy-Desktop\ComfyUI-Shared"

Set-Location -LiteralPath $ComfyRoot
& $ComfyPython -s main.py `
    --listen 127.0.0.1 `
    --port 8188 `
    --disable-auto-launch `
    --models-directory (Join-Path $SharedRoot "models") `
    --input-directory (Join-Path $SharedRoot "input") `
    --output-directory (Join-Path $SharedRoot "output") `
    --user-directory (Join-Path $ComfyRoot "user")
