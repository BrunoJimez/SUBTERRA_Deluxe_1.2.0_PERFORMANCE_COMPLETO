from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from faster_whisper import WhisperModel


def stamp(seconds: float) -> str:
    milliseconds = max(0, int(round(seconds * 1000)))
    hours, milliseconds = divmod(milliseconds, 3_600_000)
    minutes, milliseconds = divmod(milliseconds, 60_000)
    secs, milliseconds = divmod(milliseconds, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{milliseconds:03d}"


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser()
    parser.add_argument("audio")
    parser.add_argument("model")
    parser.add_argument("output_dir")
    parser.add_argument("--language", default="en")
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--initial-prompt", default=None)
    args = parser.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    compute_type = "float16" if args.device == "cuda" else "int8"
    model = WhisperModel(args.model, device=args.device, compute_type=compute_type)
    iterator, info = model.transcribe(
        args.audio,
        language=args.language,
        task="transcribe",
        beam_size=5,
        best_of=5,
        temperature=0.0,
        condition_on_previous_text=True,
        initial_prompt=args.initial_prompt,
        word_timestamps=True,
        vad_filter=False,
    )

    rows = []
    for index, segment in enumerate(iterator, 1):
        row = {
            "index": index,
            "start": round(segment.start, 3),
            "end": round(segment.end, 3),
            "text": segment.text.strip(),
            "avg_logprob": round(segment.avg_logprob, 4),
            "no_speech_prob": round(segment.no_speech_prob, 4),
            "compression_ratio": round(segment.compression_ratio, 4),
            "words": [
                {
                    "start": round(word.start, 3),
                    "end": round(word.end, 3),
                    "word": word.word,
                    "probability": round(word.probability, 4),
                }
                for word in (segment.words or [])
            ],
        }
        rows.append(row)
        print(
            f"[{index:03d}] {segment.start:7.2f}-{segment.end:7.2f} "
            f"p={segment.avg_logprob:6.3f} ns={segment.no_speech_prob:5.3f} | {row['text']}",
            flush=True,
        )

    payload = {
        "audio": str(Path(args.audio).resolve()),
        "model": str(Path(args.model).resolve()),
        "language": info.language,
        "language_probability": info.language_probability,
        "duration": info.duration,
        "duration_after_vad": info.duration_after_vad,
        "segments": rows,
    }
    (out / "transcription.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (out / "transcription.txt").write_text(
        "\n".join(f"[{row['start']:07.2f}-{row['end']:07.2f}] {row['text']}" for row in rows),
        encoding="utf-8",
    )
    srt = []
    for index, row in enumerate(rows, 1):
        srt.extend([str(index), f"{stamp(row['start'])} --> {stamp(row['end'])}", row["text"], ""])
    (out / "transcription.srt").write_text("\n".join(srt), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
