from __future__ import annotations

import json
import secrets
import subprocess
import sys
import threading
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from subterra_deluxe.config import DeluxeConfig
from subterra_deluxe.features import analyse_audio
from subterra_deluxe.director import make_story
from subterra_deluxe.media import CharacterSpec
from subterra_deluxe.renderer import DeluxeRenderer
from subterra_deluxe.styles import STYLE_SPECS
from subterra_deluxe.ai.manifest import build_multishot_manifest, ensure_manifest_keyframes
from subterra_deluxe.ai.comfyui import discover_comfyui, generate_manifest, parse_shot_selector
from subterra_deluxe.ai.hybrid import assemble_hybrid

ROOT=Path(__file__).resolve().parent

def _latest_story():
    candidates=list((ROOT/'output'/'_work').glob('**/story.json'))
    return str(max(candidates,key=lambda path:path.stat().st_mtime)) if candidates else ''

class App(tk.Tk):
    def __init__(self):
        super().__init__();self.title('SUBTERRA Deluxe 1.1.2 · reconstruído');self.geometry('1180x780');self.configure(bg='#090b0e')
        self.audio=tk.StringVar();self.output=tk.StringVar(value=str(ROOT/'output'/'filme_deluxe.mp4'));self.work=tk.StringVar(value=str(ROOT/'output'/'_work'))
        self.style=tk.StringVar(value='nolan_odisseia');self.seed=tk.StringVar(value='');self.width=tk.StringVar(value='1920');self.height=tk.StringVar(value='1080');self.fps=tk.StringVar(value='30');self.quality=tk.StringVar(value='deluxe');self.encoder=tk.StringVar(value='auto');self.audio_mode=tk.StringVar(value='preserve');self.gpu=tk.BooleanVar(value=True);self.preview=tk.StringVar(value='20')
        self.media=[];self.characters=[];self.last_story=None;self.last_base=None
        self._build()

    def _build(self):
        style=ttk.Style(self);style.theme_use('clam');style.configure('.',background='#10141a',foreground='#e9eef5',fieldbackground='#0b0f14');style.configure('TNotebook',background='#090b0e');style.configure('TNotebook.Tab',padding=(18,8));style.map('TNotebook.Tab',background=[('selected','#f5a623')],foreground=[('selected','#050505')])
        header=tk.Frame(self,bg='#090b0e');header.pack(fill='x',padx=14,pady=12)
        tk.Label(header,text='SUBTERRA DELUXE',font=('Consolas',20,'bold'),fg='#f5a623',bg='#090b0e').pack(side='left')
        tk.Label(header,text='  clássico + cyberpunk + GPU + estilos reais',font=('Consolas',10),fg='#8391a3',bg='#090b0e').pack(side='left')
        tabs=ttk.Notebook(self);tabs.pack(fill='both',expand=True,padx=12,pady=(0,10))
        self.tab_project=ttk.Frame(tabs);self.tab_assets=ttk.Frame(tabs);self.tab_style=ttk.Frame(tabs);self.tab_ai=ttk.Frame(tabs);self.tab_log=ttk.Frame(tabs)
        tabs.add(self.tab_project,text='Projeto');tabs.add(self.tab_assets,text='Mídia e personagens');tabs.add(self.tab_style,text='Direção e estilo');tabs.add(self.tab_ai,text='IA local');tabs.add(self.tab_log,text='Registro')
        self._project();self._assets();self._style();self._ai();self._log()
        bottom=tk.Frame(self,bg='#090b0e');bottom.pack(fill='x',padx=12,pady=(0,12))
        self.progress=ttk.Progressbar(bottom,maximum=100);self.progress.pack(side='left',fill='x',expand=True,padx=(0,10))
        ttk.Button(bottom,text='Prévia',command=lambda:self.start(True)).pack(side='left',padx=4);ttk.Button(bottom,text='RENDERIZAR FILME',command=lambda:self.start(False)).pack(side='left',padx=4)

    def row(self,parent,label,var,kind='file'):
        f=ttk.Frame(parent);f.pack(fill='x',padx=18,pady=7);ttk.Label(f,text=label,width=24).pack(side='left');ttk.Entry(f,textvariable=var).pack(side='left',fill='x',expand=True)
        if kind:
            def pick():
                if kind=='dir':p=filedialog.askdirectory()
                elif kind=='save':p=filedialog.asksaveasfilename(defaultextension='.mp4',filetypes=[('Vídeo','*.mp4 *.mkv *.avi')])
                else:p=filedialog.askopenfilename()
                if p:var.set(p)
            ttk.Button(f,text='ABRIR',command=pick).pack(side='left',padx=(8,0))

    def _project(self):
        self.row(self.tab_project,'Música',self.audio,'file');self.row(self.tab_project,'Filme final',self.output,'save');self.row(self.tab_project,'Pasta de trabalho',self.work,'dir')
        grid=ttk.Frame(self.tab_project);grid.pack(fill='x',padx=18,pady=12)
        for i,(lab,var,vals) in enumerate([('Largura',self.width,None),('Altura',self.height,None),('FPS',self.fps,['24','25','30','50','60']),('Qualidade',self.quality,['preview','fast','deluxe','master']),('Encoder',self.encoder,['auto','h264_nvenc','hevc_nvenc','av1_nvenc','libx264']),('Áudio',self.audio_mode,['preserve','streaming','cinema','club'])]):
            ttk.Label(grid,text=lab).grid(row=(i//3)*2,column=i%3,sticky='w',padx=8);w=ttk.Combobox(grid,textvariable=var,values=vals,state='readonly') if vals else ttk.Entry(grid,textvariable=var);w.grid(row=(i//3)*2+1,column=i%3,sticky='ew',padx=8,pady=(0,10));grid.columnconfigure(i%3,weight=1)
        ttk.Checkbutton(self.tab_project,text='Usar GPU OpenGL quando disponível',variable=self.gpu).pack(anchor='w',padx=26,pady=4)
        f=ttk.Frame(self.tab_project);f.pack(fill='x',padx=18,pady=10);ttk.Label(f,text='Prévia (segundos)',width=24).pack(side='left');ttk.Entry(f,textvariable=self.preview,width=10).pack(side='left')
        legacy=ttk.LabelFrame(self.tab_project,text='Motores oficiais anteriores preservados');legacy.pack(fill='x',padx=18,pady=14)
        ttk.Button(legacy,text='Abrir SUBTERRA 0.2 clássico',command=lambda:self.launch(ROOT/'engines'/'subterra_classic_v0_2'/'gui.py')).pack(side='left',padx=8,pady=10)
        ttk.Button(legacy,text='Abrir SUBTERRA-CYBERPUNK 0.2',command=lambda:self.launch(ROOT/'engines'/'subterra_cyberpunk_v0_2'/'gui.py')).pack(side='left',padx=8,pady=10)

    def _assets(self):
        left=ttk.LabelFrame(self.tab_assets,text='Mídia de base');left.pack(side='left',fill='both',expand=True,padx=12,pady=12)
        self.media_list=tk.Listbox(left,bg='#080b10',fg='#dce5ee');self.media_list.pack(fill='both',expand=True,padx=8,pady=8)
        ttk.Button(left,text='Adicionar imagens/vídeos',command=self.add_media).pack(pady=6)
        right=ttk.LabelFrame(self.tab_assets,text='Personagens rápidos 2.5D');right.pack(side='left',fill='both',expand=True,padx=12,pady=12)
        self.char_list=tk.Listbox(right,bg='#080b10',fg='#dce5ee');self.char_list.pack(fill='both',expand=True,padx=8,pady=8)
        ttk.Button(right,text='Adicionar personagem PNG/JPG',command=self.add_character).pack(pady=6)
        ttk.Label(right,text='O rig completo continua disponível no motor Cyberpunk 0.2.',foreground='#9aa8b8').pack(pady=6)

    def _style(self):
        f=ttk.Frame(self.tab_style);f.pack(fill='x',padx=18,pady=14);ttk.Label(f,text='Preset visual',width=22).pack(side='left');combo=ttk.Combobox(f,textvariable=self.style,values=list(STYLE_SPECS),state='readonly');combo.pack(side='left',fill='x',expand=True)
        self.style_desc=tk.Text(self.tab_style,height=14,bg='#080b10',fg='#dce5ee',wrap='word');self.style_desc.pack(fill='both',expand=True,padx=18,pady=10)
        def update(*_):
            s=STYLE_SPECS[self.style.get()];self.style_desc.delete('1.0','end');self.style_desc.insert('end',f'{s.label}\n\nFamília: {s.family}\nDireção: {s.direction}\nTemporalidade: {s.temporal}\nOverlay: {s.overlay}\n\nEste preset altera cor, imagem, temporalidade e direção visual. Não é apenas uma paleta.')
        self.style.trace_add('write',update);update()
        f2=ttk.Frame(self.tab_style);f2.pack(fill='x',padx=18,pady=10);ttk.Label(f2,text='Semente',width=22).pack(side='left');ttk.Entry(f2,textvariable=self.seed).pack(side='left',fill='x',expand=True);ttk.Button(f2,text='ALEATÓRIA',command=lambda:self.seed.set(str(secrets.randbelow(2**31-2)+1))).pack(side='left',padx=8)

    def _ai(self):
        box=ttk.LabelFrame(self.tab_ai,text='Seedance musical local — multi-shot');box.pack(fill='both',expand=True,padx=18,pady=14)
        ttk.Label(box,text='Fluxo completo: exportar manifesto → gerar e baixar clipes pelo ComfyUI → montar filme híbrido com fallback procedural.',wraplength=980).pack(anchor='w',padx=10,pady=10)
        self.ai_dir=tk.StringVar(value=str(ROOT/'output'/'ai_shots'))
        self.ai_manifest=tk.StringVar(value=str(ROOT/'output'/'ai_shots'/'manifest.json'))
        self.ai_workflow=tk.StringVar(value='')
        self.ai_story=tk.StringVar(value=_latest_story())
        self.ai_base=tk.StringVar(value=str(ROOT/'output'/'filme_deluxe.mp4'))
        self.ai_audio=tk.StringVar(value='')
        self.ai_final=tk.StringVar(value=str(ROOT/'output'/'filme_deluxe_hibrido.mp4'))
        self.ai_shots=tk.StringVar(value='0')
        self.ai_allow_t2v=tk.BooleanVar(value=False)
        self.ai_backend_status=tk.StringVar(value='ComfyUI ainda não auditado nesta sessão.')
        self.comfy=tk.StringVar(value='http://127.0.0.1:8188')
        self.row(box,'Pasta dos planos IA',self.ai_dir,'dir')
        self.row(box,'Manifesto IA',self.ai_manifest,'file')
        self.row(box,'Roteiro story.json',self.ai_story,'file')
        self.row(box,'Workflow API (opcional)',self.ai_workflow,'file')
        self.row(box,'Filme-base',self.ai_base,'file')
        self.row(box,'Áudio master (opcional)',self.ai_audio,'file')
        self.row(box,'Filme híbrido final',self.ai_final,'save')
        f=ttk.Frame(box);f.pack(fill='x',padx=18,pady=8);ttk.Label(f,text='Servidor ComfyUI',width=24).pack(side='left');ttk.Entry(f,textvariable=self.comfy).pack(side='left',fill='x',expand=True);ttk.Button(f,text='AUTO-DETECTAR',command=self.test_comfy).pack(side='left',padx=8)
        select=ttk.Frame(box);select.pack(fill='x',padx=18,pady=6);ttk.Label(select,text='Shots (0, 2-4 ou all)',width=24).pack(side='left');ttk.Entry(select,textvariable=self.ai_shots,width=24).pack(side='left');ttk.Checkbutton(select,text='Permitir T2V sem keyframe (diagnóstico)',variable=self.ai_allow_t2v).pack(side='left',padx=14)
        ttk.Label(box,textvariable=self.ai_backend_status,foreground='#f5a623',wraplength=980).pack(anchor='w',padx=18,pady=5)
        buttons=ttk.Frame(box);buttons.pack(fill='x',padx=18,pady=12)
        ttk.Button(buttons,text='1 · EXPORTAR MANIFESTO',command=self.export_ai).pack(side='left',padx=4)
        ttk.Button(buttons,text='2 · TESTAR SHOT 0000',command=self.test_shot_0000).pack(side='left',padx=4)
        ttk.Button(buttons,text='GERAR SELECIONADOS',command=self.start_ai_generate).pack(side='left',padx=4)
        ttk.Button(buttons,text='3 · MONTAR FILME HÍBRIDO',command=self.start_ai_assemble).pack(side='left',padx=4)
        ttk.Label(box,text='A autoconfiguração usa os nós/modelos realmente expostos pelo ComfyUI. O padrão seguro gera somente o shot 0; lote exige seleção explícita.',foreground='#9aa8b8',wraplength=980).pack(anchor='w',padx=18,pady=8)

    def _log(self):
        self.logbox=tk.Text(self.tab_log,bg='#05070a',fg='#d7e3ef',font=('Consolas',10));self.logbox.pack(fill='both',expand=True,padx=8,pady=8)

    def log(self,msg):self.logbox.insert('end',msg+'\n');self.logbox.see('end');self.update_idletasks()
    def add_media(self):
        for p in filedialog.askopenfilenames(filetypes=[('Mídia','*.png *.jpg *.jpeg *.webp *.mp4 *.mov *.mkv *.avi')]):self.media.append(p);self.media_list.insert('end',p)
    def add_character(self):
        p=filedialog.askopenfilename(filetypes=[('Imagem','*.png *.jpg *.jpeg *.webp')]);
        if p:self.characters.append(CharacterSpec(p,'protagonist',Path(p).stem));self.char_list.insert('end',p)
    def launch(self,path):subprocess.Popen([sys.executable,str(path)],cwd=str(path.parent))
    def test_comfy(self):
        try:
            discovery=discover_comfyui(self.comfy.get());public={k:v for k,v in discovery.items() if k!='_object_info'}
            if discovery['image_to_video_ready']:status='I2V pronto: '+str(discovery['resolved']['wan_i2v'])
            elif discovery['text_to_video_ready']:status='Somente T2V instalado: '+str(discovery['resolved']['wan_t2v'])+' · keyframe não será condicionado.'
            else:status='Nenhum backend de vídeo local compatível foi detectado.'
            self.ai_backend_status.set(status);self.log('Auditoria ComfyUI:\n'+json.dumps(public,indent=2,ensure_ascii=False))
        except Exception as e:messagebox.showerror('ComfyUI',str(e))
    def export_ai(self):
        story=Path(self.last_story or self.ai_story.get());base=Path(self.last_base or self.ai_base.get())
        if not story.is_file() or not base.is_file():messagebox.showwarning('IA','Selecione um story.json e um filme-base válidos.');return
        p=build_multishot_manifest(story,self.ai_dir.get(),base,768,432,24,'auto');self.ai_manifest.set(str(p));self.ai_story.set(str(story));self.ai_base.set(str(base));self.log('Manifesto IA: '+str(p));messagebox.showinfo('IA','Manifesto criado:\n'+str(p))
    def test_shot_0000(self):
        self.ai_shots.set('0');self.start_ai_generate()
    def start_ai_generate(self):
        if not self.ai_manifest.get():
            messagebox.showerror('IA','Selecione o manifesto. O workflow é opcional com autoconfiguração.');return
        threading.Thread(target=self.run_ai_generate,daemon=True).start()
    def run_ai_generate(self):
        try:
            shots=parse_shot_selector(self.ai_shots.get());base=Path(self.ai_base.get())
            if shots is not None and base.is_file():ensure_manifest_keyframes(self.ai_manifest.get(),base,shots)
            workflow=self.ai_workflow.get().strip() or None
            self.log('Iniciando geração seletiva no ComfyUI: '+self.ai_shots.get())
            report=generate_manifest(self.ai_manifest.get(),workflow,self.ai_dir.get(),self.comfy.get(),3600,lambda a,b,m:(self.progress.configure(value=100*a/max(1,b)),self.log(m)),shots,True,self.ai_allow_t2v.get())
            self.log(json.dumps(report,indent=2,ensure_ascii=False));messagebox.showinfo('IA',f'Clipes baixados: {report["downloaded"]}/{report["total"]}')
        except Exception as e:self.log('ERRO IA: '+repr(e));messagebox.showerror('IA',str(e))
    def start_ai_assemble(self):
        if not self.ai_manifest.get() or not self.ai_base.get() or not self.ai_final.get():
            messagebox.showerror('Montagem','Selecione manifesto, filme-base e filme final.');return
        threading.Thread(target=self.run_ai_assemble,daemon=True).start()
    def run_ai_assemble(self):
        try:
            audio=self.ai_audio.get().strip() or None
            self.log('Montando filme híbrido com fallback procedural...')
            report=assemble_hybrid(self.ai_manifest.get(),self.ai_base.get(),self.ai_dir.get(),self.ai_final.get(),audio,self.encoder.get())
            self.log(json.dumps(report,indent=2,ensure_ascii=False));messagebox.showinfo('Montagem',f'Concluído: {report["output"]}\nPlanos IA: {report["ai_shots"]} · fallback: {report["fallback_shots"]}')
        except Exception as e:self.log('ERRO MONTAGEM: '+repr(e));messagebox.showerror('Montagem',str(e))
    def start(self,preview):
        if not self.audio.get():messagebox.showerror('Projeto','Selecione a música.');return
        threading.Thread(target=self.run_render,args=(preview,),daemon=True).start()
    def run_render(self,preview):
        try:
            seed=int(self.seed.get()) if self.seed.get().strip() else secrets.randbelow(2**31-2)+1;self.seed.set(str(seed))
            work=Path(self.work.get())/f'{Path(self.audio.get()).stem}_seed{seed}';work.mkdir(parents=True,exist_ok=True)
            self.log(f'Analisando áudio · seed {seed}');analysis,features=analyse_audio(self.audio.get(),work)
            story=work/'story.json';make_story(analysis,story,seed,.62,self.style.get(),len(self.characters));self.last_story=story
            out=Path(self.output.get());
            if preview:out=out.with_name(out.stem+'__preview'+out.suffix)
            cfg=DeluxeConfig(width=int(self.width.get()),height=int(self.height.get()),fps=float(self.fps.get()),seed=seed,style=self.style.get(),quality=self.quality.get(),encoder=self.encoder.get(),audio_mode=self.audio_mode.get(),preview_seconds=float(self.preview.get()) if preview else 0,use_gpu=self.gpu.get())
            cfg.save(work/'render_config.json');r=DeluxeRenderer(cfg,features,story,self.media,self.characters)
            self.log('Renderizador: '+r.renderer_name)
            if r.gpu_error:self.log('Aviso GPU no autoteste: '+r.gpu_error)
            report=r.render(out,self.audio.get(),lambda a,b:self.progress.configure(value=100*a/b));self.last_base=out
            self.log(json.dumps(report,indent=2,ensure_ascii=False));messagebox.showinfo('SUBTERRA Deluxe','Concluído:\n'+str(out))
        except Exception as e:self.log('ERRO: '+repr(e)+'\n'+traceback.format_exc());messagebox.showerror('Erro',str(e))

if __name__=='__main__':App().mainloop()
