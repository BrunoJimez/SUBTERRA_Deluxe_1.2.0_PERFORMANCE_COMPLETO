# SUBTERRA Deluxe 1.1.2 — correção de composição de mídia

## Sintoma corrigido

Erro OpenCV ao iniciar o render:

`(-209:Sizes of input arguments do not match) ... in function 'cv::arithm_op'`

## Causa

A função `cover()` calculava o tamanho intermediário com `int(w * scale)` e
`int(h * scale)`. Em determinadas proporções, a representação de ponto flutuante
produzia algo como `959.999999...`; o `int()` truncava para 959 quando o
framebuffer tinha 960 pixels. O `cv2.addWeighted()` exige que os dois arrays
tenham exatamente a mesma largura, altura e número de canais.

Um caso de regressão reproduzido foi uma imagem 832x1216 direcionada para
960x540: a implementação antiga podia produzir 959x540.

## Correção aplicada

- `cover()` usa `ceil()` e nunca deixa a dimensão de *cover* menor que o alvo.
- A saída é garantida como `altura x largura x 3`, BGR, `uint8` e contígua.
- Tons de cinza e BGRA são normalizados automaticamente.
- GPU e CPU normalizam novamente a mídia imediatamente antes da composição.
- O traceback completo passa a aparecer no painel Registro em novas falhas.
- O hotfix anterior do shader NVIDIA (`uBright`) foi preservado.

## Validação

A suíte completa deste pacote foi executada após a correção: 10/10 testes
aprovados, incluindo render procedural, personagens, estilos, montagem híbrida,
contrato do shader e o novo teste de regressão de dimensões de mídia.

No Windows, execute `RODAR_TESTES.bat` para repetir a validação local.
