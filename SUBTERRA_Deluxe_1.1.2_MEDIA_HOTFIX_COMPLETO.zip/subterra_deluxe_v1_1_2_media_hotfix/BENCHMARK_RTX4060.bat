@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Execute INSTALAR_WINDOWS.bat primeiro.
  pause
  exit /b 1
)
.venv\Scripts\python.exe tests\benchmark_rtx4060.py --width 1920 --height 1080 --fps 30 --seconds 20 --quality deluxe --encoder auto
pause
