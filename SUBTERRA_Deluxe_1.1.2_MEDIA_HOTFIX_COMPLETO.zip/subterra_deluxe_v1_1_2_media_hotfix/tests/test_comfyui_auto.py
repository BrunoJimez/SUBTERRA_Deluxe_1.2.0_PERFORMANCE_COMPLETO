from __future__ import annotations

import unittest
from unittest.mock import patch

from subterra_deluxe.ai.comfyui import (
    build_auto_workflow,
    discover_comfyui,
    parse_shot_selector,
    validate_workflow,
)


ITEM = {
    "shot": 0,
    "duration": 2.0,
    "width": 640,
    "height": 360,
    "fps": 24.0,
    "frames": 49,
    "seed": 1234,
    "prompt": "A subterranean signal cathedral, slow orbit.",
    "negative_prompt": "text, watermark",
    "output_name": "shot_0000.mp4",
}


def discovery(*, i2v: bool, t2v: bool = True, fun_camera: bool = False) -> dict:
    resolved = {
        "wan_i2v": "wan2.1_i2v_480p_14B_fp8.safetensors" if i2v else None,
        "wan_fun_camera": (
            "wan2.1_fun_camera_v1.1_1.3B_bf16.safetensors" if fun_camera else None
        ),
        "wan_t2v": "wan2.1_t2v_1.3B_fp16.safetensors" if t2v else None,
        "text_encoder": "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
        "vae": "wan_2.1_vae.safetensors",
        "clip_vision": "clip_vision_h.safetensors" if (i2v or fun_camera) else None,
    }
    return {
        "resolved": resolved,
        "image_to_video_ready": i2v or fun_camera,
        "fun_camera_ready": fun_camera,
        "text_to_video_ready": t2v,
        "issues": ["I2V ausente"] if not (i2v or fun_camera) else [],
    }


class ComfyAutoWorkflowTests(unittest.TestCase):
    def test_discovery_recognises_fun_camera_as_i2v(self):
        nodes = {
            name: {}
            for name in {
                "CLIPTextEncode",
                "ModelSamplingSD3",
                "KSampler",
                "VAEDecode",
                "CreateVideo",
                "SaveVideo",
                "LoadImage",
                "CLIPVisionEncode",
                "WanCameraEmbedding",
                "WanCameraImageToVideo",
            }
        }
        nodes.update(
            {
                "UNETLoader": {
                    "input": {
                        "required": {
                            "unet_name": [["wan2.1_fun_camera_v1.1_1.3B_bf16.safetensors"]]
                        }
                    }
                },
                "CLIPLoader": {
                    "input": {"required": {"clip_name": [["umt5_xxl_fp8.safetensors"]]}}
                },
                "VAELoader": {
                    "input": {"required": {"vae_name": [["wan_2.1_vae.safetensors"]]}}
                },
                "CLIPVisionLoader": {
                    "input": {
                        "required": {"clip_name": [["clip_vision_h.safetensors"]]}
                    }
                },
            }
        )
        stats = {"system": {"comfyui_version": "test"}, "devices": []}
        with patch(
            "subterra_deluxe.ai.comfyui._read_json", side_effect=[stats, nodes]
        ):
            result = discover_comfyui()
        self.assertTrue(result["image_to_video_ready"])
        self.assertTrue(result["fun_camera_ready"])
        self.assertEqual(result["backends"][0]["id"], "wan_fun_camera_i2v")

    def test_safe_selector_defaults_to_shot_zero(self):
        self.assertEqual(parse_shot_selector(None), [0])
        self.assertEqual(parse_shot_selector("0,2-4"), [0, 2, 3, 4])
        self.assertIsNone(parse_shot_selector("all"))

    def test_text_only_backend_is_rejected_by_default(self):
        with self.assertRaisesRegex(RuntimeError, "image-to-video"):
            build_auto_workflow(ITEM, discovery(i2v=False))

    def test_text_only_diagnostic_is_explicit(self):
        workflow, profile = build_auto_workflow(
            ITEM, discovery(i2v=False), allow_text_to_video=True
        )
        self.assertEqual(profile["mode"], "text-to-video-diagnostic")
        self.assertNotIn("52", workflow)
        self.assertEqual(workflow["40"]["inputs"]["length"], 49)
        validate_workflow(workflow)

    def test_i2v_workflow_uses_uploaded_keyframe(self):
        upload = {
            "name": "shot_0000_keyframe.png",
            "subfolder": "subterra_deluxe",
            "type": "input",
        }
        workflow, profile = build_auto_workflow(ITEM, discovery(i2v=True), upload)
        self.assertEqual(profile["mode"], "image-to-video")
        self.assertEqual(
            workflow["52"]["inputs"]["image"],
            "subterra_deluxe/shot_0000_keyframe.png",
        )
        self.assertEqual(workflow["55"]["inputs"]["start_image"], ["52", 0])
        self.assertNotIn("{{", str(workflow))
        validate_workflow(workflow)

    def test_fun_camera_workflow_uses_keyframe_and_camera_embedding(self):
        upload = {
            "name": "shot_0000_keyframe.png",
            "subfolder": "subterra_deluxe",
            "type": "input",
        }
        workflow, profile = build_auto_workflow(
            ITEM, discovery(i2v=False, fun_camera=True), upload
        )
        self.assertEqual(profile["id"], "wan_fun_camera_i2v")
        self.assertEqual(profile["mode"], "image-to-video")
        self.assertEqual(profile["camera_pose"], "ClockWise (CW)")
        self.assertEqual(workflow["56"]["class_type"], "WanCameraImageToVideo")
        self.assertEqual(workflow["56"]["inputs"]["start_image"], ["52", 0])
        self.assertEqual(workflow["56"]["inputs"]["camera_conditions"], ["55", 0])
        self.assertEqual(workflow["3"]["inputs"]["latent_image"], ["56", 2])
        self.assertNotIn("{{", str(workflow))
        validate_workflow(workflow)


if __name__ == "__main__":
    unittest.main()
