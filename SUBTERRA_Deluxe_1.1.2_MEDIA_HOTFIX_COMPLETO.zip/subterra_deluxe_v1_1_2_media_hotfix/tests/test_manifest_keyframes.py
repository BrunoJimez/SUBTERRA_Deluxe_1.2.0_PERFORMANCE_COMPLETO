from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np

from subterra_deluxe.ai.manifest import _extract_representative_keyframe


class _SyntheticCapture:
    def __init__(self):
        self.timestamp_ms = 0.0

    def set(self, property_id, value):
        if property_id == cv2.CAP_PROP_POS_MSEC:
            self.timestamp_ms = float(value)
        return True

    def read(self):
        # Simulate a black opening fade followed by progressively useful frames.
        level = 0 if self.timestamp_ms < 400 else min(220, int(self.timestamp_ms / 8))
        return True, np.full((36, 64, 3), level, dtype=np.uint8)


class RepresentativeKeyframeTests(unittest.TestCase):
    def test_avoids_black_shot_boundary(self):
        with tempfile.TemporaryDirectory() as folder:
            destination = Path(folder) / "keyframe.png"
            result = _extract_representative_keyframe(
                _SyntheticCapture(), 0.0, 2.0, destination
            )
            self.assertIsNotNone(result)
            self.assertTrue(destination.is_file())
            self.assertGreater(result["timestamp"], 1.0)
            self.assertGreater(result["mean_luma"], 100)


if __name__ == "__main__":
    unittest.main()
