from __future__ import annotations

import argparse
import json
import math
import struct
import sys
import time
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from subterra_deluxe.config import DeluxeConfig
from subterra_deluxe.director import make_story
from subterra_deluxe.features import analyse_audio
from subterra_deluxe.renderer import DeluxeRenderer


def make_audio(path: Path, seconds: float, sr: int = 44100) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), 'wb') as f:
        f.setnchannels(2); f.setsampwidth(2); f.setframerate(sr)
        for i in range(int(seconds * sr)):
            t = i / sr
            kick = math.exp(-((t % .5) / .07)) * math.sin(2 * math.pi * 55 * t)
            pad = .25 * math.sin(2 * math.pi * 110 * t) + .12 * math.sin(2 * math.pi * 220 * t)
            value = max(-1, min(1, .55 * kick + pad))
            sample = int(value * 32767)
            f.writeframesraw(struct.pack('<hh', sample, sample))


def main() -> int:
    p = argparse.ArgumentParser(description='Benchmark local do SUBTERRA Deluxe reconstruído')
    p.add_argument('--audio')
    p.add_argument('--width', type=int, default=1920)
    p.add_argument('--height', type=int, default=1080)
    p.add_argument('--fps', type=float, default=30)
    p.add_argument('--seconds', type=float, default=20)
    p.add_argument('--quality', choices=['preview', 'fast', 'deluxe', 'master'], default='deluxe')
    p.add_argument('--style', default='nolan_odisseia')
    p.add_argument('--encoder', default='auto')
    p.add_argument('--cpu', action='store_true')
    ns = p.parse_args()

    work = ROOT / 'benchmark_output'
    work.mkdir(parents=True, exist_ok=True)
    audio = Path(ns.audio) if ns.audio else work / 'benchmark_audio.wav'
    if not ns.audio:
        make_audio(audio, max(ns.seconds, 24))
    analysis, features = analyse_audio(audio, work / 'analysis')
    seed = 1223951587
    story = work / 'story.json'
    make_story(analysis, story, seed, .62, ns.style, 0)
    output = work / f'benchmark_{ns.width}x{ns.height}_{int(ns.fps)}fps_{ns.quality}.mp4'
    cfg = DeluxeConfig(
        width=ns.width, height=ns.height, fps=ns.fps, seed=seed, style=ns.style,
        quality=ns.quality, preview_seconds=ns.seconds, encoder=ns.encoder,
        audio_mode='preserve', use_gpu=not ns.cpu,
    )
    renderer = DeluxeRenderer(cfg, features, story)
    print('Renderizador:', renderer.renderer_name)
    started = time.perf_counter()
    report = renderer.render(output, audio, lambda a, b: print(f'\r{a}/{b}', end='', flush=True))
    report['benchmark_wall_seconds'] = round(time.perf_counter() - started, 3)
    report['requested_gpu'] = not ns.cpu
    path = work / 'benchmark_report.json'
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    print('\n' + json.dumps(report, indent=2, ensure_ascii=False))
    print('\nRelatório:', path)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
