from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> int:
    shader = (ROOT / "subterra_deluxe" / "shaders" / "deluxe_scene.frag").read_text(encoding="utf-8")
    declaration = "uniform float uBright;"
    assert declaration in shader
    body = shader.replace(declaration, "", 1)
    assert "uBright" in body, "uBright voltou a ser declarado sem participar da saída"

    from subterra_deluxe.gpu_engine import GPUSceneRenderer

    class Slot:
        def __init__(self): self.value = None

    class FakeProgram:
        def __init__(self): self.slot = Slot()
        def __getitem__(self, name):
            if name == "present": return self.slot
            raise KeyError(name)

    renderer = GPUSceneRenderer.__new__(GPUSceneRenderer)
    renderer.prog = FakeProgram()
    assert renderer._set_uniform("present", 3.0, required=True)
    assert renderer.prog.slot.value == 3.0
    assert renderer._set_uniform("optimised_out", 1.0, required=False) is False
    try:
        renderer._set_uniform("required_missing", 1.0, required=True)
    except RuntimeError as exc:
        assert "required_missing" in str(exc)
    else:
        raise AssertionError("uniform obrigatório ausente não foi detectado")

    print("PASS contrato GPU/uBright")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
