from __future__ import annotations
import json, os, platform, shutil, subprocess, sys
from pathlib import Path
try: import psutil
except Exception: psutil=None

root=Path(__file__).resolve().parents[1]
report={'os':platform.platform(),'python':sys.version.split()[0],'machine':platform.machine(),'cpu':platform.processor(),'logical_cores':os.cpu_count(),'ffmpeg':shutil.which('ffmpeg') is not None,'nvidia_smi':shutil.which('nvidia-smi') is not None}
if psutil:
 report['ram_gb']=round(psutil.virtual_memory().total/2**30,2);report['free_disk_gb']=round(shutil.disk_usage(root).free/2**30,2)
if report['nvidia_smi']:
 try:
  txt=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,driver_version','--format=csv,noheader'],text=True,timeout=10).strip();report['gpu']=txt
 except Exception as e:report['gpu_error']=str(e)
try:
 import moderngl
 ctx=moderngl.create_standalone_context(require=330);report['opengl_renderer']=ctx.info.get('GL_RENDERER');ctx.release()
except Exception as e:report['opengl_error']=str(e)
path=root/'hardware_report_deluxe.json';path.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8');print(json.dumps(report,indent=2,ensure_ascii=False));print(path)
