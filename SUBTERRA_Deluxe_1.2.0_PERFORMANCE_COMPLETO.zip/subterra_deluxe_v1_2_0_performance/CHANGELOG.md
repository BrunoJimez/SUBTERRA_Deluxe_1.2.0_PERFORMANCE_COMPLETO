# 1.2.0 — Performance

- Pipeline de quadros com GPU, workers CPU e encoder trabalhando em paralelo; estado temporal em ordem.
- Planejamento de workers e filas por RAM/resolução/CPU, com reserva de CPU para libx264.
- Perfis Equilibrado/Máximo/Compatibilidade na GUI/CLI.
- Vídeos lidos sequencialmente e quadros repetidos reutilizados; imagens e decoders sob limites.
- Cache da máscara de vinheta e readback OpenGL reutilizável.
- Escrita por memoryview, propagação de erros e substituição final somente após sucesso.
- Áudio integrado ao encoder no Deluxe, sem segunda cópia do filme.
- Detecção de encoder com exportação real de um quadro e fallback auto para libx264.
- Cache de análise compartilhado entre sementes visuais na GUI/CLI.
- Montagem híbrida com até dois segmentos em paralelo.
- Benchmark comparativo reproduzível e testes de equivalência/regressão.

# Changelog

## 1.1.2-media-shape-hotfix

- Corrigido o erro OpenCV `(-209:Sizes of input arguments do not match)` ao misturar mídia de base com o framebuffer.
- A função `cover()` agora usa arredondamento para cima no modo *cover* e garante dimensionalidade exata, evitando quadros 1 px menores por erro de ponto flutuante.
- Imagens em tons de cinza, BGRA e arrays numéricos compatíveis são normalizados para BGR `uint8`.
- Os compositores GPU e CPU fazem uma validação/normalização defensiva imediatamente antes do `cv2.addWeighted`.
- Adicionado teste de regressão para mídia 832x1216, proporção que expunha o bug ao gerar 959x540 em vez de 960x540 na implementação anterior.
- A interface agora registra o traceback completo no painel **Registro** quando houver uma exceção de render.

## Continuação Codex — autoconfiguração IA (não lançada)

- Adicionada descoberta real de ComfyUI por `/system_stats` e `/object_info`.
- Adicionado upload multipart de keyframes por `/upload/image`.
- Adicionados workflows API nativos Wan T2V/I2V construídos sem edição manual de JSON.
- Adicionado perfil Wan2.1 Fun Camera I2V com CLIP Vision e movimento de câmera nativos.
- Keyframes passam a ser escolhidos dentro do shot por luminância/contraste,
  evitando frames pretos em fades de entrada.
- Shot 0000 I2V real validado visualmente; peso T2V antigo removido após o aceite.
- T2V não é mais aceito silenciosamente como I2V; diagnóstico T2V exige opção explícita.
- Geração seletiva e retomável por shot, com padrão seguro no `shot_0000`.
- Workflow adaptado, prompt ID, upload, FFprobe e erros são gravados no relatório por shot.
- Interface recupera `story.json`/filme-base e oferece auto-detecção e teste do shot 0.
- Montagem híbrida aceita subconjunto de shots para prévias curtas.
- Validação ampliada para 9 testes, mais 7 contratos unitários de autoconfiguração/keyframe.
- Benchmark local confirmou GPU ativa, mas não ganho relevante de velocidade; o gargalo permanece em readback GPU→CPU e pós-processamento OpenCV por quadro.

## 1.1.1-gpu-hotfix

- Corrigido `KeyError('uBright')` no caminho ModernGL/NVIDIA.
- `uBright` agora participa efetivamente do shader como exposição espectral limitada.
- Escrita de uniformes protegida contra otimização específica de drivers GLSL.
- Autoteste GPU executado antes do primeiro quadro do filme.
- Fallback em tempo de execução com diagnóstico no relatório, sem perder a renderização.
- Relatório passa a registrar `gpu_requested`, `gpu_active_at_finish` e `gpu_error`.

## 1.1.0-rebuilt

### Reconstrução

- Descartado o núcleo do Deluxe 1.0 rejeitado.
- Novo código independente para análise, direção, cenas, GPU, estilos, mídia, áudio, IA e montagem.
- SUBTERRA clássico 0.2 e SUBTERRA-CYBERPUNK 0.2 preservados integralmente como motores oficiais anteriores.

### Render

- Novo renderer GPU-first em ModernGL/OpenGL.
- Fallback CPU vetorizado.
- 15 cenas originais.
- Quadros enviados diretamente ao FFmpeg.
- Seleção automática de NVENC quando realmente disponível.
- Cache de análise e mídia persistente.

### Estilos

- 28 presets com quatro componentes próprios: cor, imagem, tempo e direção.
- Adicionados tratamentos reais de camcorder, hacking, vidro corporativo, chuva, cel animation limitada, Dark Deco, Matrix, Frutiger Aero, SCP, Nolan_Odisseia e outros.
- Teste automático de hashes e distância visual.

### Cyberpunk

- Personagens rápidos 2.5D integrados ao Deluxe.
- Rig completo e continuidade do Cyberpunk 0.2 preservados na distribuição.

### IA

- Manifesto multi-shot com prompts, keyframes, seeds e duração.
- Envio sequencial a workflows ComfyUI API.
- Espera e download automático de MP4/WebM/MOV/GIF detectável.
- Montagem híbrida com fallback para o filme procedural.

### Áudio

- `preserve` não aplica filtros sonoros.
- Modos alteradores somente por escolha explícita.

### Validação

- Auditoria de similaridade contra o programa de referência.
- 0 arquivos idênticos e 0 pares acima de 0,70 de similaridade.
- 28/28 estilos com hashes únicos.
- Vídeos de demonstração, personagens, comparação de estilos e montagem híbrida aprovados.
