# SUBTERRA Deluxe 1.2.0 — renderização paralela

Esta versão melhora a renderização do motor Deluxe e a montagem híbrida. A GPU gera as cenas OpenGL; workers da CPU processam quadros independentes; uma fila em RAM alimenta o FFmpeg enquanto os próximos quadros são preparados. Quando o teste real de NVENC passa, a compressão H.264 usa o encoder da NVIDIA.

## Instalar e abrir no Windows

1. Extraia o ZIP em uma nova pasta, por exemplo `C:\Projeto_GPT\subterra_deluxe_v1_2_0_performance`.
2. Execute `INSTALAR_WINDOWS.bat`. O instalador procura Python 3.11 e, na ausência dele, usa o Python 3 disponível. Python de 64 bits é necessário; 3.11 é a referência do instalador.
3. Execute `DIAGNOSTICO_WINDOWS.bat`. Para sua RTX 4060, procure `opengl_renderer` contendo NVIDIA/RTX 4060 e `h264_nvenc.real_encode_ok: true`.
4. Abra `ABRIR_DELUXE.bat`. Selecione seu áudio, estilo, resolução e mídias normalmente.
5. Em **Desempenho**, escolha **Máximo**, deixe **Workers = 0** e **RAM = 0**, marque GPU OpenGL e selecione **Encoder = auto**. Faça uma prévia antes do filme completo.

Os atalhos adicionam `C:\ffmpeg\bin` ao PATH quando essa instalação existe, conforme o caminho utilizado no seu computador. Caso use outra instalação, FFmpeg e FFprobe precisam estar no PATH.

| Perfil | Uso | Compressão automática |
|---|---|---|
| Equilibrado | Padrão, até 4 workers conforme CPU/RAM | NVENC p4 / x264 fast |
| Máximo | Prioriza velocidade, até 8 workers conforme CPU/RAM | NVENC p2 / x264 veryfast |
| Compatibilidade | Processamento visual sequencial para comparação/diagnóstico | NVENC p5 / x264 medium |

A resolução, o FPS e a escala visual selecionados são mantidos ao mudar apenas o perfil de desempenho. Presets mais rápidos de compressão podem produzir arquivos maiores e diferenças de compressão; o ganho de velocidade não implica identidade binária do MP4. Configurações antigas com `ffmpeg_preset` explícito conservam esse preset.

Se o encoder for libx264, o número de workers é limitado adicionalmente à metade das CPUs lógicas, para reservar capacidade à compressão. Portanto, Máximo não significa abrir sempre oito workers, nem é garantido que vença Equilibrado em todo projeto.

## Como CPU, GPU e RAM trabalham juntas

- **GPU / OpenGL:** geração das cenas, com contexto persistente e leitura em buffer reutilizável.
- **CPU:** personagens, câmera e efeitos espaciais de vários quadros ao mesmo tempo. Se OpenGL falhar, a geração das cenas passa para a CPU.
- **RAM:** imagens reutilizadas e filas limitadas de quadros, sem guardar o filme inteiro.
- **NVENC:** compressão de vídeo simultânea à preparação dos quadros. Sem um encoder NVIDIA operacional, auto usa libx264.
- **Áudio:** entra no mesmo processo de exportação do vídeo; o Deluxe não cria mais um vídeo silencioso inteiro para depois copiá-lo com áudio.

Os rastros, quadros retidos e transições são aplicados na ordem da linha do tempo, depois dos workers. Isso evita cintilação, troca de quadros e perda de continuidade.

Usar 100% de todos os recursos não é a meta: a etapa mais lenta limita a velocidade. Aumentar workers excessivamente pode aumentar a disputa por memória e diminuir o desempenho. A utilização da GPU pode aparecer separada nos gráficos 3D e Video Encode do Gerenciador de Tarefas.

## RAM e SSD no seu computador

Com 16 GB de RAM, comece com o orçamento automático. Ele permite até 2048 MiB para a estimativa dos buffers e limita essa escolha a 40% da RAM disponível no início. Este número é um orçamento estimado do pipeline, não um teto do processo inteiro: Python, decoders, driver, FFmpeg e ComfyUI também usam memória.

O programa limita cache de imagens, decoders abertos, workers, quadros em processamento e fila de escrita. Se nem um quadro couber na estimativa do orçamento, apresenta uma mensagem em vez de iniciar uma fila excessiva.

O campo RAM aceita um orçamento manual em MiB, ainda limitado pela RAM disponível. Aumentá-lo só ajuda se a RAM estiver limitando o paralelismo. ComfyUI aberto pode reduzir a memória disponível. Para medir o render procedural, execute o benchmark sem gerar clipes de IA ao mesmo tempo.

Use preferencialmente o SSD para saída e arquivos de trabalho; coloque o filme pronto no HDD depois, se desejar. Isso reduz o impacto de escrita, leitura e finalização do MP4 em discos lentos.

## Medir o ganho na RTX 4060

Execute `BENCHMARK_RTX4060.bat`. Ele compara os três perfis em Full HD com duas repetições, mesma seed e mesmo roteiro, alternando a ordem. O arquivo é `benchmark_output/benchmark_comparativo.json`.

O benchmark padrão inclui os presets automáticos de cada perfil. Para medir o paralelismo mantendo a compressão no mesmo preset:

```powershell
.\.venv\Scripts\python.exe tests\benchmark_rtx4060.py --width 1920 --height 1080 --seconds 8 --repeats 3 --same-preset
```

Para também avaliar seus vídeos de entrada:

```powershell
.\.venv\Scripts\python.exe tests\benchmark_rtx4060.py --audio "C:\Musicas\faixa.wav" --media "C:\Videos\base.mp4" --same-preset
```

Compare `median_seconds`, `median_fps`, o encoder efetivamente usado e `gpu_active_at_finish`. A comparação é com o perfil sequencial da versão atual, que já contém correções e caches; não é uma medição direta do executável 1.1.2 original.

No ambiente de desenvolvimento, o ensaio em CPU de 1280×720, 24 fps, 72 quadros, estilo nolan_odisseia, áudio e x264 medium fixo teve mediana de 13,614 s no perfil sequencial e 6,765 s em Máximo (2,012×). Veja `docs/BENCHMARK_DESENVOLVIMENTO.json`. Isso demonstra o funcionamento do paralelismo nesse ensaio; não prediz o ganho da sua RTX 4060. Não havia uma GPU NVIDIA neste ambiente.

## Uso por linha de comando

```powershell
.\.venv\Scripts\python.exe deluxe.py render "C:\Musicas\faixa.wav" "output\filme.mp4" --performance maximum --encoder auto --width 1920 --height 1080 --fps 30 --quality deluxe
```

Opções novas: `--performance balanced|maximum|compatibility`, `--cpu-workers 0`, `--ram-budget-mb 0` e `--encoder-preset auto`. As duas opções com zero usam seleção automática. `--encoder-preset p5` fixa p5 independentemente do perfil.

A montagem `ai-assemble` também aceita `--performance maximum` e normaliza até dois segmentos simultaneamente, com concatenação na ordem do roteiro. Isso acelera a montagem, não a difusão dos modelos de IA.

## O que foi preservado e os limites

Os 30 estilos, suas fórmulas, sementes e efeitos temporais foram mantidos. Os testes compararam a saída visual dos estilos com hashes calculados pela versão 1.1.2 original e compararam o pipeline paralelo com o sequencial, antes da compressão. Os motores Clássico 0.2 e Cyberpunk 0.2 continuam como módulos separados: as otimizações novas ficam no Deluxe e na montagem híbrida. Abra `ABRIR_DELUXE.bat` para usá-las.

A geração de clipes em ComfyUI permanece dependente do modelo, resolução, quantidade de frames e VRAM. Esta versão não muda steps, sampler, pesos, rig ou fidelidade dos clipes para acelerar essa geração. Também não requer CUDA Toolkit, PyTorch ou CuPy para o render procedural.

Não foi possível testar a interface nativa no Windows nem o driver da sua RTX 4060 aqui. A validação OpenGL usou Mesa/llvmpipe, que executa shaders por software. O diagnóstico e o benchmark locais verificam o caminho NVIDIA no seu computador.

## Falhas e relatórios

Cada render gera `nome.render_report.json` com perfil, workers reais, orçamento, tempos, FPS, encoder, diagnóstico GPU e contadores de leitura/seek. Os tempos de workers se sobrepõem e não devem ser somados para reconstruir o tempo total. A amostragem RSS é apenas do processo Python; FFmpeg/driver não estão incluídos.

Uma falha do encoder, erro de efeito ou interrupção não substitui o arquivo final anterior. O programa encerra a escrita e remove os temporários de exportação. Auto testa um frame real antes do filme; escolher NVENC manualmente sem um encoder funcional causa erro claro no início. OpenGL tem fallback CPU registrado no relatório.

Execute `RODAR_TESTES.bat` para validação local. Em caso de problema, compartilhe `hardware_report_deluxe.json`, o relatório do render ou `benchmark_comparativo.json` e a mensagem exibida.
