from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
import wave
from pathlib import Path
from unittest.mock import patch

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from subterra_deluxe.config import DeluxeConfig
from subterra_deluxe.media import MediaPool, CharacterSpec
from subterra_deluxe.performance import make_plan
from subterra_deluxe.renderer import DeluxeRenderer
from subterra_deluxe.styles import StyleState, STYLE_SPECS, apply_style
from subterra_deluxe.video_writer import AsyncVideoWriter
from subterra_deluxe.audio_mux import resolve_encoder, video_writer_cmd


def project(folder, duration=1.0):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    t=np.linspace(0,duration,80,dtype=np.float32)
    features=folder/'features.npz'
    np.savez(features,times=t,energy=.5+.2*np.sin(t),impact=.5+.4*np.cos(t*13),
             brightness=np.full_like(t,.6),beat_times=np.arange(0,duration,.25))
    transitions=['cut','dissolve','blackout','shape_wipe','chromatic_whip','film_burn']
    shots=[]
    for i,transition in enumerate(transitions):
        shots.append(dict(shot=i,start=i*duration/6,end=(i+1)*duration/6,
                          scene=['signal_cathedral','rain_transit'][i%2],seed=31+i,
                          camera=['locked','push','drift','orbit','handheld','crash_zoom'][i],
                          transition=transition, visible_characters=[0],
                          style=['nolan_odisseia','night_vibe','future_noir_cel'][i%3]))
    story=folder/'story.json';story.write_text(json.dumps(dict(duration_seconds=duration,shots=shots)))
    return features,story


class FrameSink:
    """Captures pre-encoding images so compression cannot hide ordering errors."""
    captures=[]
    def __init__(self,cmd,width,height,queue_size):
        self.path=Path(cmd[-1]);self.frames=0;self.resize_seconds=0.;self.write_seconds=0.;self.peak_queue=0
        self.images=[];FrameSink.captures.append(self)
    def submit(self,frame):self.images.append(frame.copy());self.frames+=1
    def check(self):pass
    def finish(self):self.path.write_bytes(b'checked frames')
    def abort(self):pass


class PerformanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.work=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()

    def test_original_all_thirty_styles_pixel_exact(self):
        versions=json.loads((ROOT/'tests/fixtures/reference_versions.json').read_text())
        if versions != {'numpy':np.__version__,'opencv':cv2.__version__}:
            self.skipTest('Hashes históricos exigem as versões NumPy/OpenCV registradas em reference_versions.json; equivalência paralelo/sequencial permanece testada.')
        expected=json.loads((ROOT/'tests/fixtures/styles_1_1_2_sha256.json').read_text())
        frames=np.random.default_rng(9281).integers(0,256,(6,72,128,3),dtype=np.uint8)
        for style,digest in expected.items():
            with self.subTest(style=style):
                state=StyleState();actual=hashlib.sha256()
                for i,frame in enumerate(frames):
                    actual.update(apply_style(frame,style,.9,state,i/24,i,.9,119).tobytes())
                self.assertEqual(actual.hexdigest(),digest)

    def test_cpu_parallel_temporal_transitions_characters_match_sequential(self):
        self._compare_pipeline(False)

    def test_opengl_parallel_matches_sequential_when_available(self):
        try:
            from subterra_deluxe.gpu_engine import GPUSceneRenderer
            gpu=GPUSceneRenderer(128,72,123);gpu.self_test();gpu.close()
        except Exception as exc:
            self.skipTest(f'OpenGL indisponível: {exc}')
        self._compare_pipeline(True)

    def _compare_pipeline(self,gpu):
        features,story=project(self.work)
        sprite=np.zeros((80,40,4),np.uint8)
        cv2.ellipse(sprite,(20,40),(14,32),0,0,360,(70,140,240,255),-1)
        path=self.work/'actor.png';cv2.imwrite(str(path),sprite)
        captured=[]
        with patch('subterra_deluxe.renderer.AsyncVideoWriter',FrameSink):
            for mode in ['compatibility','balanced','maximum']:
                cfg=DeluxeConfig(width=128,height=72,fps=24,seed=123,use_gpu=gpu,performance=mode,encoder='libx264')
                renderer=DeluxeRenderer(cfg,features,story,characters=[CharacterSpec(str(path))])
                if gpu:self.assertTrue(renderer.gpu_active,renderer.gpu_error)
                report=renderer.render(self.work/f'{mode}.mp4')
                self.assertEqual(report['frames'],24)
                captured.append(FrameSink.captures[-1].images)
        for mode in [1,2]:
            for i in range(24):np.testing.assert_array_equal(captured[0][i],captured[mode][i],err_msg=f'mode={mode} frame={i}')

    def _source_video(self):
        path=self.work/'source.mkv'
        frames=np.zeros((18,72,128,3),np.uint8)
        for i in range(len(frames)):
            frames[i,:]=(i*13,220-i*7,i*5)
            cv2.putText(frames[i],str(i),(8,45),cv2.FONT_HERSHEY_SIMPLEX,.6,(255,255,255),1)
        cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','bgr24','-s','128x72','-r','12','-i','-',
             '-c:v','ffv1','-threads','1',str(path)]
        subprocess.run(cmd,input=frames.tobytes(),check=True)
        return path,frames

    def test_sequential_decoder_avoids_seeks_and_reuses_exact_frames(self):
        path,frames=self._source_video();pool=MediaPool([str(path)],128,72)
        try:
            for i in range(36):
                actual=pool.get(0,i/24)
                np.testing.assert_array_equal(actual,frames[int(i/24*12)])
            self.assertEqual(pool.stats['seeks'],0)
            self.assertEqual(pool.stats['reads'],18)
            self.assertEqual(pool.stats['reused_frames'],18)
            for t in [0., .75, 1.6, .25]:
                target=int(t*12)%len(frames)
                np.testing.assert_array_equal(pool.get(0,t),frames[target])
        finally:pool.close()

    def test_media_prefetch_ownership_and_loop(self):
        path,_=self._source_video();features,story=project(self.work,duration=2)
        cfg=DeluxeConfig(width=128,height=72,fps=24,use_gpu=False,encoder='libx264',performance='maximum')
        renderer=DeluxeRenderer(cfg,features,story,[str(path)])
        with patch('subterra_deluxe.renderer.AsyncVideoWriter',FrameSink):
            report=renderer.render(self.work/'prefetch.mp4')
        self.assertEqual(report['frames'],48)
        self.assertGreater(report['media_decode']['reused_frames'],0)
        self.assertLess(report['media_decode']['seeks'],5)

    def test_image_cache_is_bounded_and_lazy(self):
        paths=[]
        for i in range(8):
            path=self.work/f'{i}.png';cv2.imwrite(str(path),np.full((800,800,3),i,np.uint8));paths.append(str(path))
        pool=MediaPool(paths,512,512,cache_mb=1)
        self.assertEqual(pool.cache_bytes,0)
        for i in range(8):pool.get(i,0)
        self.assertLessEqual(pool.cache_bytes,1024**2)
        pool.close();self.assertEqual(pool.cache_bytes,0)

    def test_plan_bounds_workers_and_memory(self):
        for profile in ['balanced','maximum','compatibility']:
            cfg=DeluxeConfig(performance=profile,cpu_workers=64,ram_budget_mb=4096)
            plan=make_plan(cfg,1920,1080,available_mb=4096,logical_cpus=4)
            self.assertLessEqual(plan.workers,4)
            self.assertLessEqual(plan.estimated_peak_mb,plan.memory_budget_mb)
            self.assertLessEqual(plan.memory_budget_mb,int(4096*.4))
            self.assertGreaterEqual(plan.inflight,plan.workers)
        with self.assertRaises(ValueError):make_plan(DeluxeConfig(),3840,2160,available_mb=100)

    def test_old_configuration_loads_and_explicit_preset_wins(self):
        old={'width':128,'height':72,'ffmpeg_preset':'p5'}
        path=self.work/'config.json';path.write_text(json.dumps(old))
        cfg=DeluxeConfig.load(path);cfg.validate()
        self.assertEqual(make_plan(cfg,128,72).encoder_preset,'p5')
        for kw in [dict(cpu_workers=-1),dict(ram_budget_mb=-3),dict(performance='unknown')]:
            with self.assertRaises(ValueError):DeluxeConfig(**kw).validate()

    def test_real_mp4_audio_frame_count_and_duration(self):
        features,story=project(self.work)
        audio=self.work/'tone.wav'
        with wave.open(str(audio),'wb') as f:
            f.setparams((1,2,16000,0,'NONE','not compressed'))
            t=np.arange(32000)/16000
            f.writeframes((np.sin(t*2*np.pi*330)*4000).astype('<i2').tobytes())
        out=self.work/'film.mp4'
        cfg=DeluxeConfig(width=128,height=72,fps=24,seed=321,use_gpu=False,performance='maximum',encoder='auto')
        progress=[]
        report=DeluxeRenderer(cfg,features,story).render(out,audio,lambda a,b:progress.append(a))
        streams=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-of','json',str(out)]))['streams']
        video=next(s for s in streams if s['codec_type']=='video')
        sound=next(s for s in streams if s['codec_type']=='audio')
        self.assertEqual(int(video['nb_read_frames']),24)
        self.assertEqual((video['width'],video['height']),(128,72))
        self.assertEqual(video['avg_frame_rate'],'24/1')
        self.assertAlmostEqual(float(video['duration']),1.,places=2)
        self.assertLess(abs(float(sound['duration'])-1),.15)
        self.assertEqual(progress,sorted(progress));self.assertEqual(progress[-1],24)
        self.assertTrue(report['single_pass_audio'])
        self.assertFalse(list(self.work.glob('subterra_render_*')))

    def test_hybrid_parallel_preserves_shot_order_and_frame_counts(self):
        from subterra_deluxe.ai.hybrid import assemble_hybrid
        source,frames=self._source_video()
        clips=self.work/'clips';clips.mkdir()
        # Deterministic fixture for the replacement clip, not AI-generated video.
        shutil.copyfile(source,clips/'shot_0000.mp4')
        manifest=self.work/'manifest.json'
        manifest.write_text(json.dumps({'shots':[
            {'shot':0,'start':0.,'end':.5,'fps':12.,'output_name':'shot_0000.mp4'},
            {'shot':1,'start':.5,'end':1.,'fps':12.,'output_name':'shot_0001.mp4'},
            {'shot':2,'start':1.,'end':1.5,'fps':12.,'output_name':'shot_0002.mp4'}]}))
        outputs=[]
        for mode in ['compatibility','maximum']:
            out=self.work/f'hybrid_{mode}.mp4'
            report=assemble_hybrid(manifest,source,clips,out,encoder='libx264',performance=mode)
            self.assertEqual(report['target_total_frames'],18)
            self.assertEqual((report['ai_shots'],report['fallback_shots']),(1,2))
            self.assertEqual([m['shot'] for m in report['mapping']],[0,1,2])
            raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(out),'-f','rawvideo','-pix_fmt','bgr24','-'])
            decoded=np.frombuffer(raw,np.uint8).reshape(-1,72,128,3)
            self.assertEqual(len(decoded),18)
            for i in [1,7,13]:
                self.assertLess(float(np.abs(decoded[i].astype(float)-frames[i]).mean()),12)
            outputs.append(decoded)
        self.assertEqual(outputs[0].shape,outputs[1].shape)

    def test_ffmpeg_failure_propagates_without_hanging(self):
        bad=['ffmpeg','-v','error','-invalid_option']
        writer=AsyncVideoWriter(bad,128,72,1)
        try:
            with self.assertRaises(RuntimeError):
                for _ in range(20):writer.submit(np.zeros((72,128,3),np.uint8))
                writer.finish()
        finally:writer.abort()
        self.assertFalse(writer.thread.is_alive())
        self.assertIsNotNone(writer.proc.poll())

    def test_worker_failure_keeps_old_output_and_restores_native_threads(self):
        features,story=project(self.work);out=self.work/'final.mp4';out.write_bytes(b'previous movie')
        cfg=DeluxeConfig(width=128,height=72,fps=24,use_gpu=False,encoder='libx264')
        renderer=DeluxeRenderer(cfg,features,story);threads=cv2.getNumThreads()
        real=renderer._prepare
        def fail(frame,shot,t,i,*args):
            if i==3:raise ValueError('injected effect error')
            return real(frame,shot,t,i,*args)
        with patch.object(renderer,'_prepare',fail):
            with self.assertRaisesRegex(ValueError,'injected effect error'):renderer.render(out)
        self.assertEqual(out.read_bytes(),b'previous movie')
        self.assertEqual(cv2.getNumThreads(),threads)
        self.assertFalse(list(self.work.glob('subterra_render_*')))
        self.assertFalse(any(t.name.startswith('subterra-') for t in threading.enumerate()))

    def test_gpu_failure_midfilm_falls_back_and_finishes(self):
        features,story=project(self.work)
        from subterra_deluxe.scene_cpu import CPUSceneRenderer
        class FailingGPU:
            def render(self,*args):raise RuntimeError('injected driver error')
            def close(self):pass
        cfg=DeluxeConfig(width=128,height=72,fps=12,use_gpu=False,encoder='libx264')
        renderer=DeluxeRenderer(cfg,features,story)
        renderer.base=FailingGPU();renderer.gpu_active=True
        with patch('subterra_deluxe.renderer.AsyncVideoWriter',FrameSink):report=renderer.render(self.work/'fallback.mp4')
        self.assertEqual(report['frames'],12)
        self.assertFalse(report['gpu_active_at_finish'])
        self.assertIn('injected driver error',report['gpu_error'])


if __name__=='__main__':unittest.main(verbosity=2)
