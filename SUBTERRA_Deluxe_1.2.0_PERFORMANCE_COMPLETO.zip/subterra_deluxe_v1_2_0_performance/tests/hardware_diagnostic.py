from __future__ import annotations
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from subterra_deluxe.audio_mux import encoder_works, ffmpeg_encoders
from subterra_deluxe.config import DeluxeConfig
from subterra_deluxe.performance import make_plan, adapt_for_encoder

report={'version':'1.2.0','os':platform.platform(),'python':sys.version.split()[0],
        'cpu':platform.processor(),'logical_cpus':os.cpu_count(),'ffmpeg':shutil.which('ffmpeg'),
        'ffprobe':shutil.which('ffprobe'),'nvidia_smi':shutil.which('nvidia-smi')}
try:
    import psutil
    memory=psutil.virtual_memory()
    report.update(ram_total_gb=round(memory.total/2**30,2),ram_available_gb=round(memory.available/2**30,2),
                  free_disk_gb=round(shutil.disk_usage(ROOT).free/2**30,2))
except Exception as exc:report['memory_detection_error']=repr(exc)
if report['nvidia_smi']:
    try:report['nvidia']=subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,memory.free,driver_version','--format=csv,noheader'],text=True,timeout=15).strip()
    except Exception as exc:report['nvidia_error']=repr(exc)
encoders=ffmpeg_encoders();actual={}
for encoder in ['h264_nvenc','hevc_nvenc','av1_nvenc','libx264']:
    advertised=encoder in encoders
    actual[encoder]={'advertised':advertised,'real_encode_ok':encoder_works(encoder) if advertised else False}
report['encoders']=actual
try:
    from subterra_deluxe.gpu_engine import GPUSceneRenderer
    gpu=GPUSceneRenderer(64,64,7)
    try:
        gpu.self_test();report['opengl_renderer']=gpu.renderer_name;report['opengl_self_test']=True
        report['opengl_software_renderer']=any(x in gpu.renderer_name.lower() for x in ['llvmpipe','softpipe','software','swiftshader'])
    finally:gpu.close()
except Exception as exc:report['opengl_error']=repr(exc)
encoder='h264_nvenc' if actual['h264_nvenc']['real_encode_ok'] else 'libx264'
for mode in ['balanced','maximum']:
    try:report['plan_'+mode]=adapt_for_encoder(make_plan(DeluxeConfig(performance=mode),1920,1080),encoder,1920,1080).as_dict()
    except Exception as exc:report['plan_'+mode]={'error':str(exc)}
path=ROOT/'hardware_report_deluxe.json';path.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(report,indent=2,ensure_ascii=False));print('\nRelatório:',path)
