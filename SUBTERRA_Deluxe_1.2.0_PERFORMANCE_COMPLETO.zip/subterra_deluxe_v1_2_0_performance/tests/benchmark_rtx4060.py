"""Local, reproducible comparison of three scheduling/encoding profiles."""
from __future__ import annotations
import argparse
import json
import platform
import statistics
import subprocess
import sys
import time
import wave
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from subterra_deluxe.config import DeluxeConfig
from subterra_deluxe.director import make_story
from subterra_deluxe.features import analyse_audio
from subterra_deluxe.renderer import DeluxeRenderer
from subterra_deluxe.styles import STYLE_NAMES


def make_audio(path: Path, seconds: float, sr: int = 44100):
    t=np.arange(int(seconds*sr))/sr
    y=.5*np.exp(-(t%.5)/.07)*np.sin(2*np.pi*55*t)+.20*np.sin(2*np.pi*110*t)
    samples=(np.column_stack([y,y])*26000).astype('<i2')
    with wave.open(str(path),'wb') as stream:
        stream.setparams((2,2,sr,0,'NONE','not compressed'));stream.writeframes(samples.tobytes())


def main():
    p=argparse.ArgumentParser(description='Comparação local: Compatibilidade x Equilibrado x Máximo')
    p.add_argument('--audio');p.add_argument('--width',type=int,default=1920);p.add_argument('--height',type=int,default=1080)
    p.add_argument('--fps',type=float,default=30);p.add_argument('--seconds',type=float,default=8)
    p.add_argument('--quality',choices=['preview','fast','deluxe','master'],default='deluxe')
    p.add_argument('--style',choices=STYLE_NAMES,default='nolan_odisseia');p.add_argument('--encoder',default='auto')
    p.add_argument('--cpu',action='store_true');p.add_argument('--repeats',type=int,default=2)
    p.add_argument('--same-preset',action='store_true',help='Fixar p5 em todos os perfis para isolar paralelismo')
    p.add_argument('--media',action='append',default=[]);p.add_argument('--synthetic',action='store_true',help='Omitir análise musical para medir apenas renderização')
    ns=p.parse_args()
    if ns.seconds<=0 or ns.repeats<1:p.error('seconds e repeats devem ser positivos')
    work=ROOT/'benchmark_output';work.mkdir(exist_ok=True)
    audio=Path(ns.audio).resolve() if ns.audio else work/'benchmark_audio.wav'
    if not ns.audio:make_audio(audio,max(ns.seconds,12))
    seed=1223951587;story=work/'story.json'
    if ns.synthetic:
        # Fixture fixed across all modes: no music-analysis/JIT time in render timing.
        t=np.linspace(0,ns.seconds,max(80,int(ns.seconds*43)),dtype=np.float32)
        features=work/'features.npz'
        np.savez(features,times=t,energy=.5+.2*np.sin(t),impact=.5+.4*np.cos(t*13),brightness=.5+.1*np.sin(t),beat_times=np.arange(0,ns.seconds,.5))
        shots=[]
        for i in range(3):
            shots.append(dict(shot=i,start=i*ns.seconds/3,end=(i+1)*ns.seconds/3,
                       scene=['signal_cathedral','subterranean_architecture','liquid_chrome'][i],
                       seed=seed+i,camera=['push','drift','orbit'][i],transition=['cut','dissolve','film_burn'][i]))
        story.write_text(json.dumps(dict(duration_seconds=ns.seconds,shots=shots)))
    else:
        analysis,features=analyse_audio(audio,work/'audio_cache')
        make_story(analysis,story,seed,.62,ns.style,0)
    profiles=['compatibility','balanced','maximum'];runs={mode:[] for mode in profiles}
    for repeat in range(ns.repeats):
        # Rotate order to reduce the effect of warm caches/thermal changes.
        for mode in profiles[repeat%3:]+profiles[:repeat%3]:
            cfg=DeluxeConfig(width=ns.width,height=ns.height,fps=ns.fps,seed=seed,style=ns.style,
                quality=ns.quality,preview_seconds=ns.seconds,encoder=ns.encoder,use_gpu=not ns.cpu,
                performance=mode,ffmpeg_preset='p5' if ns.same_preset else 'auto')
            renderer=DeluxeRenderer(cfg,features,story,ns.media)
            print(f'\n{mode} · repetição {repeat+1}/{ns.repeats} · {renderer.renderer_name}',flush=True)
            output=work/f'{mode}_{repeat+1}.mp4'
            report=renderer.render(output,audio,lambda a,b:print(f'\r{a}/{b}',end='',flush=True))
            video=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-select_streams','v:0',
                '-show_entries','stream=nb_read_frames,width,height,avg_frame_rate','-of','json',str(output)]))['streams'][0]
            if int(video['nb_read_frames'])!=report['frames']:raise RuntimeError('FFprobe detectou vídeo incompleto.')
            report['ffprobe']=video;runs[mode].append(report)
            print(f'\n{report["elapsed_seconds"]} s · {report["fps_render"]} fps',flush=True)
    summary={}
    baseline=statistics.median(r['elapsed_seconds'] for r in runs['compatibility'])
    for mode,items in runs.items():
        elapsed=statistics.median(r['elapsed_seconds'] for r in items)
        summary[mode]={'median_seconds':round(elapsed,3),'speedup_vs_compatibility':round(baseline/elapsed,3),
                       'median_fps':round(statistics.median(r['fps_render'] for r in items),2)}
    result={'version':'1.2.0','environment':{'os':platform.platform(),'python':platform.python_version(),
            'numpy':np.__version__},'arguments':vars(ns),'comparison':'updated compatibility profile, not the original 1.1.2 binary',
            'same_encoder_preset':ns.same_preset,'summary':summary,'runs':runs}
    path=work/'benchmark_comparativo.json';path.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
    print('\n'+json.dumps(summary,indent=2,ensure_ascii=False));print('\nRelatório:',path)
    return 0

if __name__=='__main__':raise SystemExit(main())
