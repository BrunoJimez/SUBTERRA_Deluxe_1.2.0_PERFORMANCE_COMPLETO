from __future__ import annotations
import hashlib, json, math, os, shutil, subprocess, sys, time, traceback
from difflib import SequenceMatcher
from pathlib import Path
import cv2, numpy as np, soundfile as sf

ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from subterra_deluxe.config import DeluxeConfig
from subterra_deluxe.features import analyse_audio
from subterra_deluxe.director import make_story
from subterra_deluxe.renderer import DeluxeRenderer
from subterra_deluxe.media import CharacterSpec, cover
from subterra_deluxe.scene_cpu import CPUSceneRenderer
from subterra_deluxe.styles import STYLE_SPECS,StyleState,apply_style,style_metrics,export_style_specs
from subterra_deluxe.ai.manifest import build_multishot_manifest
from subterra_deluxe.ai.comfyui import build_auto_workflow, validate_workflow
from subterra_deluxe.ai.hybrid import assemble_hybrid

OUT=ROOT/'tests'/'_validation';shutil.rmtree(OUT,ignore_errors=True);OUT.mkdir(parents=True)
results=[]
def record(name,ok,detail):results.append({'test':name,'ok':bool(ok),'detail':detail});print(('PASS' if ok else 'FAIL'),name,detail)

def synth_audio(path,duration=10.0,sr=44100):
 t=np.arange(int(duration*sr))/sr
 beat=(np.sin(2*np.pi*2.2*t)>0.92).astype(float);kick=np.sin(2*np.pi*(55+35*np.exp(-(t%(.454))*18))*t)*np.exp(-(t%(.454))*12)
 bass=.18*np.sin(2*np.pi*55*t)+.08*np.sin(2*np.pi*110*t);pad=.07*np.sin(2*np.pi*220*t)+.05*np.sin(2*np.pi*330*t)
 y=np.tanh((kick*.45+bass+pad+beat*.04)*1.8).astype(np.float32);sf.write(path,y,sr);return path

def manual_project(folder,duration,seed,style,character_count=0):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
 times=np.linspace(0,duration,max(20,int(duration*43)),dtype=np.float32)
 energy=(.45+.30*np.sin(times*.7)**2).astype(np.float32);impact=np.zeros_like(times)
 for bt in np.arange(0,duration,.454):impact+=np.exp(-np.maximum(0,times-bt)*14)*(times>=bt)
 impact=np.clip(impact,0,1).astype(np.float32);brightness=(.42+.18*np.sin(times*.31+1)).astype(np.float32)
 texture=(.35+.25*np.sin(times*.19)**2).astype(np.float32);flux=(.3+.5*impact).astype(np.float32)
 npz=folder/'features.npz';np.savez_compressed(npz,times=times,energy=energy,impact=impact,brightness=brightness,texture=texture,flux=flux,sub=energy,bass=energy,mid=brightness,presence=flux,air=brightness,beat_times=np.arange(0,duration,.454,dtype=np.float32),section_bounds=np.array([0,duration/3,2*duration/3,duration],np.float32))
 analysis={'source':str(folder/'test_audio.wav'),'duration_seconds':duration,'estimated_bpm':132.0,'sections':[{'index':0,'start':0,'end':duration/3,'role':'intro','energy':.42},{'index':1,'start':duration/3,'end':2*duration/3,'role':'drop','energy':.78},{'index':2,'start':2*duration/3,'end':duration,'role':'outro','energy':.5}]}
 ap=folder/'analysis.json';ap.write_text(json.dumps(analysis),encoding='utf-8');sp=folder/'story.json';make_story(ap,sp,seed,.68,style,character_count);return npz,sp

try:
 import compileall
 ok=compileall.compile_dir(str(ROOT/'subterra_deluxe'),quiet=1) and compileall.compile_file(str(ROOT/'gui.py'),quiet=1)
 record('compilacao',ok,'módulos Deluxe compilados')
except Exception as e:record('compilacao',False,repr(e))


try:
 # Regression: algumas proporções geravam 1 px a menos por int(w*scale).
 cases=[(832,1216,960,540),(103,100,1920,1080),(154,100,640,360)]
 details=[]
 for sw,sh,dw,dh in cases:
  src=np.zeros((sh,sw,3),np.uint8)
  fitted=cover(src,dw,dh)
  assert fitted.shape==(dh,dw,3), (sw,sh,dw,dh,fitted.shape)
  # Também prova que a operação que falhava no relatório agora aceita a mídia.
  base=np.zeros((dh,dw,3),np.uint8)
  mixed=cv2.addWeighted(base,.72,fitted,.35,0)
  assert mixed.shape==base.shape
  details.append(f'{sw}x{sh}->{fitted.shape[1]}x{fitted.shape[0]}')
 # Defesa adicional do fallback CPU para uma mídia deliberadamente incompatível.
 cpu=CPUSceneRenderer(320,180,7)
 odd=np.zeros((181,319,4),np.uint8)
 fr=cpu.render('subterranean_architecture',0.1,.5,.2,.5,11,odd)
 assert fr.shape==(180,320,3)
 record('contrato_midia_dimensoes',True,'; '.join(details)+'; CPU normalizou BGRA 319x181')
except Exception as e:record('contrato_midia_dimensoes',False,traceback.format_exc())

try:
 shader=(ROOT/'subterra_deluxe'/'shaders'/'deluxe_scene.frag').read_text(encoding='utf-8')
 declaration='uniform float uBright;'
 body=shader.replace(declaration,'',1)
 from subterra_deluxe.gpu_engine import GPUSceneRenderer
 class _Slot:
  def __init__(self):self.value=None
 class _Program:
  def __init__(self):self.slot=_Slot()
  def __getitem__(self,name):
   if name=='present':return self.slot
   raise KeyError(name)
 fake=GPUSceneRenderer.__new__(GPUSceneRenderer);fake.prog=_Program()
 ok=declaration in shader and 'uBright' in body and fake._set_uniform('present',.5,required=True) and fake._set_uniform('optimised_out',.5,required=False) is False
 record('contrato_gpu_uniformes',ok,'uBright ativo no shader; uniformes otimizados tratados sem KeyError')
except Exception as e:record('contrato_gpu_uniformes',False,traceback.format_exc())

try:
 item={'shot':0,'duration':2.0,'width':640,'height':360,'fps':24.0,'frames':49,'seed':1234,'prompt':'signal cathedral','negative_prompt':'text, watermark','output_name':'shot_0000.mp4'}
 discovery={'resolved':{'wan_i2v':None,'wan_t2v':'wan2.1_t2v_1.3B_fp16.safetensors','text_encoder':'umt5_xxl_fp8_e4m3fn_scaled.safetensors','vae':'wan_2.1_vae.safetensors','clip_vision':None},'image_to_video_ready':False,'text_to_video_ready':True,'issues':['I2V ausente']}
 rejected=False
 try:build_auto_workflow(item,discovery)
 except RuntimeError:rejected=True
 workflow,profile=build_auto_workflow(item,discovery,allow_text_to_video=True);validation=validate_workflow(workflow)
 fun_discovery={'resolved':{'wan_i2v':None,'wan_fun_camera':'wan2.1_fun_camera_v1.1_1.3B_bf16.safetensors','wan_t2v':'wan2.1_t2v_1.3B_fp16.safetensors','text_encoder':'umt5_xxl_fp8_e4m3fn_scaled.safetensors','vae':'wan_2.1_vae.safetensors','clip_vision':'clip_vision_h.safetensors'},'image_to_video_ready':True,'fun_camera_ready':True,'text_to_video_ready':True,'issues':[]}
 upload={'name':'shot_0000_keyframe.png','subfolder':'subterra_deluxe','type':'input'}
 fun_workflow,fun_profile=build_auto_workflow(item,fun_discovery,upload);fun_validation=validate_workflow(fun_workflow)
 ok=rejected and profile['mode']=='text-to-video-diagnostic' and '52' not in workflow and validation['nodes']==11 and fun_profile['id']=='wan_fun_camera_i2v' and fun_workflow['56']['inputs']['start_image']==['52',0] and fun_validation['nodes']==15
 record('comfyui_autoconfiguracao_segura',ok,'T2V não se passa por I2V; Fun Camera conecta keyframe, CLIP Vision e câmera')
except Exception as e:record('comfyui_autoconfiguracao_segura',False,traceback.format_exc())

try:
 base=CPUSceneRenderer(640,360,127).render('neon_megacity',1.2,.62,.73,.48,341)
 frames={};metrics={};hashes={}
 for i,name in enumerate(STYLE_SPECS):
  fr=apply_style(base,name,1.0,StyleState(),1.2,i,.73,991)
  frames[name]=fr;metrics[name]=style_metrics(fr);hashes[name]=hashlib.sha256(fr.tobytes()).hexdigest()
 unique=len(set(hashes.values()))
 # Metrics must not all collapse to one output; check mean pairwise absolute difference against clean.
 clean=frames['clean_deluxe'].astype(np.float32);diffs={k:float(np.mean(np.abs(v.astype(np.float32)-clean))) for k,v in frames.items() if k!='clean_deluxe'}
 ok=unique==len(STYLE_SPECS) and min(diffs.values())>0.7
 record('estilos_distintos',ok,f'{unique}/{len(STYLE_SPECS)} hashes únicos; diferença mínima {min(diffs.values()):.2f}')
 (OUT/'style_metrics.json').write_text(json.dumps({'metrics':metrics,'hashes':hashes,'diff_from_clean':diffs},indent=2,ensure_ascii=False),encoding='utf-8')
 # gallery
 cols=4;tw,th=320,180;rows=math.ceil(len(frames)/cols);sheet=np.zeros((rows*(th+30),cols*tw,3),np.uint8);sheet[:]=12
 for idx,(name,fr) in enumerate(frames.items()):
  thumb=cv2.resize(fr,(tw,th));x=(idx%cols)*tw;y=(idx//cols)*(th+30);sheet[y:y+th,x:x+tw]=thumb;cv2.putText(sheet,name[:34],(x+6,y+th+20),cv2.FONT_HERSHEY_SIMPLEX,.42,(235,235,235),1,cv2.LINE_AA)
 cv2.imwrite(str(ROOT/'subterra_deluxe_style_gallery.jpg'),sheet,[cv2.IMWRITE_JPEG_QUALITY,93])
except Exception as e:record('estilos_distintos',False,traceback.format_exc())

try:
 # Originality check: no exact source file is shared with the analysed TUF archive.
 tuf=Path('/mnt/data/work_rebuild/techno_src/tuf')
 new=list((ROOT/'subterra_deluxe').rglob('*.py'))
 old=list(tuf.rglob('*.py')) if tuf.exists() else []
 exact=[];similar=[]
 for n in new:
  nt=n.read_text(encoding='utf-8',errors='ignore')
  nh=hashlib.sha256(nt.encode()).hexdigest()
  for o in old:
   ot=o.read_text(encoding='utf-8',errors='ignore')
   if hashlib.sha256(ot.encode()).hexdigest()==nh:exact.append((str(n.relative_to(ROOT)),str(o.relative_to(tuf))))
   if len(nt)>600 and len(ot)>600:
    ratio=SequenceMatcher(None,nt,ot,autojunk=True).ratio()
    if ratio>.70:similar.append((str(n.relative_to(ROOT)),str(o.relative_to(tuf)),round(ratio,3)))
 ok=not exact and not similar
 record('originalidade_codigo',ok,f'exatos={len(exact)}, similaridade>0.70={len(similar)}')
 (OUT/'originality_audit.json').write_text(json.dumps({'exact_matches':exact,'high_similarity':similar,'new_files':len(new),'reference_files':len(old)},indent=2,ensure_ascii=False),encoding='utf-8')
except Exception as e:record('originalidade_codigo',False,traceback.format_exc())

try:
 audio=synth_audio(OUT/'test_audio.wav',6.0)
 features,story=manual_project(OUT/'work',6.0,123456789,'nolan_odisseia',0)
 cfg=DeluxeConfig(width=640,height=360,fps=24,seed=123456789,style='nolan_odisseia',quality='preview',internal_scale=1.0,encoder='libx264',ffmpeg_preset='veryfast',audio_mode='preserve',preview_seconds=6,use_gpu=False)
 cfg.save(OUT/'work'/'render_config.json');r=DeluxeRenderer(cfg,features,story);rep=r.render(ROOT/'subterra_deluxe_rebuilt_demo.mp4',audio)
 cap=cv2.VideoCapture(str(ROOT/'subterra_deluxe_rebuilt_demo.mp4'));frames=int(cap.get(cv2.CAP_PROP_FRAME_COUNT));fps=cap.get(cv2.CAP_PROP_FPS);cap.release()
 ok=frames>=140 and abs(fps-24)<.1
 record('render_demo',ok,f'{frames} quadros, {fps:.2f} fps, {rep["fps_render"]} fps de render')
except Exception as e:record('render_demo',False,traceback.format_exc())

try:
 # Character-integrated preview using bundled assets if available.
 assets=list((ROOT/'examples'/'assets').glob('*.png'))[:2]
 if assets:
  audio=OUT/'test_audio.wav';chars=[CharacterSpec(str(p),'protagonist',p.stem) for p in assets];features,story=manual_project(OUT/'work_char',6.0,849201337,'neon_graphic_grit',len(chars))
  cfg=DeluxeConfig(width=640,height=360,fps=24,seed=849201337,style='neon_graphic_grit',quality='preview',encoder='libx264',ffmpeg_preset='veryfast',preview_seconds=6,use_gpu=False)
  rep=DeluxeRenderer(cfg,features,story,characters=chars).render(ROOT/'subterra_deluxe_cyber_demo.mp4',audio)
  record('render_personagens',Path(rep['output']).exists(),f'{len(chars)} personagens; {rep["frames"]} quadros')
 else:record('render_personagens',False,'assets de exemplo ausentes')
except Exception as e:record('render_personagens',False,traceback.format_exc())

try:
 # Style comparison video: same moving source, every preset gets a labelled segment.
 audio=OUT/'comparison_audio.wav';synth_audio(audio,len(STYLE_SPECS)*.55,44100)
 w,h,fps=640,360,24;silent=OUT/'style_compare_silent.mp4';cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','bgr24','-s',f'{w}x{h}','-r',str(fps),'-i','-','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p',str(silent)]
 proc=subprocess.Popen(cmd,stdin=subprocess.PIPE);base_renderer=CPUSceneRenderer(w,h,442);frame_no=0
 for si,(name,spec) in enumerate(STYLE_SPECS.items()):
  state=StyleState()
  for j in range(7):
   t=frame_no/fps;base=base_renderer.render('waveform_city',t,.62,.70 if j in {0,6} else .25,.55,993+si)
   fr=apply_style(base,name,1.0,state,t,j,.7 if j in {0,6} else .25,731+si);cv2.rectangle(fr,(0,h-34),(w,h),(0,0,0),-1);cv2.putText(fr,name,(12,h-11),cv2.FONT_HERSHEY_SIMPLEX,.62,(245,245,245),1,cv2.LINE_AA);proc.stdin.write(fr.tobytes());frame_no+=1
 proc.stdin.close();proc.wait();subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(silent),'-i',str(audio),'-c:v','copy','-c:a','aac','-b:a','192k','-shortest',str(ROOT/'subterra_deluxe_style_comparison.mp4')],check=True);silent.unlink(missing_ok=True)
 record('video_comparacao_estilos',(ROOT/'subterra_deluxe_style_comparison.mp4').exists(),f'{len(STYLE_SPECS)} presets no mesmo material')
except Exception as e:record('video_comparacao_estilos',False,traceback.format_exc())

try:
 # Hybrid assembly: one AI replacement plus deterministic procedural fallbacks.
 ai_dir=OUT/'ai_shots';manifest=build_multishot_manifest(OUT/'work'/'story.json',ai_dir,ROOT/'subterra_deluxe_rebuilt_demo.mp4',320,180,24,'ltx_video_q8')
 data=json.loads(Path(manifest).read_text(encoding='utf-8'));first=data['shots'][0]
 generated=ai_dir/'shot_0000.mp4'
 subprocess.run(['ffmpeg','-y','-hide_banner','-loglevel','error','-ss',str(first['start']),'-i',str(ROOT/'subterra_deluxe_rebuilt_demo.mp4'),'-t',str(first['duration']),'-vf','hue=h=100:s=1.2','-an','-c:v','libx264','-preset','veryfast','-crf','18',str(generated)],check=True)
 hrep=assemble_hybrid(manifest,ROOT/'subterra_deluxe_rebuilt_demo.mp4',ai_dir,OUT/'hybrid_test.mp4',OUT/'test_audio.wav','libx264')
 cap=cv2.VideoCapture(str(OUT/'hybrid_test.mp4'));dur=cap.get(cv2.CAP_PROP_FRAME_COUNT)/max(cap.get(cv2.CAP_PROP_FPS),1);cap.release()
 ok=hrep['ai_shots']==1 and hrep['fallback_shots']>=1 and abs(dur-6.0)<.15
 record('montagem_hibrida_ia',ok,f"IA={hrep['ai_shots']}, fallback={hrep['fallback_shots']}, duração={dur:.2f}s")
except Exception as e:record('montagem_hibrida_ia',False,traceback.format_exc())

export_style_specs(ROOT/'style_specs.json')
report={'version':'1.2.0-performance','passed':sum(r['ok'] for r in results),'total':len(results),'results':results}
(ROOT/'VALIDATION_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
md=['# Relatório de validação — SUBTERRA Deluxe 1.2.0 · desempenho','',f"**Resultado:** {report['passed']}/{report['total']} testes aprovados.",'']
for r in results:md.append(f"- {'PASS' if r['ok'] else 'FAIL'} — **{r['test']}**: {r['detail']}")
(ROOT/'VALIDATION_REPORT.md').write_text('\n'.join(md),encoding='utf-8')
if report['passed']!=report['total']:raise SystemExit(1)
