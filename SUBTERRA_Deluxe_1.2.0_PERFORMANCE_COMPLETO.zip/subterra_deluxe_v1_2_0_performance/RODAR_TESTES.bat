@echo off
setlocal
cd /d "%~dp0"
if exist "C:\ffmpeg\bin\ffmpeg.exe" set "PATH=C:\ffmpeg\bin;%PATH%"
if not exist .venv\Scripts\python.exe (
  echo Execute INSTALAR_WINDOWS.bat primeiro.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m unittest discover -s tests -p "test_*.py" -v
if errorlevel 1 goto falha
.venv\Scripts\python.exe tests\test_gpu_uniform_contract.py
if errorlevel 1 goto falha
.venv\Scripts\python.exe tests\run_validation.py
if errorlevel 1 goto falha
echo Todos os testes foram concluidos.
pause
exit /b 0
:falha
echo Houve falha em um teste. Leia os detalhes acima.
pause
exit /b 1
