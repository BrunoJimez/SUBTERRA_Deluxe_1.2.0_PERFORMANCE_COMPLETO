@echo off
setlocal
cd /d "%~dp0"
if exist "C:\ffmpeg\bin\ffmpeg.exe" set "PATH=C:\ffmpeg\bin;%PATH%"
if not exist .venv\Scripts\python.exe (
  echo Execute INSTALAR_WINDOWS.bat primeiro.
  pause
  exit /b 1
)
.venv\Scripts\python.exe tests\hardware_diagnostic.py
pause
