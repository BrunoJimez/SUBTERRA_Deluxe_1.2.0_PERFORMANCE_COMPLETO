from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

SCENE_IDS = {
    "subterranean_architecture": 0,
    "powerline_memory": 1,
    "waveform_city": 2,
    "liquid_chrome": 3,
    "neon_megacity": 4,
    "silhouette_club": 5,
    "monumental_desert": 6,
    "cyber_stage": 7,
    "signal_cathedral": 8,
    "character_corridor": 9,
    "glass_atrium": 10,
    "rain_transit": 11,
    "ink_apartment": 12,
    "hologram_plaza": 13,
    "orbital_ruins": 14,
}


class GPUSceneRenderer:
    """Renderizador OpenGL persistente do SUBTERRA Deluxe.

    Uniformes podem ser eliminados pelo compilador GLSL quando um driver conclui
    que não afetam a saída. O acesso direto ``programa[nome]`` levantava KeyError
    nesses casos. A escrita agora é centralizada e tolerante para uniformes
    opcionais, sem esconder a ausência dos uniformes realmente obrigatórios.
    """

    def __init__(self, width: int, height: int, seed: int):
        import moderngl

        self.mgl = moderngl
        self.w = width
        self.h = height
        self.seed = seed
        try:
            self.ctx = moderngl.create_standalone_context(require=330)
        except Exception:
            import sys
            if sys.platform != 'linux':
                raise
            self.ctx = moderngl.create_standalone_context(require=330, backend='egl')
        root = Path(__file__).parent / "shaders"
        vert = (root / "fullscreen.vert").read_text(encoding="utf-8")
        frag = (root / "deluxe_scene.frag").read_text(encoding="utf-8")
        self.prog = self.ctx.program(vertex_shader=vert, fragment_shader=frag)

        vertices = np.array([-1, -1, 3, -1, -1, 3], dtype="f4")
        self.vbo = self.ctx.buffer(vertices.tobytes())
        self.vao = self.ctx.vertex_array(self.prog, [(self.vbo, "2f", "in_pos")])
        self.tex = self.ctx.texture((width, height), 3, dtype="f1")
        self.fbo = self.ctx.framebuffer([self.tex])
        self._readback = np.empty((height, width, 3), dtype=np.uint8)
        self._set_uniform("uRes", (float(width), float(height)), required=True)

    def _set_uniform(self, name: str, value: Any, *, required: bool = False) -> bool:
        """Define um uniform e trata otimizações específicas de cada driver.

        Retorna ``True`` quando o uniform está ativo. Um uniform opcional ausente
        não interrompe o render. Um uniform obrigatório ausente produz erro com
        diagnóstico claro, em vez de um KeyError sem contexto.
        """
        try:
            self.prog[name].value = value
            return True
        except KeyError as exc:
            if required:
                raise RuntimeError(
                    f"Shader GPU incompatível: uniform obrigatório ausente: {name}"
                ) from exc
            return False

    @property
    def renderer_name(self) -> str:
        return str(self.ctx.info.get("GL_RENDERER", "OpenGL"))

    def self_test(self) -> None:
        """Compila, executa e lê um quadro antes do início do filme."""
        frame = self.render(
            "subterranean_architecture",
            t=0.125,
            energy=0.55,
            impact=0.25,
            brightness=0.60,
            shot_seed=self.seed or 1,
        )
        if frame.shape != (self.h, self.w, 3) or frame.dtype != np.uint8:
            raise RuntimeError(
                f"Autoteste GPU retornou quadro inválido: {frame.shape}, {frame.dtype}"
            )

    def render(
        self,
        scene: str,
        t: float,
        energy: float,
        impact: float,
        brightness: float,
        shot_seed: int,
        media=None,
    ) -> np.ndarray:
        self.fbo.use()
        self.ctx.viewport = (0, 0, self.w, self.h)

        # Todos estes uniformes participam do shader atual. A tolerância a
        # otimização de driver permanece como proteção para futuras variantes.
        self._set_uniform("uTime", float(t), required=True)
        self._set_uniform("uEnergy", float(energy), required=True)
        self._set_uniform("uImpact", float(impact), required=True)
        self._set_uniform("uBright", float(brightness), required=False)
        self._set_uniform("uSeed", float(shot_seed % 100000) * 0.001, required=True)
        self._set_uniform("uScene", int(SCENE_IDS.get(scene, 0)), required=True)

        self.vao.render(self.mgl.TRIANGLES, vertices=3)
        self.fbo.read_into(self._readback, components=3, alignment=1)
        # The owned copy is mandatory: CPU workers may still use earlier frames.
        arr = self._readback[::-1, :, ::-1].copy()

        if media is not None:
            import cv2
            from .media import cover

            # Defesa de composição: mesmo que a mídia venha de um decoder
            # externo com 1 px a menos/mais ou com 4 canais, normalize-a para o
            # framebuffer antes da aritmética OpenCV.
            media = cover(media, self.w, self.h)
            arr = cv2.addWeighted(arr, 0.72, media, 0.35, 0)
        return arr

    def close(self) -> None:
        for obj in [self.vao, self.vbo, self.fbo, self.tex, self.prog]:
            try:
                obj.release()
            except Exception:
                pass
        try:
            self.ctx.release()
        except Exception:
            pass
