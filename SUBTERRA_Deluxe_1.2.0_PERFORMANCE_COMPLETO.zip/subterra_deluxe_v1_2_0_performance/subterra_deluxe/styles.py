from __future__ import annotations

from dataclasses import dataclass, asdict
from functools import lru_cache
import json
import math
from pathlib import Path
from typing import Callable

import cv2
import numpy as np


@dataclass(frozen=True)
class StyleSpec:
    label: str
    family: str
    matrix: tuple[float, ...]
    lift: tuple[float, float, float] = (0, 0, 0)
    gamma: float = 1.0
    gain: float = 1.0
    contrast: float = 1.0
    saturation: float = 1.0
    bloom: float = 0.0
    grain: float = 0.0
    vignette: float = 0.0
    chroma_shift: float = 0.0
    posterize: int = 0
    scanlines: float = 0.0
    letterbox: float = 0.0
    temporal: str = "clean"
    overlay: str = "none"
    direction: str = "cinematic"


def _m(*v: float) -> tuple[float, ...]:
    return tuple(v)


# Each preset carries an independent colour transform, image treatment,
# temporal behaviour and direction/overlay. They are not aliases for palettes.
STYLE_SPECS: dict[str, StyleSpec] = {
    "clean_deluxe": StyleSpec("Clean Deluxe", "clean", _m(1.03,-.01,-.01,-.01,1.02,-.01,-.01,-.01,1.03), contrast=1.04, saturation=1.04, bloom=.08, grain=.025, vignette=.08, direction="neutral cinema"),
    "red_rose_glass": StyleSpec("Red Rose Glass", "icy_noir", _m(.58,.27,.10,.24,.42,.10,.08,.09,.25), lift=(.008,-.008,-.028), gamma=.94, gain=.96, contrast=1.38, saturation=.52, bloom=.15, grain=.17, vignette=.43, chroma_shift=.003, temporal="slow_ghost", overlay="halation", direction="icy cyan-black wet glass, controlled negative space, no interface text"),
    "red_rose_signal": StyleSpec("Red Rose Signal", "red_signal", _m(.76,.03,-.06,.03,.67,-.04,-.06,-.03,1.22), lift=(-.012,-.018,-.010), gamma=.89, gain=.98, contrast=1.43, saturation=.92, bloom=.11, grain=.20, vignette=.36, chroma_shift=.006, posterize=7, temporal="impact_repeat", overlay="ink_outline", direction="cyan-black signal damage with a single isolated blood-red accent"),
    "nolan_odisseia": StyleSpec("Nolan_Odisseia", "cinema", _m(1.10,.02,-.08,.01,1.01,-.05,-.05,.03,.95), lift=(-.025,-.020,-.015), gamma=.94, gain=.98, contrast=1.25, saturation=.70, bloom=.18, grain=.15, vignette=.28, chroma_shift=.002, letterbox=.105, temporal="cinema24", overlay="anamorphic", direction="monumental scale, practical light, negative space"),
    "mitsubishi_evo_1999_camcorder": StyleSpec("Mitsubishi EVO · Camcorder 1999", "tape", _m(1.06,.03,-.02,.01,.99,.01,-.03,.04,.94), gamma=.96, contrast=1.09, saturation=1.10, bloom=.12, grain=.20, vignette=.13, chroma_shift=.012, scanlines=.34, temporal="field_jitter", overlay="camcorder", direction="handheld consumer DV"),
    "trance_classics_late_90s": StyleSpec("Trance Classics · Late 90s", "club", _m(.95,.03,.12,-.02,.92,.18,.05,.03,1.12), gamma=.90, contrast=1.12, saturation=1.38, bloom=.48, grain=.07, vignette=.16, chroma_shift=.008, temporal="dream_ghost", overlay="starburst", direction="euphoric soft club montage"),
    "unrealistic_hacking": StyleSpec("Wildly Unrealistic Hacking", "terminal", _m(.35,.10,.02,.04,1.28,.04,.02,.22,.30), gamma=.92, contrast=1.22, saturation=.76, bloom=.16, grain=.08, vignette=.22, scanlines=.45, temporal="digital_stutter", overlay="hacking", direction="CRT interfaces and impossible code"),
    "cold_corporate_glass": StyleSpec("Cold Corporate Glass", "architecture", _m(.78,.08,.08,.02,.99,.10,.06,.14,1.12), lift=(-.015,-.005,.015), gamma=1.04, contrast=1.16, saturation=.60, bloom=.10, grain=.025, vignette=.10, temporal="clean", overlay="glass", direction="symmetrical glass interiors and clean tracking"),
    "yokohama_9pm": StyleSpec("9PM in Yokohama", "night_city", _m(.82,.03,.18,-.02,.91,.18,.12,.02,1.18), gamma=.89, contrast=1.20, saturation=1.25, bloom=.39, grain=.11, vignette=.28, chroma_shift=.007, temporal="neon_trail", overlay="rain", direction="wet neon city at night"),
    "gen_x_soft_club": StyleSpec("Gen X Soft Club", "soft_club", _m(.96,.06,.10,.04,.94,.12,.08,.04,1.02), gamma=.88, contrast=.94, saturation=.82, bloom=.52, grain=.10, vignette=.12, temporal="soft_hold", overlay="soft_club", direction="late-90s soft focus club fashion"),
    "go_death": StyleSpec("Go Death", "graphic_extreme", _m(1.20,-.10,-.10,-.04,.55,-.02,-.08,-.04,.45), gamma=.84, contrast=1.55, saturation=.25, bloom=.06, grain=.27, vignette=.38, posterize=4, temporal="impact_repeat", overlay="dust", direction="white-red-black brutal print"),
    "aesthetic_archive": StyleSpec("Aesthetic Archive", "archive", _m(1.03,.02,.02,.02,.98,.02,.02,.02,.95), gamma=.96, contrast=1.03, saturation=.72, bloom=.20, grain=.22, vignette=.20, temporal="archive_hold", overlay="date_stamp", direction="found-footage moodboard"),
    "junkieconcept": StyleSpec("Junkieconcept", "dirty_collage", _m(1.05,.04,-.02,.02,.91,.01,-.01,.02,.86), gamma=.90, contrast=1.25, saturation=.88, bloom=.07, grain=.30, vignette=.23, chroma_shift=.010, posterize=7, temporal="smear", overlay="xerox", direction="damaged editorial collage"),
    "dark_deco": StyleSpec("Dark Deco", "deco", _m(1.00,.07,-.08,.02,.88,-.04,-.09,.03,.72), lift=(-.025,-.02,-.01), gamma=.92, contrast=1.38, saturation=.68, bloom=.15, grain=.13, vignette=.40, posterize=6, temporal="clean", overlay="deco", direction="black-gold monumental geometry"),
    "samurai_graphic_minimal": StyleSpec("Samurai Jack · Graphic Minimal", "limited_animation", _m(1.06,.02,-.02,-.03,.96,.01,-.03,.02,.94), gamma=.88, contrast=1.50, saturation=1.25, bloom=0, grain=.035, vignette=.06, posterize=5, temporal="limited12", overlay="ink_silhouette", direction="flat silhouettes, negative space, limited animation"),
    "sunburst": StyleSpec("Sunburst", "graphic_light", _m(1.18,.08,-.02,.02,1.00,-.04,-.06,.02,.83), gamma=.88, contrast=1.16, saturation=1.12, bloom=.35, grain=.06, vignette=.10, temporal="radiant_pulse", overlay="sunburst", direction="radial light and poster composition"),
    "allure_of_night": StyleSpec("The Allure of the Night", "night", _m(.72,.05,.14,.01,.86,.13,.13,.06,1.18), gamma=.94, contrast=1.22, saturation=1.14, bloom=.33, grain=.16, vignette=.42, chroma_shift=.004, temporal="night_ghost", overlay="halation", direction="intimate nocturnal photography"),
    "graphicdesign": StyleSpec("Graphicdesign", "motion_design", _m(1.05,.02,.01,.01,.96,.02,.02,.02,.94), gamma=.96, contrast=1.25, saturation=1.04, bloom=.04, grain=.035, vignette=.03, posterize=8, temporal="design_step", overlay="design_grid", direction="kinetic typography, grids and colour blocks"),
    "legacy_matrix": StyleSpec("Legacy of the Matrix", "matrix", _m(.30,.05,.02,.08,1.18,.05,.03,.23,.34), gamma=.89, contrast=1.34, saturation=.70, bloom=.20, grain=.13, vignette=.31, scanlines=.38, temporal="matrix_echo", overlay="matrix_code", direction="green-black virtual surveillance"),
    "night_vibe": StyleSpec("Night Vibe", "monochrome_night", _m(.68,.09,.11,.07,.75,.12,.12,.12,.85), gamma=1.02, contrast=1.12, saturation=.05, bloom=.20, grain=.18, vignette=.45, temporal="slow_ghost", overlay="none", direction="quiet monochrome night"),
    "life_good": StyleSpec("Life Good", "documentary", _m(1.05,.01,.01,.01,1.03,.00,.00,.02,.98), gamma=.96, contrast=1.18, saturation=.82, bloom=.08, grain=.18, vignette=.14, temporal="documentary", overlay="frame_counter", direction="optimistic handheld documentary"),
    "vibes_2006": StyleSpec("Vibes from 2006", "digital_2006", _m(1.02,.02,.03,.02,.99,.03,.03,.01,.96), gamma=.94, contrast=1.20, saturation=.72, bloom=.17, grain=.11, vignette=.10, chroma_shift=.008, scanlines=.12, temporal="digital2006", overlay="compact_camera", direction="early digital camera nightlife"),
    "urban_ink_band": StyleSpec("Urban Ink Band", "ink_animation", _m(1.10,.01,-.03,-.02,.92,.02,-.04,.02,.82), gamma=.88, contrast=1.45, saturation=1.15, bloom=.04, grain=.23, vignette=.17, posterize=5, temporal="limited12", overlay="ink_outline", direction="urban ink character poster"),
    "poster_marketing_90s_00s": StyleSpec("90s/00s Poster Marketing", "poster", _m(1.08,.02,.01,.01,1.02,.01,.01,.02,.96), gamma=.93, contrast=1.30, saturation=1.12, bloom=.08, grain=.16, vignette=.06, posterize=7, temporal="design_step", overlay="poster", direction="commercial poster montage"),
    "frutiger_aero": StyleSpec("Frutiger Aero", "aero", _m(.82,.08,.08,.02,1.10,.06,.08,.14,1.16), gamma=.88, contrast=1.02, saturation=1.20, bloom=.30, grain=.02, vignette=.05, temporal="clean", overlay="bubbles", direction="optimistic glossy ecology and sky"),
    "desire_machine": StyleSpec("Desire Machine", "industrial_sensual", _m(.90,.07,.04,.02,.86,.06,.06,.04,.83), gamma=.92, contrast=1.27, saturation=.70, bloom=.19, grain=.21, vignette=.38, chroma_shift=.004, temporal="mechanical_pulse", overlay="machine", direction="cold industrial body-machine"),
    "staglieno_cemetery": StyleSpec("Cimitero di Staglieno", "stone", _m(.86,.06,.04,.05,.84,.05,.04,.07,.88), gamma=1.05, contrast=1.12, saturation=.38, bloom=.09, grain=.20, vignette=.37, temporal="slow_ghost", overlay="marble", direction="funerary marble, stillness and depth"),
    "scp_zxckfair": StyleSpec("SCP ZXCKFAIR", "surveillance", _m(.58,.06,.04,.04,.72,.05,.05,.12,.65), gamma=.82, contrast=1.42, saturation=.40, bloom=.08, grain=.36, vignette=.48, chroma_shift=.013, scanlines=.60, temporal="security_drop", overlay="scp", direction="dark anomalous surveillance"),
    "neon_graphic_grit": StyleSpec("Neon Graphic Grit", "cyber_ink", _m(1.10,-.02,.12,-.04,.78,.18,.13,-.04,1.10), gamma=.86, contrast=1.40, saturation=1.15, bloom=.22, grain=.24, vignette=.25, posterize=6, temporal="impact_repeat", overlay="ink_outline", direction="red-magenta cyberpunk print"),
    "future_noir_cel": StyleSpec("Future Noir Cel", "future_cel", _m(.86,.04,.14,.01,.88,.13,.12,.03,1.04), gamma=.91, contrast=1.30, saturation=1.05, bloom=.16, grain=.035, vignette=.20, posterize=7, temporal="limited12", overlay="cel_edges", direction="late-90s angular future noir"),
}

STYLE_NAMES = tuple(STYLE_SPECS)


def export_style_specs(path: str | Path) -> None:
    Path(path).write_text(json.dumps({k: asdict(v) for k, v in STYLE_SPECS.items()}, ensure_ascii=False, indent=2), encoding="utf-8")


class StyleState:
    def __init__(self):
        self.previous: np.ndarray | None = None
        self.held: np.ndarray | None = None


def _saturation(img: np.ndarray, amount: float) -> np.ndarray:
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32)[..., None]
    return np.clip(gray + (img.astype(np.float32) - gray) * amount, 0, 255).astype(np.uint8)


def _bloom(img: np.ndarray, amount: float) -> np.ndarray:
    if amount <= 0:
        return img
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    mask = np.clip((gray.astype(np.float32) - 150) / 105, 0, 1)[..., None]
    blur = cv2.GaussianBlur(img, (0, 0), max(1.0, min(img.shape[:2]) * .010))
    return np.clip(img.astype(np.float32) + blur.astype(np.float32) * mask * amount, 0, 255).astype(np.uint8)


@lru_cache(maxsize=2)
def _vignette_mask(h: int, w: int, amount: float) -> np.ndarray:
    y, x = np.ogrid[-1:1:h*1j, -1:1:w*1j]
    r = np.sqrt(x*x + y*y)
    m = np.clip(1 - amount * np.maximum(0, r - .15) ** 1.4, .25, 1)[..., None]
    m.flags.writeable = False
    return m


def _vignette(img: np.ndarray, amount: float) -> np.ndarray:
    if amount <= 0:
        return img
    m = _vignette_mask(*img.shape[:2], amount)
    return np.clip(img.astype(np.float32) * m, 0, 255).astype(np.uint8)


def _apply_matrix(img: np.ndarray, spec: StyleSpec) -> np.ndarray:
    f = img.astype(np.float32) / 255.0
    # BGR matrix, intentionally explicit and deterministic.
    mat = np.array(spec.matrix, np.float32).reshape(3, 3)
    f = f @ mat.T
    f += np.array(spec.lift, np.float32)
    f = np.clip(f, 0, 1)
    f = np.power(f, max(.2, spec.gamma)) * spec.gain
    f = (f - .5) * spec.contrast + .5
    out = np.clip(f * 255, 0, 255).astype(np.uint8)
    return _saturation(out, spec.saturation)


def _grain(img: np.ndarray, amount: float, rng: np.random.Generator) -> np.ndarray:
    if amount <= 0:
        return img
    noise = rng.normal(0, 255 * amount * .16, img.shape[:2]).astype(np.float32)[..., None]
    return np.clip(img.astype(np.float32) + noise, 0, 255).astype(np.uint8)


def _posterize(img: np.ndarray, levels: int) -> np.ndarray:
    if levels <= 1:
        return img
    step = 255.0 / (levels - 1)
    return np.clip(np.round(img / step) * step, 0, 255).astype(np.uint8)


def _chroma(img: np.ndarray, strength: float) -> np.ndarray:
    if strength <= 0:
        return img
    shift = max(1, int(img.shape[1] * strength))
    b, g, r = cv2.split(img)
    return cv2.merge([np.roll(b, shift, 1), g, np.roll(r, -shift, 1)])


def _temporal(img: np.ndarray, state: StyleState, mode: str, frame_no: int, impact: float) -> np.ndarray:
    prev = state.previous
    out = img
    if mode in {"limited12", "soft_hold", "archive_hold"}:
        step = 2 if mode == "limited12" else 3
        if frame_no % step and state.held is not None:
            out = state.held.copy()
        else:
            state.held = img.copy()
    elif prev is not None and mode in {"dream_ghost", "night_ghost", "slow_ghost", "matrix_echo", "neon_trail"}:
        alpha = {"dream_ghost": .26, "night_ghost": .18, "slow_ghost": .32, "matrix_echo": .20, "neon_trail": .14}[mode]
        shifted = np.roll(prev, int((2 + impact * 8) * (-1 if frame_no % 2 else 1)), axis=1)
        out = cv2.addWeighted(img, 1 - alpha, shifted, alpha, 0)
    elif prev is not None and mode in {"smear", "mechanical_pulse"}:
        alpha = .25 if mode == "smear" else .14
        out = cv2.addWeighted(img, 1-alpha, np.roll(prev, int(img.shape[1]*.012*(1+impact)), axis=1), alpha, 0)
    elif mode in {"digital_stutter", "digital2006", "security_drop", "impact_repeat"} and prev is not None:
        trigger = (frame_no % 11 == 0) or (impact > .80 and frame_no % 3 == 0)
        if trigger:
            out = prev.copy()
            if mode != "impact_repeat":
                y = (frame_no * 37) % max(1, img.shape[0] - 8)
                out[y:y+6] = np.roll(out[y:y+6], img.shape[1]//18, axis=1)
    elif mode == "field_jitter":
        out = img.copy()
        out[1::2] = np.roll(out[1::2], 1 if frame_no % 2 else -1, axis=1)
    elif mode == "design_step":
        out = np.roll(img, (frame_no // 3) % 3 - 1, axis=1)
    state.previous = out.copy()
    return out


def _overlay(img: np.ndarray, name: str, t: float, frame_no: int, impact: float, rng: np.random.Generator) -> np.ndarray:
    out = img.copy(); h, w = out.shape[:2]
    white = (238, 238, 238)
    if name == "camcorder":
        cv2.putText(out, f"REC  {int(t)//60:02d}:{int(t)%60:02d}:{frame_no%30:02d}", (20, 36), cv2.FONT_HERSHEY_SIMPLEX, .62, (220,220,245), 1, cv2.LINE_AA)
        cv2.circle(out, (w-28, 27), 7, (20,20,240), -1)
        if frame_no % 43 < 2: out[h//3:h//3+3] = 235
    elif name == "hacking":
        for x in range(0, w, max(32,w//18)): cv2.line(out,(x,0),(x,h),(20,90,25),1)
        for y in range(0, h, max(24,h//14)): cv2.line(out,(0,y),(w,y),(20,75,25),1)
        for i in range(7): cv2.putText(out, f"0x{(frame_no*7919+i*31337)&0xfffffff:07X}", (12, 28+i*22), cv2.FONT_HERSHEY_PLAIN,.9,(75,255,110),1)
    elif name == "glass":
        for i in range(4):
            x=int((.12+i*.24)*w); cv2.line(out,(x,0),(x-int(.08*w),h),(210,235,245),1,cv2.LINE_AA)
        out=cv2.addWeighted(out,.92,cv2.GaussianBlur(out,(0,0),1.2),.08,0)
    elif name == "rain":
        for _ in range(max(30,w//18)):
            x=int(rng.integers(0,w)); y=int(rng.integers(0,h)); length=int(rng.integers(8,25)); cv2.line(out,(x,y),(x-3,y+length),(190,150,220),1)
    elif name == "soft_club":
        glow=cv2.GaussianBlur(out,(0,0),max(2,h*.015)); out=cv2.addWeighted(out,.74,glow,.34,4)
    elif name in {"ink_outline", "cel_edges", "ink_silhouette"}:
        gray=cv2.cvtColor(out,cv2.COLOR_BGR2GRAY); edges=cv2.Canny(gray,60,135); out[edges>0]=(5,4,8)
        if name=="ink_silhouette": out[gray<75]=(8,6,12)
    elif name == "dust":
        for _ in range(max(40,w//10)):
            x=int(rng.integers(0,w)); y=int(rng.integers(0,h)); out[y,x]=rng.choice([0,255])
    elif name == "date_stamp":
        cv2.putText(out,"ARCHIVE  2001/09/17",(18,h-24),cv2.FONT_HERSHEY_PLAIN,1.0,(220,220,210),1)
    elif name == "xerox":
        gray=cv2.cvtColor(out,cv2.COLOR_BGR2GRAY); tex=(rng.random((h,w))>.94).astype(np.uint8)*255; gray=cv2.subtract(gray,tex); out=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
    elif name == "deco":
        gold=(55,155,215); m=int(min(w,h)*.06); cv2.rectangle(out,(m,m),(w-m,h-m),gold,2)
        for k in range(3): cv2.line(out,(w//2-k*25,m),(w-m,m+90+k*30),gold,1)
    elif name == "starburst":
        cx,cy=int(w*.73),int(h*.28); r=int(min(w,h)*(.18+.05*impact));
        for a in np.linspace(0,math.tau,18,endpoint=False): cv2.line(out,(cx,cy),(int(cx+math.cos(a)*r),int(cy+math.sin(a)*r)),(245,220,255),1,cv2.LINE_AA)
    elif name == "sunburst":
        cx,cy=w//2,h//2
        overlay=np.zeros_like(out)
        for a in np.linspace(0,math.tau,24,endpoint=False): cv2.line(overlay,(cx,cy),(int(cx+math.cos(a)*max(w,h)),int(cy+math.sin(a)*max(w,h))),(80,150,255),max(1,w//300))
        out=cv2.addWeighted(out,.87,overlay,.28,0)
    elif name == "halation":
        glow=cv2.GaussianBlur(out,(0,0),max(2,h*.018)); out=cv2.addWeighted(out,.86,glow,.26,-6)
    elif name == "design_grid":
        for x in range(w//8,w,w//8): cv2.line(out,(x,0),(x,h),(240,240,240),1)
        for y in range(h//6,h,h//6): cv2.line(out,(0,y),(w,y),(240,240,240),1)
        cv2.putText(out,"SUBTERRA / DELUXE",(int(w*.05),int(h*.14)),cv2.FONT_HERSHEY_DUPLEX,max(.5,h/700),white,max(1,h//500),cv2.LINE_AA)
    elif name == "matrix_code":
        for col in range(0,w,max(14,w//55)):
            length=(frame_no*3+col*7)%max(1,h); cv2.putText(out, chr(0x30A0+(col//14)%70), (col,length), cv2.FONT_HERSHEY_PLAIN,.75,(55,245,95),1)
    elif name in {"frame_counter","compact_camera"}:
        cv2.putText(out,f"FRAME {frame_no:06d}",(18,h-20),cv2.FONT_HERSHEY_PLAIN,.9,(230,230,230),1)
        if name=="compact_camera": cv2.rectangle(out,(w-78,16),(w-18,42),(30,30,30),-1); cv2.putText(out,"AUTO",(w-70,35),cv2.FONT_HERSHEY_PLAIN,.8,(230,230,230),1)
    elif name == "poster":
        cv2.rectangle(out,(int(w*.04),int(h*.07)),(int(w*.37),int(h*.22)),(20,20,20),-1)
        cv2.putText(out,"NIGHT / SYSTEM",(int(w*.06),int(h*.16)),cv2.FONT_HERSHEY_DUPLEX,max(.55,h/700),white,max(1,h//480),cv2.LINE_AA)
    elif name == "bubbles":
        for i in range(8):
            x=int((.1+(i*.137+t*.015)% .85)*w); y=int((.2+(i*.173-t*.01)% .65)*h); r=int(min(w,h)*(.025+.008*(i%3))); cv2.circle(out,(x,y),r,(245,250,225),2,cv2.LINE_AA)
    elif name == "machine":
        for i in range(5):
            x=int(w*(.10+i*.20)); cv2.circle(out,(x,int(h*.78)),int(h*.045),(125,130,135),2); cv2.line(out,(x,int(h*.73)),(x+int(math.sin(t+i)*w*.06),int(h*.35)),(115,120,125),2)
    elif name == "marble":
        veins=cv2.Canny(cv2.GaussianBlur(cv2.cvtColor(out,cv2.COLOR_BGR2GRAY),(0,0),4),18,42); out[veins>0]=(155,160,166)
    elif name == "scp":
        cv2.rectangle(out,(12,12),(w-12,h-12),(180,205,185),1); cv2.putText(out,"REC // ANOMALOUS FEED",(24,38),cv2.FONT_HERSHEY_PLAIN,1.0,(180,230,195),1)
        if frame_no%29==0: out[int(h*.45):int(h*.48)]=0
    elif name == "anamorphic":
        y=int(h*(.34+.04*math.sin(t*.7))); overlay=np.zeros_like(out); cv2.line(overlay,(0,y),(w,y),(180,205,255),2); out=cv2.addWeighted(out,.96,cv2.GaussianBlur(overlay,(0,0),9),.35,0)
    return out


def prepare_style(frame: np.ndarray, style: str,
                  t: float, frame_no: int, impact: float, seed: int) -> np.ndarray:
    """Stateless spatial effects may run on different frames concurrently."""
    spec = STYLE_SPECS.get(style, STYLE_SPECS["clean_deluxe"])
    rng = np.random.default_rng(seed + frame_no * 104729)
    src = frame
    out = _apply_matrix(src, spec)
    out = _posterize(out, spec.posterize)
    out = _chroma(out, spec.chroma_shift)
    out = _bloom(out, spec.bloom)
    out = _overlay(out, spec.overlay, t, frame_no, impact, rng)
    if spec.scanlines > 0:
        dark = 1 - spec.scanlines * .28
        out[1::2] = np.clip(out[1::2].astype(np.float32) * dark, 0, 255).astype(np.uint8)
    out = _grain(out, spec.grain, rng)
    out = _vignette(out, spec.vignette)
    if spec.letterbox > 0:
        bar = int(out.shape[0] * spec.letterbox)
        out[:bar] = 0; out[-bar:] = 0
    return out


def finish_style(src: np.ndarray, out: np.ndarray, style: str, strength: float,
                 state: StyleState, frame_no: int, impact: float) -> np.ndarray:
    """History is committed only in timeline order, never in worker threads."""
    spec = STYLE_SPECS.get(style, STYLE_SPECS["clean_deluxe"])
    out = _temporal(out, state, spec.temporal, frame_no, impact)
    return cv2.addWeighted(src, 1-float(strength), out, float(strength), 0)


def apply_style(frame: np.ndarray, style: str, strength: float, state: StyleState,
                t: float, frame_no: int, impact: float, seed: int) -> np.ndarray:
    out = prepare_style(frame, style, t, frame_no, impact, seed)
    return finish_style(frame, out, style, strength, state, frame_no, impact)


def style_metrics(frame: np.ndarray) -> dict[str, float]:
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY); hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    return {"brightness":float(gray.mean()/255),"contrast":float(gray.std()/255),
            "saturation":float(hsv[...,1].mean()/255),"edge_density":float((cv2.Canny(gray,70,150)>0).mean())}
