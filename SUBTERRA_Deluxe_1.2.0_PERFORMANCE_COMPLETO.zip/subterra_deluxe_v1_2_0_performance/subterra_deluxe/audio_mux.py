from __future__ import annotations

from functools import lru_cache
import platform
import shutil
import subprocess
from pathlib import Path


@lru_cache(maxsize=1)
def ffmpeg_encoders() -> str:
    if not shutil.which('ffmpeg'):
        return ''
    try:
        return subprocess.check_output(['ffmpeg','-hide_banner','-encoders'],stderr=subprocess.STDOUT,text=True,timeout=15)
    except Exception:
        return ''


@lru_cache(maxsize=16)
def encoder_works(encoder: str) -> bool:
    """An advertised encoder may have no compatible GPU/driver. Execute it."""
    cmd = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-f', 'rawvideo',
           '-pix_fmt', 'bgr24', '-s', '64x64', '-r', '30', '-i', '-',
           '-frames:v', '1', '-c:v', encoder, '-threads', '1', '-pix_fmt', 'yuv420p', '-f', 'null', '-']
    try:
        probe = subprocess.run(cmd, input=bytes(64*64*3), stdout=subprocess.DEVNULL,
                               stderr=subprocess.PIPE, timeout=20)
        return probe.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def resolve_encoder(requested: str, output: Path) -> str:
    if not shutil.which('ffmpeg'):
        raise RuntimeError('FFmpeg não encontrado no PATH. Veja LEIA_PRIMEIRO_DESEMPENHO.md.')
    if output.suffix.lower() == '.avi':
        return 'mpeg4'
    supported = {'h264_nvenc', 'hevc_nvenc', 'av1_nvenc', 'libx264', 'mpeg4'}
    if requested != 'auto':
        if requested not in supported:
            raise ValueError(f'Encoder não suportado: {requested}')
        if not encoder_works(requested):
            raise RuntimeError(f'O encoder {requested} falhou no teste real. Use auto ou verifique o driver/FFmpeg.')
        return requested
    encoders = ffmpeg_encoders()
    if 'h264_nvenc' in encoders and encoder_works('h264_nvenc'):
        return 'h264_nvenc'
    if encoder_works('libx264'):
        return 'libx264'
    raise RuntimeError('Nenhum encoder H.264 operacional. Verifique o FFmpeg.')


def audio_options(output: Path, mode: str) -> list[str]:
    filters = {'preserve': None, 'streaming': 'loudnorm=I=-14:TP=-1.0:LRA=11',
               'cinema': 'highpass=f=25,lowpass=f=19000,loudnorm=I=-18:TP=-1.0:LRA=14',
               'club': 'highpass=f=25,loudnorm=I=-9:TP=-0.8:LRA=7'}
    if mode not in filters:
        raise ValueError(f'Modo de áudio desconhecido: {mode}')
    options = ['-af', filters[mode]] if filters[mode] else []
    if output.suffix.lower() == '.mkv' and mode == 'preserve':
        return options + ['-c:a', 'flac']
    return options + ['-c:a', 'aac', '-b:a', '320k']


def video_writer_cmd(output: Path, width:int, height:int, fps:float, encoder:str,
                     crf:int, preset:str, *, threads:int=0, audio=None,
                     audio_mode:str='preserve')->list[str]:
    cmd=['ffmpeg','-y','-hide_banner','-loglevel','error', '-filter_threads', str(max(1, threads or 2)),
         '-f','rawvideo','-pix_fmt','bgr24','-s',f'{width}x{height}','-r',str(fps),'-i','-']
    if audio:
        cmd += ['-i', str(audio), '-map', '0:v:0', '-map', '1:a:0']
    else:
        cmd += ['-an']
    if encoder in {'h264_nvenc', 'hevc_nvenc', 'av1_nvenc'}:
        cmd += ['-c:v',encoder,'-preset',preset if preset in {f'p{i}' for i in range(1,8)} else 'p4',
                '-cq',str(crf),'-pix_fmt','yuv420p']
    elif encoder=='mpeg4':
        cmd += ['-c:v','mpeg4','-q:v','3']
    else:
        cpu_preset = preset if not preset.startswith('p') else {'p2':'veryfast','p4':'fast'}.get(preset, 'medium')
        cmd += ['-c:v','libx264','-preset',cpu_preset,'-crf',str(crf),'-pix_fmt','yuv420p']
    if threads:
        cmd += ['-threads:v', str(threads)]
    if audio:
        cmd += audio_options(output, audio_mode) + ['-shortest']
    if output.suffix.lower() in {'.mp4', '.mov', '.m4v'}:
        cmd += ['-movflags', '+faststart']
    return cmd + [str(output)]


def mux_audio(video_silent: str|Path, audio: str|Path, output: str|Path, mode: str='preserve') -> Path:
    """Mux audio. `preserve` means no EQ/compression/loudness filters.

    MP4 requires a compatible codec, so source audio is transparently encoded to
    high-bitrate AAC but its samples are not equalised, compressed or limited.
    """
    v=Path(video_silent);a=Path(audio);out=Path(output);out.parent.mkdir(parents=True,exist_ok=True)
    cmd=['ffmpeg','-y','-hide_banner','-loglevel','error','-i',str(v),'-i',str(a),'-map','0:v:0','-map','1:a:0','-c:v','copy']
    suffix=out.suffix.lower()
    if mode=='preserve':
        if suffix=='.mkv': cmd += ['-c:a','flac']
        else: cmd += ['-c:a','aac','-b:a','320k']
    elif mode=='streaming': cmd += ['-af','loudnorm=I=-14:TP=-1.0:LRA=11','-c:a','aac','-b:a','320k']
    elif mode=='cinema': cmd += ['-af','highpass=f=25,lowpass=f=19000,loudnorm=I=-18:TP=-1.0:LRA=14','-c:a','aac','-b:a','320k']
    elif mode=='club': cmd += ['-af','highpass=f=25,loudnorm=I=-9:TP=-0.8:LRA=7','-c:a','aac','-b:a','320k']
    else: raise ValueError(f'Modo de áudio desconhecido: {mode}')
    cmd += ['-shortest','-movflags','+faststart',str(out)]
    subprocess.run(cmd,check=True)
    return out
