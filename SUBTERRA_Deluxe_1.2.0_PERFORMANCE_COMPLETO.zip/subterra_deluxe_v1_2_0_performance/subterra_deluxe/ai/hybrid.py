from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from collections.abc import Iterable
from pathlib import Path

from ..audio_mux import resolve_encoder, mux_audio
from ..config import DeluxeConfig
from ..performance import make_plan


def _probe_size(path: Path) -> tuple[int, int]:
    cmd = [
        'ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height', '-of', 'csv=s=x:p=0', str(path)
    ]
    text = subprocess.check_output(cmd, text=True, timeout=30).strip()
    w, h = text.split('x', 1)
    return int(w), int(h)


def _find_clip(root: Path, expected: str, shot: int) -> Path | None:
    candidates = [root / expected, root / f'shot_{shot:04d}.mp4', root / f'shot_{shot:04d}.webm']
    for p in candidates:
        if p.exists():
            return p
    patterns = [f'shot_{shot:04d}*.mp4', f'shot_{shot:04d}*.webm', f'*shot_{shot:04d}*.mp4']
    for pat in patterns:
        found = sorted(root.rglob(pat))
        if found:
            return found[0]
    return None


def _segment_cmd(source: Path, output: Path, start: float, frame_count: int,
                 width: int, height: int, fps: float, encoder: str, is_generated: bool, threads: int = 2, preset: str = 'p5') -> list[str]:
    cmd = ['ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-threads', str(threads), '-filter_threads', str(threads)]
    if not is_generated:
        cmd += ['-ss', f'{start:.6f}']
    cmd += ['-i', str(source), '-an']
    vf = (
        f'fps={fps},scale={width}:{height}:force_original_aspect_ratio=increase,'
        f'crop={width}:{height},setsar=1,'
        f'tpad=stop_mode=clone:stop_duration=2,trim=end_frame={frame_count},setpts=PTS-STARTPTS'
    )
    cmd += ['-vf', vf, '-frames:v', str(frame_count)]
    if encoder == 'h264_nvenc':
        cmd += ['-c:v', 'h264_nvenc', '-preset', preset, '-cq', '18']
    elif encoder == 'hevc_nvenc':
        cmd += ['-c:v', 'hevc_nvenc', '-preset', preset, '-cq', '18']
    elif encoder == 'av1_nvenc':
        cmd += ['-c:v', 'av1_nvenc', '-preset', preset, '-cq', '20']
    else:
        cpu_preset={'p2':'veryfast','p4':'fast','p5':'medium'}.get(preset,preset if not preset.startswith('p') else 'fast')
        cmd += ['-c:v', 'libx264', '-preset', cpu_preset, '-crf', '18']
    cmd += ['-threads:v', str(threads), '-pix_fmt', 'yuv420p', str(output)]
    return cmd


def assemble_hybrid(manifest_path: str | Path, base_video: str | Path,
                    clips_dir: str | Path, output: str | Path,
                    audio_master: str | Path | None = None,
                    encoder: str = 'auto',
                    shot_ids: Iterable[int] | None = None, *, performance: str = 'balanced') -> dict:
    """Assemble a multi-shot film with deterministic fallback to the base render.

    Generated files are searched by the manifest's ``output_name`` and by the
    stable ``shot_XXXX`` prefix. Every segment is normalized to the base video's
    dimensions and the manifest FPS before concatenation. Missing clips are cut
    from the base video, so a partial AI run still produces a complete film.
    """
    started = time.perf_counter()
    manifest_path = Path(manifest_path)
    base = Path(base_video)
    clips = Path(clips_dir)
    out = Path(output)
    if not manifest_path.exists():
        raise FileNotFoundError(manifest_path)
    if not base.exists():
        raise FileNotFoundError(base)
    if not clips.exists():
        raise FileNotFoundError(clips)
    out.parent.mkdir(parents=True, exist_ok=True)

    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    all_shots = manifest.get('shots', [])
    shots = all_shots
    if shot_ids is not None:
        selected = {int(value) for value in shot_ids}
        shots = [item for item in all_shots if int(item['shot']) in selected]
        found = {int(item['shot']) for item in shots}
        missing = selected - found
        if missing:
            formatted = ', '.join(f'{shot:04d}' for shot in sorted(missing))
            raise ValueError(f'Shots não encontrados no manifesto: {formatted}')
    if not shots:
        raise ValueError('O manifesto não contém planos.')
    width, height = _probe_size(base)
    fps = float(shots[0].get('fps', 24.0))
    chosen_encoder = resolve_encoder(encoder, out)
    # MP4 concat is most reliable when all intermediate segments use H.264.
    segment_encoder = chosen_encoder if chosen_encoder in {'h264_nvenc', 'libx264'} else 'libx264'

    cfg = DeluxeConfig(width=width,height=height,performance=performance)
    cfg.validate()
    plan = make_plan(cfg,width,height)
    segment_workers = min(2,plan.workers) if performance!='compatibility' else 1
    segment_threads = max(1,min(4,plan.logical_cpus//segment_workers))
    used_ai = 0
    fallbacks = 0
    with tempfile.TemporaryDirectory(prefix='subterra_hybrid_') as td:
        temp = Path(td)
        segment_paths: list[Path] = []
        mapping: list[dict] = []
        commands = []
        target_total_frames = 0
        for pos, item in enumerate(shots):
            sid = int(item['shot'])
            start = float(item['start'])
            # Rounding every duration independently loses a fraction of a frame
            # at many edit points. Deriving the count from cumulative timeline
            # boundaries makes adjacent shots partition the master exactly.
            start_frame = int(round(start * fps))
            end_frame = int(round(float(item['end']) * fps))
            frame_count = max(1, end_frame - start_frame)
            target_total_frames += frame_count
            generated = _find_clip(clips, str(item.get('output_name', '')), sid)
            source = generated or base
            is_generated = generated is not None
            used_ai += int(is_generated)
            fallbacks += int(not is_generated)
            seg = temp / f'segment_{pos:04d}.mp4'
            commands.append(_segment_cmd(source,seg,start,frame_count,width,height,fps,
                                         segment_encoder,is_generated,segment_threads,plan.encoder_preset))
            segment_paths.append(seg)
            mapping.append({
                'shot': sid,
                'source': str(source.resolve()),
                'ai': is_generated,
                'target_frames': frame_count,
                'target_duration': round(frame_count / fps, 6),
            })

        def run_segment(cmd):
            # No pipe to fill up while another segment is running.
            with tempfile.TemporaryFile(mode='w+b') as log:
                result=subprocess.run(cmd,stderr=log)
                if result.returncode:
                    log.seek(0)
                    raise RuntimeError('Falha no segmento: '+log.read()[-4000:].decode('utf-8','replace'))
        with ThreadPoolExecutor(max_workers=segment_workers,thread_name_prefix='subterra-segments') as executor:
            pending=deque()
            for command in commands:
                pending.append(executor.submit(run_segment,command))
                if len(pending)>=segment_workers:pending.popleft().result()
            while pending:pending.popleft().result()

        concat_file = temp / 'concat.txt' 
        concat_file.write_text(
            ''.join(f"file '{p.as_posix()}'\n" for p in segment_paths), encoding='utf-8'
        )
        silent = temp / 'hybrid_silent.mp4'
        subprocess.run([
            'ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-f', 'concat', '-safe', '0',
            '-i', str(concat_file), '-c', 'copy', str(silent)
        ], check=True)

        if audio_master:
            mux_audio(silent, audio_master, out, 'preserve')
        else:
            # Reuse the base soundtrack without processing it.
            subprocess.run([
                'ffmpeg', '-y', '-hide_banner', '-loglevel', 'error', '-i', str(silent), '-i', str(base),
                '-map', '0:v:0', '-map', '1:a:0?', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '320k',
                '-shortest', '-movflags', '+faststart', str(out)
            ], check=True)

    report = {
        'output': str(out.resolve()),
        'elapsed_seconds': round(time.perf_counter()-started,3),
        'segment_workers': segment_workers,
        'performance': performance,
        'manifest': str(manifest_path.resolve()),
        'base_video': str(base.resolve()),
        'clips_dir': str(clips.resolve()),
        'manifest_total_shots': len(all_shots),
        'selected_shots': [int(item['shot']) for item in shots],
        'total_shots': len(shots),
        'ai_shots': used_ai,
        'fallback_shots': fallbacks,
        'width': width,
        'height': height,
        'fps': fps,
        'target_total_frames': target_total_frames,
        'target_duration': round(target_total_frames / fps, 6),
        'segment_encoder': segment_encoder,
        'mapping': mapping,
    }
    report_path = out.with_suffix('.hybrid_report.json')
    report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    return report
