from __future__ import annotations

import argparse
import json
import secrets
from pathlib import Path

from .config import DeluxeConfig
from .features import analyse_audio
from .director import make_story
from .media import CharacterSpec
from .renderer import DeluxeRenderer
from .styles import STYLE_NAMES, export_style_specs
from .ai.manifest import build_multishot_manifest
from .ai.comfyui import discover_comfyui, generate_manifest, parse_shot_selector
from .ai.hybrid import assemble_hybrid


def build_parser()->argparse.ArgumentParser:
    p=argparse.ArgumentParser(prog='subterra-deluxe',description='SUBTERRA Deluxe rebuilt musical film engine')
    sub=p.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('analyse');a.add_argument('audio');a.add_argument('workdir')
    r=sub.add_parser('render');r.add_argument('audio');r.add_argument('output');r.add_argument('--workdir',default='output/_work');r.add_argument('--style',choices=STYLE_NAMES,default='nolan_odisseia');r.add_argument('--seed',type=int);r.add_argument('--width',type=int,default=1920);r.add_argument('--height',type=int,default=1080);r.add_argument('--fps',type=float,default=30);r.add_argument('--quality',default='deluxe');r.add_argument('--preview-seconds',type=float,default=0);r.add_argument('--encoder',default='auto');r.add_argument('--audio-mode',choices=['preserve','streaming','cinema','club'],default='preserve');r.add_argument('--no-gpu',action='store_true');r.add_argument('--media',action='append',default=[]);r.add_argument('--character',action='append',default=[],help='path::role::name')
    r.add_argument('--performance',choices=['balanced','maximum','compatibility'],default='balanced',help='Perfil de paralelismo; maximum prioriza velocidade de codificação')
    r.add_argument('--encoder-preset',default='auto',help='auto, p1-p7 (NVENC) ou preset x264; substitui a escolha do perfil')
    r.add_argument('--cpu-workers',type=int,default=0,help='0 = automático conforme CPU/RAM')
    r.add_argument('--ram-budget-mb',type=int,default=0,help='Orçamento dos buffers; 0 = automático')
    m=sub.add_parser('ai-manifest');m.add_argument('story');m.add_argument('output_dir');m.add_argument('--base-video');m.add_argument('--width',type=int,default=768);m.add_argument('--height',type=int,default=432);m.add_argument('--fps',type=float,default=24);m.add_argument('--backend',default='auto');m.add_argument('--shots',default='all',help='all, 0 ou 0,2-4')
    d=sub.add_parser('ai-detect');d.add_argument('--host',default='http://127.0.0.1:8188')
    q=sub.add_parser('ai-generate');q.add_argument('manifest');q.add_argument('workflow',nargs='?',help='Workflow API opcional; omita para autoconfiguração');q.add_argument('--host',default='http://127.0.0.1:8188');q.add_argument('--output-dir');q.add_argument('--timeout',type=float,default=3600);q.add_argument('--shots',default='0',help='Padrão seguro: apenas 0. Use all explicitamente para lote.');q.add_argument('--allow-text-to-video',action='store_true',help='Diagnóstico explícito sem condicionamento pelo keyframe');q.add_argument('--no-skip-existing',action='store_true')
    h=sub.add_parser('ai-assemble');h.add_argument('manifest');h.add_argument('base_video');h.add_argument('clips_dir');h.add_argument('output');h.add_argument('--audio-master');h.add_argument('--encoder',default='auto');h.add_argument('--shots',default='all',help='all ou uma prévia como 0-4')
    h.add_argument('--performance',choices=['balanced','maximum','compatibility'],default='balanced')
    s=sub.add_parser('list-styles');s.add_argument('--json')
    return p


def main(argv=None)->int:
    ns=build_parser().parse_args(argv)
    if ns.cmd=='analyse':
        print(*analyse_audio(ns.audio,ns.workdir));return 0
    if ns.cmd=='list-styles':
        if ns.json:export_style_specs(ns.json)
        else:print('\n'.join(STYLE_NAMES))
        return 0
    if ns.cmd=='ai-detect':
        discovery=discover_comfyui(ns.host);discovery.pop('_object_info',None)
        print(json.dumps(discovery,indent=2,ensure_ascii=False));return 0
    if ns.cmd=='ai-manifest':
        shots=parse_shot_selector(ns.shots)
        print(build_multishot_manifest(ns.story,ns.output_dir,ns.base_video,ns.width,ns.height,ns.fps,ns.backend,shots,bool(ns.base_video and shots is not None)));return 0
    if ns.cmd=='ai-generate':
        shots=parse_shot_selector(ns.shots)
        report=generate_manifest(ns.manifest,ns.workflow,ns.output_dir,ns.host,ns.timeout,lambda a,b,m:print(f'[{a}/{b}] {m}'),shots,not ns.no_skip_existing,ns.allow_text_to_video)
        print(json.dumps(report,indent=2,ensure_ascii=False));return 0
    if ns.cmd=='ai-assemble':
        report=assemble_hybrid(ns.manifest,ns.base_video,ns.clips_dir,ns.output,ns.audio_master,ns.encoder,parse_shot_selector(ns.shots),performance=ns.performance)
        print(json.dumps(report,indent=2,ensure_ascii=False));return 0
    seed=ns.seed if ns.seed is not None else secrets.randbelow(2**31-2)+1
    work=Path(ns.workdir)/f'{Path(ns.audio).stem}_seed{seed}';work.mkdir(parents=True,exist_ok=True)
    analysis,features=analyse_audio(ns.audio,Path(ns.workdir)/'_audio_cache')
    chars=[]
    for raw in ns.character:
        parts=raw.split('::');chars.append(CharacterSpec(parts[0],parts[1] if len(parts)>1 else 'protagonist',parts[2] if len(parts)>2 else Path(parts[0]).stem))
    story=work/'story.json';make_story(analysis,story,seed,.62,ns.style,len(chars))
    cfg=DeluxeConfig(width=ns.width,height=ns.height,fps=ns.fps,seed=seed,style=ns.style,quality=ns.quality,preview_seconds=ns.preview_seconds,encoder=ns.encoder,audio_mode=ns.audio_mode,use_gpu=not ns.no_gpu,performance=ns.performance,ffmpeg_preset=ns.encoder_preset,cpu_workers=ns.cpu_workers,ram_budget_mb=ns.ram_budget_mb)
    cfg.save(work/'render_config.json')
    renderer=DeluxeRenderer(cfg,features,story,ns.media,chars)
    report=renderer.render(ns.output,ns.audio,lambda a,b:print(f'\r{a}/{b}',end='',flush=True))
    print('\n'+json.dumps(report,indent=2,ensure_ascii=False));return 0

if __name__=='__main__':raise SystemExit(main())
