from __future__ import annotations

import json
import math
import os
import subprocess
import time
import tempfile
import threading
from collections import deque
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable

import cv2
import numpy as np

from .audio_mux import resolve_encoder, video_writer_cmd
from .video_writer import AsyncVideoWriter
from .performance import make_plan, adapt_for_encoder
from .config import DeluxeConfig, QUALITY_PRESETS
from .features import FeatureStream
from .media import MediaPool, CharacterSpec, CharacterSprite, alpha_composite
from .scene_cpu import CPUSceneRenderer
from .styles import StyleState, prepare_style, finish_style, STYLE_SPECS

_RENDER_LOCK = threading.Lock()


class DeluxeRenderer:
    def __init__(self,cfg:DeluxeConfig,features_path:str|Path,story_path:str|Path,
                 media_paths:list[str]|None=None,characters:list[CharacterSpec]|None=None):
        self.cfg=cfg;cfg.validate();self.features=FeatureStream(features_path)
        self.story=json.loads(Path(story_path).read_text(encoding='utf-8'))
        self.shots=self.story['shots'];self.duration=float(self.story['duration_seconds'])
        q=QUALITY_PRESETS.get(cfg.quality,QUALITY_PRESETS['deluxe'])
        scale=cfg.internal_scale*q['scale'];self.iw=max(64,int(round(cfg.width*scale/2)*2));self.ih=max(64,int(round(cfg.height*scale/2)*2))
        self.plan=make_plan(cfg,self.iw,self.ih)
        self.media=MediaPool(media_paths or [],self.iw,self.ih,self.plan.media_cache_mb)
        self.characters=[CharacterSprite(c) for c in (characters or [])]
        self.style_state=StyleState();self.active_style=cfg.style;self.rng=np.random.default_rng(cfg.seed)
        self.renderer_name='CPU vectorised fallback';self.base=None
        self.gpu_requested=bool(cfg.use_gpu);self.gpu_active=False;self.gpu_error=None
        if cfg.use_gpu:
            try:
                from .gpu_engine import GPUSceneRenderer
                candidate=GPUSceneRenderer(self.iw,self.ih,cfg.seed)
                candidate.self_test()
                self.base=candidate;self.gpu_active=True
                self.renderer_name='GPU '+candidate.renderer_name
            except Exception as exc:
                self.gpu_error=repr(exc)
                try:candidate.close()
                except Exception:pass
        if self.base is None:self.base=CPUSceneRenderer(self.iw,self.ih,cfg.seed)
        self.last=np.zeros((self.ih,self.iw,3),np.uint8)

    def shot_at(self,t:float)->dict:
        lo,hi=0,len(self.shots)-1
        while lo<=hi:
            mid=(lo+hi)//2;s=self.shots[mid]
            if t<float(s['start']):hi=mid-1
            elif t>=float(s['end']):lo=mid+1
            else:return s
        return self.shots[min(max(lo,0),len(self.shots)-1)]

    def _camera(self,frame:np.ndarray,mode:str,t:float,local:float,impact:float,seed:int)->np.ndarray:
        h,w=frame.shape[:2];cx,cy=w/2,h/2
        if mode=='locked':return frame
        zoom=1.0;angle=0;dx=dy=0
        if mode=='push':zoom=1.0+.035*local
        elif mode=='drift':dx=math.sin(t*.25+seed)*w*.025;dy=math.cos(t*.19+seed)*h*.018
        elif mode=='orbit':angle=math.sin(t*.22+seed)*2.2;zoom=1.025
        elif mode=='handheld':dx=math.sin(t*7.3+seed)*w*.006*(.3+impact);dy=math.cos(t*9.1+seed)*h*.005*(.3+impact);angle=math.sin(t*6.1)*.6
        elif mode=='low_angle':dy=h*.04;zoom=1.06
        elif mode=='over_shoulder':dx=w*.04;zoom=1.10
        elif mode=='crash_zoom':zoom=1.0+.18*impact
        m=cv2.getRotationMatrix2D((cx,cy),angle,zoom);m[:,2]+=np.array([dx,dy])
        return cv2.warpAffine(frame,m,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT)

    def _characters(self,frame:np.ndarray,shot:dict,t:float,impact:float)->np.ndarray:
        if not self.characters:return frame
        local=t-float(shot['start']);dur=max(.001,float(shot['end'])-float(shot['start']));p=np.clip(local/dur,0,1)
        blocking=shot.get('blocking',{})
        # An explicitly empty list is meaningful for narrative shots where the
        # supplied references should affect the environment but no character
        # sprite should be composited. Older stories without the field retain
        # the original automatic-character behaviour.
        if 'visible_characters' in shot:
            visible=shot.get('visible_characters') or []
        else:
            visible=[int(shot['shot'])%len(self.characters)]
        for idx in sorted(visible,key=lambda x:blocking.get(str(x),{}).get('depth',.5),reverse=True):
            if idx>=len(self.characters):continue
            b=blocking.get(str(idx),{});x0=float(b.get('x_start',.5));x1=float(b.get('x_end',x0));x=int((x0+(x1-x0)*p)*self.iw)
            depth=float(b.get('depth',.5));scale=float(b.get('scale',1));height=int(self.ih*(.50+.24*(1-depth))*scale*self.cfg.character_strength)
            src,alpha=self.characters[idx].render(height,t,impact,str(b.get('action','idle')),int(b.get('facing',1)))
            y=int(self.ih*.90)-src.shape[0];px=x-src.shape[1]//2
            shadow=cv2.GaussianBlur(alpha,(0,0),max(2,self.ih*.008));alpha_composite(frame,np.zeros_like(src),(shadow*.30).astype(np.uint8),px+int(self.iw*.01),y+int(self.ih*.01))
            alpha_composite(frame,src,alpha,px,y)
        return frame

    def _transition(self,frame:np.ndarray,shot:dict,local:float)->np.ndarray:
        dur=min(.5,max(.12,(float(shot['end'])-float(shot['start']))*.2));p=float(np.clip(local/dur,0,1));kind=shot.get('transition','cut')
        if p>=1 or kind=='cut':return frame
        if kind=='dissolve':return cv2.addWeighted(frame,p,self.last,1-p,0)
        if kind=='blackout':return (frame.astype(np.float32)*p).astype(np.uint8)
        if kind=='shape_wipe':
            yy,xx=np.ogrid[:self.ih,:self.iw];r=np.sqrt((xx-self.iw/2)**2+(yy-self.ih/2)**2);mask=(r<math.hypot(self.iw,self.ih)*p)[...,None];return np.where(mask,frame,self.last).astype(np.uint8)
        if kind=='chromatic_whip':
            shift=int((1-p)*self.iw*.55);a=np.roll(frame,shift,1);b=np.roll(self.last,shift-self.iw,1);out=cv2.addWeighted(a,p,b,1-p,0);bb,gg,rr=cv2.split(out);return cv2.merge([np.roll(bb,3,1),gg,np.roll(rr,-3,1)])
        if kind=='film_burn':
            burn=np.full_like(frame,(35,95,235));return cv2.addWeighted(frame,p,burn,(1-p)*.65,0)
        return frame

    def _base_frame(self, shot, t, energy, impact, bright, media):
        try:
            return self.base.render(shot['scene'],t,energy,impact,bright,int(shot['seed']),media)
        except Exception as exc:
            if not self.gpu_active:
                raise
            self.gpu_error=repr(exc)
            try:self.base.close()
            except Exception:pass
            self.base=CPUSceneRenderer(self.iw,self.ih,self.cfg.seed)
            self.gpu_active=False
            self.renderer_name='CPU vectorised fallback após falha GPU'
            return self.base.render(shot['scene'],t,energy,impact,bright,int(shot['seed']),media)

    def _inputs(self, t):
        return (self.shot_at(t),self.features.value('energy',t),
                max(self.features.value('impact',t),self.features.pulse(t)),
                self.features.value('brightness',t))

    def _prepare(self, frame, shot, t, frame_no, energy, impact, bright, media):
        started=time.perf_counter()
        if frame is None:
            # CPU fallback scene generation is stateless and can run in workers.
            frame=self.base.render(shot['scene'],t,energy,impact,bright,int(shot['seed']),media)
        frame=self._characters(frame,shot,t,impact)
        local=t-float(shot['start'])
        frame=self._camera(frame,shot.get('camera','locked'),t,local,impact,int(shot['seed']))
        style_name=str(shot.get('style') or self.cfg.style)
        if style_name not in STYLE_SPECS:style_name=self.cfg.style
        styled=prepare_style(frame,style_name,t,frame_no,impact,self.cfg.seed)
        return frame,styled,style_name,shot,local,frame_no,impact,time.perf_counter()-started

    def _finish(self, prepared):
        src,styled,style_name,shot,local,frame_no,impact,_=prepared
        if style_name!=self.active_style:
            self.style_state=StyleState();self.active_style=style_name
        frame=finish_style(src,styled,style_name,self.cfg.style_strength,self.style_state,frame_no,impact)
        frame=self._transition(frame,shot,local)
        self.last=frame.copy()
        return frame

    def frame(self,t:float,frame_no:int)->np.ndarray:
        shot,energy,impact,bright=self._inputs(t)
        media=self.media.get(int(shot['shot']),t) if self.cfg.media_strength>0 else None
        frame=self._base_frame(shot,t,energy,impact,bright,media)
        frame=self._finish(self._prepare(frame,shot,t,frame_no,energy,impact,bright,media))
        if (self.iw,self.ih)!=(self.cfg.width,self.cfg.height):
            frame=cv2.resize(frame,(self.cfg.width,self.cfg.height),interpolation=cv2.INTER_LANCZOS4)
        return frame

    def render(self,output:str|Path,audio:str|Path|None=None,progress:Callable[[int,int],None]|None=None)->dict:
        if not _RENDER_LOCK.acquire(blocking=False):
            raise RuntimeError('Já existe um render em execução neste processo.')
        original_threads=cv2.getNumThreads()
        writer=None;effects=None;decoder=None
        out=Path(output);start=time.perf_counter()
        spatial_seconds=0.;source_seconds=0.;ordered_seconds=0.
        rss_peak=0
        try:
            import psutil
            resource_process=psutil.Process()
        except Exception:
            resource_process=None
        try:
            self.cfg.validate()
            if not self.shots:
                raise ValueError('O roteiro não contém planos.')
            if audio and not Path(audio).is_file():
                raise FileNotFoundError(audio)
            out.parent.mkdir(parents=True,exist_ok=True)
            encoder=resolve_encoder(self.cfg.encoder,out)
            self.plan=adapt_for_encoder(self.plan,encoder,self.iw,self.ih)
            cv2.setNumThreads(self.plan.opencv_threads)
            seconds=self.cfg.preview_seconds if self.cfg.preview_seconds>0 else self.duration
            total=max(1,int(round(seconds*self.cfg.fps)))
            # Keep the previous final file intact on failure; isolate concurrent jobs.
            with tempfile.TemporaryDirectory(prefix='subterra_render_',dir=out.parent) as td, ExitStack() as cleanup:
                staged=Path(td)/('film'+out.suffix)
                cmd=video_writer_cmd(staged,self.cfg.width,self.cfg.height,self.cfg.fps,encoder,
                                     self.cfg.crf,self.plan.encoder_preset,threads=self.plan.ffmpeg_threads,
                                     audio=audio,audio_mode=self.cfg.audio_mode)
                writer=AsyncVideoWriter(cmd,self.cfg.width,self.cfg.height,self.plan.encoder_queue)
                cleanup.callback(writer.abort)
                if self.cfg.performance=='compatibility':
                    for i in range(total):
                        writer.submit(self.frame(i/self.cfg.fps,i))
                        if resource_process and i%30==0:
                            rss_peak=max(rss_peak,resource_process.memory_info().rss)
                        if progress and (i%max(1,total//100)==0 or i==total-1):progress(i+1,total)
                else:
                    effects=ThreadPoolExecutor(max_workers=self.plan.workers,thread_name_prefix='subterra-effects')
                    pending=deque()
                    # Single owner for decoder handles; one-frame lookahead overlaps
                    # sequential decode with GL drawing and CPU postprocessing.
                    if self.media.items and self.cfg.media_strength>0:
                        decoder=ThreadPoolExecutor(max_workers=1,thread_name_prefix='subterra-media')
                        shot=self.shot_at(0)
                        media_future=decoder.submit(self.media.get,int(shot['shot']),0.)
                    else:
                        media_future=None
                    def commit():
                        nonlocal spatial_seconds,ordered_seconds
                        index,future=pending.popleft()
                        prepared=future.result();spatial_seconds+=prepared[-1]
                        tick=time.perf_counter();fr=self._finish(prepared)
                        ordered_seconds+=time.perf_counter()-tick
                        writer.submit(fr)
                        if progress and (index%max(1,total//100)==0 or index==total-1):progress(index+1,total)
                    for i in range(total):
                        writer.check()
                        tick=time.perf_counter();t=i/self.cfg.fps
                        shot,energy,impact,bright=self._inputs(t)
                        media=media_future.result() if media_future else None
                        if decoder and i+1<total:
                            next_t=(i+1)/self.cfg.fps;next_shot=self.shot_at(next_t)
                            media_future=decoder.submit(self.media.get,int(next_shot['shot']),next_t)
                        # OpenGL context remains on the thread that created it.
                        fr=self._base_frame(shot,t,energy,impact,bright,media) if self.gpu_active else None
                        source_seconds+=time.perf_counter()-tick
                        future=effects.submit(self._prepare,fr,shot,t,i,energy,impact,bright,media)
                        pending.append((i,future))
                        if len(pending)>=self.plan.inflight:commit()
                        if resource_process and i%30==0:
                            rss_peak=max(rss_peak,resource_process.memory_info().rss)
                    while pending:commit()
                writer.finish()
                if writer.frames!=total:
                    raise RuntimeError(f'Vídeo incompleto: {writer.frames}/{total} quadros.')
                staged.replace(out)
            elapsed=time.perf_counter()-start
            report={'version':'1.2.0','output':str(out.resolve()),'frames':total,'seconds':seconds,
                    'elapsed_seconds':round(elapsed,3),'fps_render':round(total/max(elapsed,.001),2),
                    'renderer':self.renderer_name,'gpu_requested':self.gpu_requested,
                    'gpu_active_at_finish':self.gpu_active,'gpu_error':self.gpu_error,'encoder':encoder,
                    'style':self.cfg.style,'styles_used':sorted({str(s.get('style') or self.cfg.style) for s in self.shots}),
                    'seed':self.cfg.seed,'audio_mode':self.cfg.audio_mode,
                    'audio_filters_applied':bool(audio) and self.cfg.audio_mode!='preserve',
                    'performance':self.plan.as_dict(),'media_decode':dict(self.media.stats),
                    'observed_python_rss_mb':round(rss_peak/1024**2,1) if rss_peak else None,
                    'timings':{'source_wall_seconds':round(source_seconds,3),
                               'spatial_worker_seconds_sum':round(spatial_seconds,3),
                               'ordered_effects_seconds':round(ordered_seconds,3),
                               'resize_seconds':round(writer.resize_seconds,3),
                               'pipe_write_seconds':round(writer.write_seconds,3)},
                    'encoder_queue_peak':writer.peak_queue,'single_pass_audio':bool(audio)}
            out.with_suffix('.render_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
            return report
        except BaseException:
            if writer:writer.abort()
            raise
        finally:
            if effects:effects.shutdown(wait=True,cancel_futures=True)
            if decoder:decoder.shutdown(wait=True,cancel_futures=True)
            self.close()
            cv2.setNumThreads(original_threads)
            _RENDER_LOCK.release()

    def close(self):
        self.media.close()
        try:self.base.close()
        except Exception:pass
