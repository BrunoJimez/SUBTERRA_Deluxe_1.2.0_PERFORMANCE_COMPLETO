"""Bounded producer/consumer writer with explicit error propagation and cleanup."""
from __future__ import annotations

from pathlib import Path
import queue
import subprocess
import tempfile
import threading
import time

import cv2
import numpy as np


class AsyncVideoWriter:
    def __init__(self, cmd, width, height, queue_size=2):
        self.width = width; self.height = height
        self.queue = queue.Queue(maxsize=queue_size)
        self.error = None; self.frames = 0; self.peak_queue = 0
        self.write_seconds = 0.; self.resize_seconds = 0.
        self.stop = threading.Event()
        self.write_started = None
        self.log = tempfile.TemporaryFile(mode='w+b')
        try:
            self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=self.log, bufsize=0)
        except BaseException:
            self.log.close(); raise
        self.thread = threading.Thread(target=self._run, name='subterra-encoder', daemon=True)
        self.thread.start()

    def _detail(self):
        self.log.seek(0)
        return self.log.read()[-6000:].decode('utf-8', 'replace')

    def check(self):
        if self.write_started is not None and time.monotonic()-self.write_started > 90:
            raise RuntimeError('FFmpeg ficou 90 segundos sem consumir dados de vídeo. Verifique disco/driver. '+self._detail())
        if self.error is not None:
            raise RuntimeError(f'Falha ao gravar vídeo: {self.error}\n{self._detail()}') from self.error
        code = self.proc.poll()
        if code is not None and code != 0:
            raise RuntimeError(f'FFmpeg terminou com código {code}: {self._detail()}')

    def submit(self, frame):
        # Caller transfers ownership: it must never mutate this frame again.
        while True:
            self.check()
            try:
                self.queue.put(frame, timeout=.1)
                self.peak_queue = max(self.peak_queue, self.queue.qsize())
                return
            except queue.Full:
                pass

    def _run(self):
        try:
            while not self.stop.is_set():
                try:
                    frame = self.queue.get(timeout=.1)
                except queue.Empty:
                    continue
                if frame is None:
                    break
                started = time.perf_counter()
                if frame.shape[:2] != (self.height, self.width):
                    frame = cv2.resize(frame, (self.width, self.height), interpolation=cv2.INTER_LANCZOS4)
                self.resize_seconds += time.perf_counter() - started
                started = time.perf_counter()
                data = memoryview(np.ascontiguousarray(frame)).cast('B')
                self.write_started = time.monotonic()
                while data:
                    written = self.proc.stdin.write(data)
                    if not written:
                        raise BrokenPipeError('FFmpeg fechou a entrada de vídeo.')
                    data = data[written:]
                    self.write_started = time.monotonic()
                self.write_started = None
                self.write_seconds += time.perf_counter() - started
                self.frames += 1
        except BaseException as exc:
            self.error = exc
        finally:
            try:
                self.proc.stdin.close()
            except (OSError, ValueError):
                pass

    def finish(self):
        self.submit(None)
        while self.thread.is_alive():
            self.thread.join(timeout=.1)
            self.check()
        self.check()
        try:
            code = self.proc.wait(timeout=60)
        except subprocess.TimeoutExpired:
            self.abort()
            raise RuntimeError('FFmpeg não finalizou em 60 segundos após receber os quadros.')
        if code:
            raise RuntimeError(f'FFmpeg terminou com código {code}: {self._detail()}')
        self.log.close()

    def abort(self):
        self.stop.set()
        if self.proc.poll() is None:
            self.proc.kill()
        self.thread.join(timeout=5)
        try:
            self.proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
        if not self.thread.is_alive():
            self.log.close()
