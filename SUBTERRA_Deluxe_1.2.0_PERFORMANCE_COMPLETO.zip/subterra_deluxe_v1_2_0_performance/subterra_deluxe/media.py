from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math
from collections import OrderedDict
import cv2
import numpy as np

IMAGE_EXT={'.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff'}
VIDEO_EXT={'.mp4','.mov','.mkv','.avi','.webm','.m4v'}


def _as_bgr_u8(frame: np.ndarray) -> np.ndarray:
    """Normaliza qualquer quadro OpenCV para BGR uint8 contíguo."""
    if frame is None or not isinstance(frame, np.ndarray) or frame.size == 0:
        raise ValueError("Quadro de mídia vazio ou inválido.")
    if frame.ndim == 2:
        frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
    elif frame.ndim == 3:
        channels = frame.shape[2]
        if channels == 1:
            frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
        elif channels == 4:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
        elif channels != 3:
            raise ValueError(f"Número de canais de mídia não suportado: {channels}")
    else:
        raise ValueError(f"Formato de mídia não suportado: shape={frame.shape}")

    if frame.dtype != np.uint8:
        if np.issubdtype(frame.dtype, np.floating):
            vmax = float(np.nanmax(frame)) if frame.size else 0.0
            if vmax <= 1.0:
                frame = frame * 255.0
        frame = np.nan_to_num(frame, nan=0.0, posinf=255.0, neginf=0.0)
        frame = np.clip(frame, 0, 255).astype(np.uint8)
    return np.ascontiguousarray(frame)


def cover(frame: np.ndarray, width: int, height: int) -> np.ndarray:
    """Redimensiona/corta em *cover* e garante exatamente ``height x width x 3``.

    A implementação anterior usava ``int(w * scale)`` / ``int(h * scale)``.
    Para certas proporções (por exemplo 832x1216 -> 960x540), o erro de ponto
    flutuante truncava uma dimensão para 959 px. O ``cv2.addWeighted`` exige
    matrizes com o mesmo tamanho e então abortava o render GPU/CPU com
    ``(-209:Sizes of input arguments do not match)``.
    """
    width = int(width)
    height = int(height)
    if width <= 0 or height <= 0:
        raise ValueError(f"Resolução de destino inválida: {width}x{height}")

    frame = _as_bgr_u8(frame)
    h, w = frame.shape[:2]
    if (w, h) == (width, height):
        return frame

    scale = max(width / max(1, w), height / max(1, h))
    # ceil é intencional: em modo cover nenhuma dimensão pode ficar 1 px menor
    # por truncamento/erro de representação binária.
    nw = max(width, int(math.ceil(w * scale)))
    nh = max(height, int(math.ceil(h * scale)))
    r = cv2.resize(
        frame, (nw, nh),
        interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC,
    )
    x = max(0, (nw - width) // 2)
    y = max(0, (nh - height) // 2)
    out = r[y:y + height, x:x + width]

    # Guarda final contra decoders/backends incomuns: jamais deixa a mídia
    # chegar ao compositor com tamanho diferente do framebuffer.
    if out.shape[:2] != (height, width):
        out = cv2.resize(out, (width, height), interpolation=cv2.INTER_LINEAR)
    return np.ascontiguousarray(out)


class MediaPool:
    """Lazy, bounded image cache and sequential video decoding.

    Owned by a single decoder thread during rendering. No VideoCapture is shared
    with effect workers. Repeated target frames reuse the already resized frame.
    """
    def __init__(self, paths: list[str], width: int, height: int, cache_mb: int = 128):
        self.width = width; self.height = height
        self.items = [(('image' if Path(p).suffix.lower() in IMAGE_EXT else 'video'), str(p))
                      for p in paths if Path(p).suffix.lower() in IMAGE_EXT | VIDEO_EXT]
        self.cache_limit = max(0, cache_mb) * 1024**2
        self.cache = OrderedDict(); self.cache_bytes = 0
        self.videos = OrderedDict()
        self.stats = {'seeks': 0, 'reads': 0, 'reused_frames': 0, 'image_cache_hits': 0}

    def _image(self, path):
        if path in self.cache:
            self.stats['image_cache_hits'] += 1
            self.cache.move_to_end(path)
            return self.cache[path]
        im = cv2.imread(path, cv2.IMREAD_COLOR)
        if im is None:
            return None
        im = cover(im, self.width, self.height)
        if im.nbytes <= self.cache_limit:
            while self.cache and self.cache_bytes + im.nbytes > self.cache_limit:
                _, old = self.cache.popitem(last=False); self.cache_bytes -= old.nbytes
            self.cache[path] = im; self.cache_bytes += im.nbytes
        return im

    def _video(self, path):
        if path in self.videos:
            self.videos.move_to_end(path)
            return self.videos[path]
        # Bound decoder-native RAM/threads as well as Python frame buffers.
        while len(self.videos) >= 2:
            _, old = self.videos.popitem(last=False); old['cap'].release()
        cap = cv2.VideoCapture()
        try:
            if hasattr(cv2, 'CAP_PROP_N_THREADS'):
                opened = cap.open(path, cv2.CAP_FFMPEG, [cv2.CAP_PROP_N_THREADS, 2])
            else:
                opened = False
        except cv2.error:
            opened = False
        if not opened:
            cap.open(path)
        if not cap.isOpened():
            cap.release(); return None
        fps = cap.get(cv2.CAP_PROP_FPS)
        fps = fps if math.isfinite(fps) and fps > 0 else 30
        count = cap.get(cv2.CAP_PROP_FRAME_COUNT)
        count = int(count) if math.isfinite(count) and count > 0 else 0
        state = dict(cap=cap, fps=fps, count=count, next=0, last_index=-1, last=None)
        self.videos[path] = state
        return state

    def get(self, index: int, t: float) -> np.ndarray | None:
        if not self.items:
            return None
        kind, path = self.items[index % len(self.items)]
        if kind == 'image':
            return self._image(path)
        state = self._video(path)
        if state is None:
            return None
        cap = state['cap']
        target = max(0, int(t * state['fps']))
        if state['count']:
            target %= state['count']
        else:
            target = state['next']  # streams with unknown frame count
        if target == state['last_index'] and state['last'] is not None:
            self.stats['reused_frames'] += 1
            return state['last']
        gap = target - state['next']
        if gap < 0 or gap > 12:
            cap.set(cv2.CAP_PROP_POS_FRAMES, target)
            self.stats['seeks'] += 1
        else:
            for _ in range(gap):
                if not cap.grab():
                    break
        ok, fr = cap.read(); self.stats['reads'] += 1
        if ok:
            state['last'] = cover(fr, self.width, self.height)
            state['last_index'] = target
            state['next'] = target + 1
        else:
            state['next'] = -1000  # force seek/recovery on next call
        return state['last']

    def close(self):
        for state in self.videos.values():
            state['cap'].release()
        self.videos.clear(); self.cache.clear(); self.cache_bytes = 0


@dataclass
class CharacterSpec:
    path: str
    role: str='protagonist'
    name: str='Character'


class CharacterSprite:
    """Lightweight 2.5D character layer for the integrated fast renderer.

    Full rigging from SUBTERRA-CYBERPUNK 0.2 remains bundled as a separate engine.
    This path is deliberately cheap: one prepared alpha sprite, affine motion and
    secondary deformation without per-frame segmentation.
    """
    def __init__(self,spec:CharacterSpec):
        self.spec=spec
        im=cv2.imread(spec.path,cv2.IMREAD_UNCHANGED)
        if im is None:raise ValueError(f'Personagem ilegível: {spec.path}')
        if im.ndim==2: im=cv2.cvtColor(im,cv2.COLOR_GRAY2BGRA)
        if im.shape[2]==3:
            gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
            # Border-connected light/dark backgrounds become transparent.
            corners=np.concatenate([im[:8,:8].reshape(-1,3),im[:8,-8:].reshape(-1,3),im[-8:,:8].reshape(-1,3),im[-8:,-8:].reshape(-1,3)])
            bg=np.median(corners,axis=0)
            dist=np.linalg.norm(im.astype(np.float32)-bg[None,None,:],axis=2)
            alpha=np.clip((dist-18)*8,0,255).astype(np.uint8)
            alpha=cv2.medianBlur(alpha,5)
            im=np.dstack([im,alpha])
        alpha=im[...,3]
        pts=cv2.findNonZero((alpha>8).astype(np.uint8))
        if pts is not None:
            x,y,w,h=cv2.boundingRect(pts);im=im[y:y+h,x:x+w]
        self.image=im

    def render(self,height:int,t:float,impact:float,action:str,facing:int=1)->tuple[np.ndarray,np.ndarray]:
        base=self.image
        scale=height/max(1,base.shape[0]);w=max(2,int(base.shape[1]*scale));h=max(2,int(base.shape[0]*scale))
        rgba=cv2.resize(base,(w,h),interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_CUBIC)
        if facing<0:rgba=cv2.flip(rgba,1)
        # Stable mesh-like affine movement; identity remains intact.
        sway=math.sin(t*1.7)*(.015+.02*impact)
        bob=math.sin(t*2.4)*(.008+.018*impact)
        if action in {'walk','run'}: sway*=2.1;bob*=2.3
        if action in {'dance','sing'}: sway*=1.6
        if action=='dramatic_turn': sway+=math.sin(min(1,t%2)*math.pi)*.08
        m=np.float32([[1,sway,-sway*h*.45],[0,1,bob*h]])
        rgba=cv2.warpAffine(rgba,m,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
        return rgba[...,:3],rgba[...,3]


def alpha_composite(dst:np.ndarray,src:np.ndarray,alpha:np.ndarray,x:int,y:int)->None:
    h,w=src.shape[:2];H,W=dst.shape[:2]
    x0=max(0,x);y0=max(0,y);x1=min(W,x+w);y1=min(H,y+h)
    if x1<=x0 or y1<=y0:return
    sx=x0-x;sy=y0-y;sw=x1-x0;sh=y1-y0
    a=alpha[sy:sy+sh,sx:sx+sw].astype(np.float32)[...,None]/255
    d=dst[y0:y1,x0:x1].astype(np.float32);s=src[sy:sy+sh,sx:sx+sw].astype(np.float32)
    dst[y0:y1,x0:x1]=np.clip(s*a+d*(1-a),0,255).astype(np.uint8)
