"""Bounded scheduling: more useful parallel work, never an unbounded film in RAM."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
import os

MIB = 1024 ** 2


@dataclass(frozen=True)
class PerformancePlan:
    profile: str
    workers: int
    inflight: int
    encoder_queue: int
    opencv_threads: int
    ffmpeg_threads: int
    memory_budget_mb: int
    estimated_peak_mb: int
    media_cache_mb: int
    available_ram_mb: int
    logical_cpus: int
    encoder_preset: str

    def as_dict(self):
        return asdict(self)


def make_plan(cfg, iw: int, ih: int, *, available_mb=None, logical_cpus=None) -> PerformancePlan:
    cores = max(1, logical_cpus or os.cpu_count() or 1)
    if available_mb is None:
        try:
            import psutil
            available_mb = int(psutil.virtual_memory().available / MIB)
        except Exception:
            available_mb = 2048  # conservative when hardware detection fails
    available_mb = max(1, int(available_mb))
    # Budget only this pipeline, leaving RAM for the OS, GUI and ComfyUI.
    safe_mb = max(1, int(available_mb * .40))
    budget = min(int(cfg.ram_budget_mb) if cfg.ram_budget_mb else 2048, safe_mb)
    per_job = max(8, int(iw * ih * 100 / MIB) + 1)  # float temporaries + sources
    output_mb = max(1, int(cfg.width * cfg.height * 3 / MIB) + 1)
    cache_mb = min(128, max(0, budget // 12))
    fixed_mb = cache_mb + max(16, int(iw * ih * 40 / MIB)) + output_mb * 3
    if budget < fixed_mb + per_job:
        raise ValueError(f'RAM insuficiente para os buffers nesta resolução: estimativa mínima {fixed_mb + per_job} MiB, '
                         f'orçamento {budget} MiB. Feche outros aplicativos, aumente o orçamento ou use qualidade fast/preview.')
    mem_workers = max(1, (budget - fixed_mb) // per_job)
    if cfg.performance == 'compatibility':
        workers = 1
    else:
        automatic = min(4 if cfg.performance == 'balanced' else 8, max(1, cores - 1))
        workers = min(cfg.cpu_workers or automatic, cores, mem_workers)
    inflight = 1 if cfg.performance == 'compatibility' else min(workers + 1, max(1, (budget - fixed_mb) // per_job))
    workers = min(workers, inflight)
    native_threads = min(4, max(1, cores // max(1, workers + 1)))
    if cfg.performance == 'compatibility':
        preset = "p5"
    else:
        preset = 'p4' if cfg.performance == 'balanced' else 'p2'
    if cfg.ffmpeg_preset != "auto":
        preset = cfg.ffmpeg_preset
    peak = fixed_mb + per_job * inflight
    return PerformancePlan(cfg.performance, workers, inflight, 2, native_threads,
                           min(8, max(1, cores - workers)), budget, peak,
                           cache_mb, available_mb, cores, preset)


def adapt_for_encoder(plan: PerformancePlan, encoder: str, iw: int, ih: int) -> PerformancePlan:
    # With libx264, encoding itself consumes CPU. Reserve enough execution
    # capacity for it instead of starving a one-thread encoder behind 8 workers.
    if encoder != 'libx264' or plan.profile == 'compatibility':
        return plan
    workers=min(plan.workers,max(1,plan.logical_cpus//2))
    inflight=min(plan.inflight,workers+1)
    per_job=max(8,int(iw*ih*100/MIB)+1)
    return replace(plan,workers=workers,inflight=inflight,
                   ffmpeg_threads=min(8,max(1,plan.logical_cpus//2)),
                   estimated_peak_mb=plan.estimated_peak_mb-(plan.inflight-inflight)*per_job)
