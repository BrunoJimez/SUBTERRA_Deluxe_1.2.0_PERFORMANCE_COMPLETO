from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path


@dataclass
class DeluxeConfig:
    width: int = 1920
    height: int = 1080
    fps: float = 30.0
    seed: int = 0
    style: str = "nolan_odisseia"
    style_strength: float = 0.90
    engine_mode: str = "deluxe_hybrid"  # deluxe_hybrid, classic, cyberpunk
    quality: str = "deluxe"
    internal_scale: float = 1.0
    encoder: str = "auto"
    crf: int = 18
    ffmpeg_preset: str = "auto"
    audio_mode: str = "preserve"  # no filtering by default
    edit_density: float = 0.62
    character_strength: float = 0.78
    media_strength: float = 0.72
    safe_flashes: bool = True
    preview_seconds: float = 0.0
    use_gpu: bool = True
    cache_analysis: bool = True
    ai_mode: str = "off"  # off, package, clips, package_and_clips
    ai_backend: str = "ltx_video_q8"
    ai_dir: str = ""
    performance: str = "balanced"  # balanced, maximum, compatibility
    cpu_workers: int = 0  # 0: hardware/RAM-aware automatic selection
    ram_budget_mb: int = 0  # 0: automatic, at most 2048 MiB / 40% available


    def validate(self) -> None:
        if self.performance not in {"balanced", "maximum", "compatibility"}:
            raise ValueError("Perfil de desempenho inválido.")
        if not isinstance(self.cpu_workers, int) or not 0 <= self.cpu_workers <= 64:
            raise ValueError("Workers deve estar entre 0 (automático) e 64.")
        if not isinstance(self.ram_budget_mb, int) or self.ram_budget_mb < 0:
            raise ValueError("Orçamento de RAM precisa ser inteiro não negativo.")
        if self.ffmpeg_preset not in {"auto", "p1", "p2", "p3", "p4", "p5", "p6", "p7", "ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "slower", "veryslow"}:
            raise ValueError("Preset de codificação inválido.")
        if self.width < 64 or self.height < 64:
            raise ValueError("Resolução mínima: 64x64")
        if self.width % 2 or self.height % 2:
            raise ValueError("A largura e a altura precisam ser pares para H.264/H.265.")
        if not 1 <= self.fps <= 120:
            raise ValueError("FPS fora da faixa 1–120.")
        if not 0.25 <= self.internal_scale <= 2.0:
            raise ValueError("Escala interna fora da faixa 0.25–2.0.")
        if not 0 <= self.style_strength <= 1:
            raise ValueError("Intensidade de estilo fora da faixa 0–1.")

    def save(self, path: str | Path) -> Path:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding="utf-8")
        return p

    @classmethod
    def load(cls, path: str | Path) -> "DeluxeConfig":
        return cls(**json.loads(Path(path).read_text(encoding="utf-8")))


QUALITY_PRESETS = {
    "preview": {"scale": 0.50, "scene_detail": 0.55, "bloom": 0.55},
    "fast": {"scale": 0.75, "scene_detail": 0.72, "bloom": 0.70},
    "deluxe": {"scale": 1.00, "scene_detail": 0.90, "bloom": 0.85},
    "master": {"scale": 1.15, "scene_detail": 1.00, "bloom": 1.00},
}
