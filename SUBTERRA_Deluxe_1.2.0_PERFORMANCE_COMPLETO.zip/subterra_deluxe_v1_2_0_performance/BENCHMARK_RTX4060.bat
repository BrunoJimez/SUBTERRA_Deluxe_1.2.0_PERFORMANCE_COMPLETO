@echo off
setlocal
cd /d "%~dp0"
if exist "C:\ffmpeg\bin\ffmpeg.exe" set "PATH=C:\ffmpeg\bin;%PATH%"
if not exist .venv\Scripts\python.exe (
  echo Execute INSTALAR_WINDOWS.bat primeiro.
  pause
  exit /b 1
)
echo Comparando tres perfis em Full HD. Aguarde as duas repeticoes.
.venv\Scripts\python.exe tests\benchmark_rtx4060.py --width 1920 --height 1080 --fps 30 --seconds 8 --quality deluxe --encoder auto --repeats 2
if errorlevel 1 goto falha
echo Resultado: benchmark_output\benchmark_comparativo.json
pause
exit /b 0
:falha
echo Benchmark interrompido. Leia o erro acima.
pause
exit /b 1
