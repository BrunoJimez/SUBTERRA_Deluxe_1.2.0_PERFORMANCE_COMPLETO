@echo off
setlocal
cd /d "%~dp0"
if exist "C:\ffmpeg\bin\ffmpeg.exe" set "PATH=C:\ffmpeg\bin;%PATH%"
if not exist .venv\Scripts\python.exe (
  py -3.11 --version >nul 2>&1
  if not errorlevel 1 (
    py -3.11 -m venv .venv
  ) else (
    py -3 --version >nul 2>&1
    if not errorlevel 1 (
      py -3 -m venv .venv
    ) else (
      python -m venv .venv
    )
  )
)
if not exist .venv\Scripts\python.exe (
  echo Nao foi possivel criar o ambiente. Instale Python 3.11 ou superior de 64 bits.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto falha
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto falha
.venv\Scripts\python.exe -m compileall -q subterra_deluxe gui.py deluxe.py
if errorlevel 1 goto falha
where ffmpeg >nul 2>&1
if errorlevel 1 echo AVISO: adicione o FFmpeg ao PATH antes de renderizar.
echo Instalacao concluida. Abra ABRIR_DELUXE.bat.
pause
exit /b 0
:falha
echo Instalacao interrompida. Leia a mensagem de erro acima.
pause
exit /b 1
