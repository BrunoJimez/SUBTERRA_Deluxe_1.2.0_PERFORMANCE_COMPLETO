# Arquitetura de desempenho — 1.2.0

## Gargalos encontrados na 1.1.2

1. O laço executava render, composição, filtros, resize e escrita do quadro de forma sequencial. A GPU podia esperar filtros e pipe.
2. `MediaPool.get` chamava `CAP_PROP_POS_FRAMES` em todo quadro de vídeo, mesmo para a posição imediatamente seguinte. Em formatos com GOP isso exige reposicionar e decodificar repetidamente.
3. Imagens eram todas carregadas/redimensionadas na criação do projeto. Não havia limite explícito desse cache.
4. A vinheta recalculava sua geometria e máscara estática em cada quadro.
5. A escrita criava uma cópia `bytes` de cada quadro com `tobytes`.
6. A escolha automática de NVENC considerava a lista de encoders e nvidia-smi; um encoder listado pode falhar sem um driver/placa compatível. Havia seleção QSV que acabava construída como libx264.
7. O Deluxe exportava um filme silencioso inteiro e depois fazia uma segunda passagem de cópia/mux do vídeo com áudio.
8. A GUI selecionava uma pasta de análise por seed, repetindo análise idêntica em projetos com semente visual diferente.
9. A montagem híbrida normalizava todos os segmentos sequencialmente.

## Implementação

`performance.py` seleciona limites com base em CPUs lógicas, resolução e RAM livre. O preset rápido só é escolhido se não existir um preset explicitamente configurado. Com libx264, a seleção reserva CPU para o encoder.

O produtor mantém o contexto OpenGL em sua thread original. Um decoder exclusivo pode preparar a próxima mídia. Cada quadro com mídia própria é entregue aos workers para câmera, personagem e `prepare_style`, que não modificam estado temporal. A geração CPU também pode ocorrer nesses workers quando OpenGL não está ativo.

As futures entram em uma deque limitada. O produtor consome resultados em ordem. `finish_style` atualiza apenas então o estado temporal; transições e último quadro também permanecem em ordem. Um escritor com fila de tamanho dois faz o resize final e alimenta o FFmpeg. A propriedade do array é transferida ao escritor; buffers GPU reutilizáveis são copiados antes de entregar um quadro a workers.

`MediaPool` abre arquivos sob demanda. Até dois decoders ficam abertos; imagens têm cache LRU em bytes. Repetições do mesmo frame reutilizam a versão já normalizada, avanços pequenos usam leitura/grab sequenciais e somente saltos/loops fazem seek. As dimensões exatas do hotfix anterior continuam garantidas por `cover`.

O framebuffer usa `read_into` em vez de criar primeiro um `bytes` de readback. A passagem pelo host permanece necessária para os filtros NumPy/OpenCV. Não há alegação de zero-copy GPU → NVENC nem migração de todos os filtros para CUDA.

A fila do escritor usa `memoryview` e trata escrita parcial. Stderr fica em arquivo temporário para não bloquear um pipe cheio. Erros chegam ao produtor; ausência de progresso no pipe por 90 segundos é tratada como falha. A exportação é feita em pasta temporária ao lado do destino e só substitui o arquivo final ao terminar com sucesso. Os executores são encerrados antes da liberação dos recursos.

O FFmpeg recebe vídeo raw BGR e áudio no mesmo processo. Em preserve, não há filtros de EQ/dinâmica; AAC continua sendo codificação com perdas quando o contêiner exige, como na versão anterior. O MP4 recebe faststart ao finalizar.

A GUI cria a configuração e captura os campos do render na thread Tk. Registro, progresso e conclusão retornam por fila, mantendo a interface responsiva. O mesmo processo recusa dois renders Deluxe concorrentes, inclusive porque a configuração nativa de threads OpenCV é global. Os threads nativos são restaurados ao final.

Na montagem híbrida, os comandos de normalização são executados com concorrência limitada a dois segmentos, sem mudar a ordem da concatenação nem o cálculo cumulativo do número de quadros.

## Compromissos

- Uma fila não remove o custo intrínseco dos shaders ou filtros. O ganho depende da distribuição de custos.
- Os limites de memória são estimativas conservadoras de buffers, não um mecanismo de contenção do sistema operacional.
- Os perfis afetam o preset de compressão. Use `--same-preset` no benchmark para separar esse efeito do paralelismo.
- O cache de áudio é compartilhado entre seeds no fluxo GUI/CLI, com chave por caminho, tamanho e mtime do arquivo.
- O processo de difusão no ComfyUI e os motores legados separados não foram reescritos.

## Documentação oficial consultada

- [OpenCV — propriedades de vídeo](https://docs.opencv.org/4.13.0/d4/d15/group__videoio__flags__base.html).
- [ModernGL — Framebuffer/read_into](https://moderngl.readthedocs.io/en/stable/reference/framebuffer.html).
- [NVIDIA — FFmpeg com aceleração GPU](https://docs.nvidia.com/video-technologies/video-codec-sdk/13.0/ffmpeg-with-nvidia-gpu/index.html).

A escolha das filas e limites é uma decisão desta implementação; não é uma recomendação de desempenho garantido por esses projetos.
