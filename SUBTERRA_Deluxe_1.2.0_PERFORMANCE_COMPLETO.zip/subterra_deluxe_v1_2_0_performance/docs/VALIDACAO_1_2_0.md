# Validação e análise — SUBTERRA Deluxe 1.2.0

Data da entrega: 23/10/2026.

## Escopo da melhoria

A versão enviada pelo usuário foi descompactada e o fluxo principal foi revisado: configuração, GUI, CLI, análise musical, geração GPU/CPU, estilos, mídia, exportação e montagem híbrida. A revisão dos caminhos de IA concentrou-se na integração e montagem; não houve treinamento de modelo ou execução de difusão no ComfyUI.

O diagnóstico e as decisões de implementação estão em `SPEED_ARCHITECTURE.md`. As instruções de instalação e escolha de perfil estão em `../LEIA_PRIMEIRO_DESEMPENHO.md`.

## Evidência de desempenho

Ensaio de renderização em CPU no ambiente Linux de desenvolvimento, 9 CPUs lógicas detectadas. Três repetições por perfil, ordem rotativa, mesma seed, roteiro, áudio, estilo nolan_odisseia, 1280×720, 24 fps, 3 segundos / 72 quadros. Qualidade deluxe, escala interna 1.0, libx264 medium fixo em todos os perfis. Análise musical excluída por usar fixture sintética; exportação de áudio e finalização MP4 incluídas. Os renders foram conferidos com FFprobe.

| Perfil | Tempos das três repetições (s) | Mediana (s) | Velocidade relativa |
|---|---|---:|---:|
| Compatibilidade | 13,302; 14,338; 13,614 | 13,614 | 1,000× |
| Equilibrado | 7,686; 7,116; 7,007 | 7,116 | 1,913× |
| Máximo | 6,983; 6,714; 6,765 | 6,765 | 2,012× |

O comparador é o perfil sequencial da versão atual, não a versão original completa 1.1.2. Portanto, o resultado não quantifica separadamente o ganho adicional da leitura sequencial, cache de áudio ou remoção da passagem de mux. Nesse ensaio sem mídias externas, o foco foi o paralelismo dos quadros.

O arquivo bruto `BENCHMARK_DESENVOLVIMENTO.json` registra parâmetros, cada execução e verificação do número de quadros. Os perfis padrão usam presets diferentes; este ensaio fixou o mesmo preset para evitar atribuir ao paralelismo um ganho proveniente de compressão mais rápida.

Não houve medição em RTX 4060/NVENC. O ensaio OpenGL executado nos testes usou llvmpipe/Mesa, um renderizador por software. A proporção de ganho no computador do usuário pode mudar com CPU, mídia, estilo, resolução, driver e disco.

## Testes executados

- **20/20 testes unittest**, sem falhas ou skips neste ambiente. Incluem os sete testes anteriores de ComfyUI/keyframes e treze casos de desempenho/integração.
- **10/10 verificações do validador integrado**, incluindo render com áudio, personagens, diferenciação dos 30 estilos, contrato de mídia, segurança da configuração I2V/T2V e montagem híbrida.
- **1/1 contrato independente GPU/uniformes**, preservando a correção de uBright.

Total: 31 verificações aprovadas entre os três comandos. Alguns contratos são deliberadamente conferidos por mais de um comando; esse total não representa 31 projetos ou 31 placas de vídeo diferentes.

### Regressões de desempenho e integridade

1. Os hashes de 180 imagens (6 quadros × 30 estilos) foram calculados executando o código original 1.1.2 e usados como referência. O estilo otimizado coincidiu pixel a pixel neste ambiente.
2. Quadros do pipeline sequencial, Equilibrado e Máximo foram comparados antes de codificação, com personagens, seis tipos de transição, câmeras e mudanças de estilo. Houve igualdade pixel a pixel tanto no fallback CPU quanto em OpenGL/Mesa.
3. Um vídeo FFV1 com quadros numerados foi lido na ordem: 36 solicitações a 24 fps em uma fonte de 12 fps resultaram em 18 leituras, 18 reutilizações e zero seeks no percurso contínuo. Saltos e loops também retornaram os quadros corretos.
4. A leitura antecipada de mídia preservou o acesso exclusivo ao decoder. O cache de imagens permaneceu dentro do limite configurado.
5. Foram verificadas a redução de workers conforme RAM/CPU, a rejeição de orçamento insuficiente, a carga de configurações antigas e a precedência de preset explícito.
6. MP4 real foi verificado por FFprobe: resolução, 24 quadros, CFR 24/1, duração de um segundo e faixa de áudio correspondente.
7. FFmpeg com opção inválida retornou erro sem deixar thread/processo de escrita ativo.
8. Erro inserido em um efeito preservou o vídeo anterior, restaurou as threads OpenCV e removeu temporários.
9. Falha de driver simulada durante o filme concluiu os quadros em CPU e registrou a causa.
10. A montagem híbrida sequencial/paralela foi testada com um clipe substituto determinístico e dois fallbacks, mantendo ordem, contagens e aparência dos quadros. Esse clipe era fixture de teste, não geração real de IA.

Os hashes históricos podem ser ignorados automaticamente em instalações com versões NumPy/OpenCV diferentes da referência, para evitar tratar diferenças dessas bibliotecas como falhas do programa. Os testes de equivalência sequencial/paralela e exportação continuam disponíveis. OpenGL indisponível também resulta em skip específico desse teste, sem ocultar os testes CPU.

## Limites práticos

A GUI Windows foi inspecionada e compilada, mas não executada nativamente neste ambiente Linux. O driver NVIDIA, NVENC e as características de VRAM do computador do usuário exigem o diagnóstico/benchmark local. Os caminhos sem NVIDIA, de falha e de fallback foram executados.

A análise inicial de áudio ainda pode ser demorada, especialmente na primeira execução com JIT das bibliotecas. Seu resultado é reutilizado nas próximas sementes. A difusão dos modelos ComfyUI não recebe ganho garantido desta mudança; o que foi paralelizado nesse caminho é a montagem dos clipes já prontos.
