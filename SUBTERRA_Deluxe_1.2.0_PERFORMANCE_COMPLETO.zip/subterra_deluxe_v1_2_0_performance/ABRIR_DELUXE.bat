@echo off
setlocal
cd /d "%~dp0"
if exist "C:\ffmpeg\bin\ffmpeg.exe" set "PATH=C:\ffmpeg\bin;%PATH%"
if exist .venv\Scripts\pythonw.exe (
  .venv\Scripts\pythonw.exe gui.py
) else (
  echo Execute INSTALAR_WINDOWS.bat primeiro.
  pause
)
